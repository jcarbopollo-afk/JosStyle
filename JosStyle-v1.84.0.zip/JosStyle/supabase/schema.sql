-- Ejecuta esto en Supabase: panel del proyecto -> SQL Editor -> pega y dale a "Run".

-- Tabla genérica de almacenamiento por usuario y "clave" (mismo concepto que se usaba
-- antes con window.storage, pero ahora en una base de datos real con seguridad por fila).
create table if not exists app_data (
  user_id uuid references auth.users(id) on delete cascade not null,
  key text not null,
  value jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, key)
);

alter table app_data enable row level security;

create policy "select propio" on app_data
  for select using (auth.uid() = user_id);

create policy "insert propio" on app_data
  for insert with check (auth.uid() = user_id);

create policy "update propio" on app_data
  for update using (auth.uid() = user_id);

create policy "delete propio" on app_data
  for delete using (auth.uid() = user_id);

-- Con esto activo, cada usuario solo puede leer y escribir sus propias filas,
-- aunque haya más de un usuario en el futuro usando la misma base de datos.

-- ---------------------------------------------------------------------------
-- RA Fase 2 — LAS RACHAS **NO NECESITAN NADA NUEVO AQUÍ**. Se explica por qué,
-- para que nadie vuelva a plantearse crear tablas para ellas.
--
-- La especificación propone tablas `streaks` y `streak_days`, y acto seguido
-- dice: "No copies estos nombres obligatoriamente si el proyecto ya utiliza otra
-- convención" (apartado 3) y "No dupliques sistemas existentes. Si ya existe una
-- abstracción para acceso a Supabase, reutilízala" (apartado 1).
--
-- La convención de JosStyle es esta tabla: una fila por usuario y clave. Las
-- rachas usan la clave 'rachas', igual que las otras veinte. Consecuencias:
--
--   * Aislamiento entre usuarios (apartado 5): lo dan las cuatro políticas de
--     arriba, que ya cubren SELECT/INSERT/UPDATE/DELETE con `auth.uid() = user_id`.
--     Ninguna es del tipo permisivo `auth.uid() IS NOT NULL` que el apartado
--     prohíbe expresamente.
--   * user_id (apartado 4): el modelo de rachas **no tiene campo user_id**. El
--     cliente no puede elegir el de otro porque no manda ninguno.
--   * UNIQUE(streak_id, local_date) (apartado 6): se aplica en
--     `src/lib/rachasServicio.js`, el único sitio del proyecto que escribe
--     cumplimientos. El propio apartado lo admite: "siempre que encaje con el
--     modelo final".
--   * Contadores manipulables (apartado 11): no existen. Ni `current_streak` ni
--     `longest_streak` se guardan en ninguna parte; se derivan del historial.
--
-- Y una razón práctica: Josué ejecuta este archivo a mano desde el iPhone. Un
-- bloque más que fuera OBLIGATORIO para que las rachas funcionaran las dejaría
-- rotas hasta que lo ejecutara. Así no hay nada que ejecutar.
-- ---------------------------------------------------------------------------


-- ============================================================
-- Fase 3 — Salud: bucket de Storage privado para fotos de progreso.
-- Cada foto se guarda en una ruta "carpeta-del-usuario/archivo.jpg", y las políticas
-- de abajo solo dejan a cada usuario leer/escribir/borrar dentro de SU PROPIA carpeta.
-- El bucket es privado (public = false): las fotos se sirven con URLs firmadas de corta
-- duración desde el cliente, nunca con una URL pública fija.
-- ============================================================
insert into storage.buckets (id, name, public)
values ('progreso', 'progreso', false)
on conflict (id) do nothing;

create policy "Subir fotos propias"
on storage.objects for insert
with check (bucket_id = 'progreso' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Ver fotos propias"
on storage.objects for select
using (bucket_id = 'progreso' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Borrar fotos propias"
on storage.objects for delete
using (bucket_id = 'progreso' and (storage.foldername(name))[1] = auth.uid()::text);

-- Nota para quien ejecute esto: si ya ejecutaste la Fase 2 antes, solo hace falta
-- pegar y ejecutar ESTE bloque nuevo (desde "Fase 3" hacia abajo) — no hace falta
-- volver a ejecutar las líneas de arriba, que ya se crearon la primera vez.


-- ============================================================
-- Fase 5 — Calistenia a fondo: bucket de Storage privado para los vídeos de técnica.
-- Mismo patrón exacto que el bucket "progreso" de la Fase 3: privado, una carpeta por usuario,
-- URLs firmadas de corta duración (se usan también para extraer fotogramas en el navegador
-- antes de mandarlos a la IA — nunca se manda el vídeo entero a la IA, solo fotogramas sueltos).
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('entrenamiento-videos', 'entrenamiento-videos', false, 104857600, array['video/mp4', 'video/quicktime', 'video/webm'])
on conflict (id) do nothing;

create policy "Subir vídeos propios"
on storage.objects for insert
with check (bucket_id = 'entrenamiento-videos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Ver vídeos propios"
on storage.objects for select
using (bucket_id = 'entrenamiento-videos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Borrar vídeos propios"
on storage.objects for delete
using (bucket_id = 'entrenamiento-videos' and (storage.foldername(name))[1] = auth.uid()::text);

-- Igual que antes: si ya ejecutaste las fases anteriores, pega y ejecuta SOLO este
-- bloque de la Fase 5 — no hace falta repetir nada de lo de arriba.


-- ============================================================
-- Fase 11 — Biblioteca: bucket de Storage privado para PDFs, vídeos y fotos de referencia
-- (apuntes, material de instituto, etc). Mismo patrón exacto que "progreso" y
-- "entrenamiento-videos": privado, una carpeta por usuario, URL firmada de corta duración.
-- Un único bucket para los tres tipos de archivo — el tipo se guarda aparte, en el propio
-- registro de la app (clave "bibliotecaArchivos" en app_data), no en Storage.
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('biblioteca', 'biblioteca', false, 104857600, array['application/pdf', 'video/mp4', 'video/quicktime', 'video/webm', 'image/jpeg', 'image/png', 'image/webp', 'image/heic'])
on conflict (id) do nothing;

create policy "Subir archivos propios de biblioteca"
on storage.objects for insert
with check (bucket_id = 'biblioteca' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Ver archivos propios de biblioteca"
on storage.objects for select
using (bucket_id = 'biblioteca' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Borrar archivos propios de biblioteca"
on storage.objects for delete
using (bucket_id = 'biblioteca' and (storage.foldername(name))[1] = auth.uid()::text);

-- Igual que antes: si ya ejecutaste las fases anteriores, pega y ejecuta SOLO este
-- bloque de la Fase 11 — no hace falta repetir nada de lo de arriba.


-- ============================================================
-- Entrega 2 · AR Fase 1 — Armario: bucket de Storage privado para las fotos de
-- las prendas.
--
-- Mismo patrón exacto que 'progreso' (fotos de Salud) y 'entrenamiento-videos':
-- bucket privado, una carpeta por usuario, y URLs firmadas de corta duración
-- desde el cliente. Nunca una URL pública fija.
--
-- Josué: si ya ejecutaste los bloques anteriores, pega y ejecuta SOLO este.
-- Hasta que lo hagas, el Armario funciona entero **sin fotos** — la fotografía es
-- opcional por diseño; lo único que fallará es subir una imagen.
-- ============================================================
insert into storage.buckets (id, name, public)
values ('armario', 'armario', false)
on conflict (id) do nothing;

create policy "Subir prendas propias"
on storage.objects for insert
with check (bucket_id = 'armario' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Ver prendas propias"
on storage.objects for select
using (bucket_id = 'armario' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Borrar prendas propias"
on storage.objects for delete
using (bucket_id = 'armario' and (storage.foldername(name))[1] = auth.uid()::text);


-- ============================================================
-- Entrega 2 · FO Fase 2 — Fondos: bucket de Storage privado para la fotografía
-- que el usuario usa como fondo de la aplicación.
--
-- Mismo patrón exacto que 'armario', 'progreso' y 'entrenamiento-videos': bucket
-- privado, una carpeta por usuario, y URLs firmadas de corta duración desde el
-- cliente. Nunca una URL pública fija.
--
-- Va en su propio bucket y no dentro de 'armario' a propósito: son cosas
-- distintas con ciclos de vida distintos (una prenda se borra con la prenda; el
-- fondo se sustituye al elegir otra foto), y mezclarlas obligaría a distinguirlas
-- por convenio de nombre de archivo, que es exactamente el tipo de acuerdo
-- implícito que se rompe solo.
--
-- Josué: si ya ejecutaste los bloques anteriores, pega y ejecuta SOLO este.
-- Hasta que lo hagas, los fondos funcionan enteros **menos la fotografía** — el
-- color, el degradado y los fondos incluidos no tocan Storage para nada.
-- ============================================================
insert into storage.buckets (id, name, public)
values ('fondos', 'fondos', false)
on conflict (id) do nothing;

create policy "Subir fondos propios"
on storage.objects for insert
with check (bucket_id = 'fondos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Ver fondos propios"
on storage.objects for select
using (bucket_id = 'fondos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Borrar fondos propios"
on storage.objects for delete
using (bucket_id = 'fondos' and (storage.foldername(name))[1] = auth.uid()::text);
