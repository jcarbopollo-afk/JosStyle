# CHANGELOG.md

## v1.84.0 — EH Fase 20/65: barba y afeitado, y una pregunta para Josué

### ⏸ Lo primero: las Fases 18 y 19 están bloqueadas, y no las he resuelto por mi cuenta
Al abrir la Fase 18 (*Cuerpo e higiene*) aparecieron **dos prompts de Josué que dicen cosas
distintas**:

- Su **Fase 2**, en la lista de módulos, pone en 🧴 Cuidado **tres apartados**: *Skincare*,
  **Higiene** y **Cuidado corporal** — dos entradas separadas, cada una con su interruptor.
- El objetivo de la **Fase 18** dice *"la estructura será modular: 🚿 **Cuidado corporal e higiene**,
  y dentro aparecerán pequeñas plaquitas"*, y el apartado 1 de la **Fase 19** lo confirma:
  *"**dentro de** 🚿 Cuerpo e Higiene mostrar 🚿 Mi rutina"*.

Las dos lecturas rompen un prompt suyo: fundirlos **quita un módulo del catálogo que él escribió** y
que lleva en uso desde v1.60.0; mantenerlos separados deja el *"¿Qué quieres utilizar?"* del apartado
1, con sus siete casillas, **sin una pantalla donde vivir**. Es la **regla 49** exactamente: se anota
como **C-25** en `docs/03` con tres preguntas concretas, **se detiene la fase afectada y no la
sesión**, y se sigue por la 20.

*(Y hay un solape añadido que conviene decidir a la vez: dos de esas siete casillas son "Cuidado de
manos" y "Cuidado de pies", y la **Fase 22** se titula "Manos, uñas y pies: configuración".)*

### Qué se ha construido: Barba y afeitado
La entrada opcional, las seis casillas de *"¿qué quieres gestionar?"*, el perfil por secciones, sus
productos y la gestión de apartados. Se llega desde **Más → Estilo de hombre → Barba**.

### Las cinco decisiones que gobiernan la fase

**1. ⚠️ Nada nuevo se construye aquí.** El apartado 17 es una **lista de siete cosas que hay que
reutilizar** —perfil global, productos globales, calendario, recordatorios, favoritos y Eliminados
recientemente— y termina con *"no crear sistemas paralelos"*. Así que la fase es, casi entera,
llamadas: el motor de cuestionarios de la F7, el registro de datos de la F4, los inventarios de F10 y
F17 y los tres niveles de la F6. `auditarBarba()` declara **nueve ceros**.

**2. ⚠️ `sensibilidadPiel` no se vuelve a preguntar.** El registro de la Fase 4 ya la declaraba con
`usan: ['skincare', 'barba', 'productos']` — con **"barba" escrito dentro, siete fases antes de que
existiera este archivo**. Se lee, y la pantalla dice dónde se cambia. Lo que sí es nuevo es
`molestiaAfeitado` (apartado 10), que **no es la misma pregunta**: reaccionar a un producto y
molestarse tras pasar una cuchilla son dos cosas, y se puede tener lo primero sin afeitarse nunca.

**3. ⚠️ Los productos son los del catálogo global, y aquí solo se guardan IDS.** Un aftershave
registrado en Skincare se marca para la barba **sin duplicarse**; desmarcarlo **no lo borra** de su
módulo; y si lo borra allí, **aquí desaparece** — no se queda su nombre huérfano, que sería media
ficha guardada aquí, o sea el segundo inventario por la puerta de atrás.

**4. ⚠️ El formulario adaptativo se amplió EN EL MOTOR, no con un `if`.** El apartado 7 dice *"si
selecciona afeitado"*, y "afeitado" no es una respuesta: es una de las casillas del apartado 2, que
vive en la `config`. Así que `cuando` pasó a recibir **dos** cosas —las respuestas y un contexto del
módulo— y las preguntas de la Fase 13 siguieron funcionando **sin tocar ni una**. Era eso o volver a
meter la condición en el JSX, que es justo lo que la F13 sacó de ahí porque no se puede comprobar.

**5. ⚠️ `frecuenciaDeAfeitado()` es la única respuesta a "cada cuánto"**, como `frecuenciaDeCorte()`
en la F11: *"cuando lo necesito"* **es una respuesta** y no se traduce a días, *"Personalizado"* sin
cifra **no es una frecuencia todavía**, y el choque entre lo del perfil y lo puesto a mano **se
enseña** en vez de resolverse por él. Con las mismas trampas cubiertas: `Number(null)` es 0 y
`Number.isInteger(0)` es `true`.

### Nunca un diagnóstico
Los apartados 10 y 11 lo dicen los dos: *"no diagnosticar"* e *"información declarada por el usuario,
no un diagnóstico médico"*. `PALABRAS_CLINICAS` es **la lista de la Fase 13, importada** —no una
segunda—, y una prueba barre los 82 textos de esta fase. La ayuda de la pregunta de molestias tuvo
que reescribirse porque *"no es un diagnóstico"* **contiene la palabra**: octava vez que una
comprobación de este proyecto salta con algo que estaba bien dicho.

### Y un fallo real, cazado por la regla invariante
Al conectar la pantalla renombré un import y dejé `resumenBarba()` usada sin importar. `vite build`
**pasó igual** —no comprueba identificadores— y en el móvil habría sido un `ReferenceError` en
blanco: exactamente el fallo de `papelera.js` que tuvo la app rota durante meses.
`scripts/test-imports.mjs`, que existe por aquello, lo señaló con nombre y archivo.

### Verificación
`bash scripts/verificar.sh` — build de Vite, **141 comprobaciones nuevas**, **756 casos de
renderizado** (60 nuevos) y **61 comprobaciones en Chromium** sobre la aplicación de verdad: se llega
a Barba, se dice que sí, se dejan marcadas solo las casillas que quiere, **se escribe en Supabase**,
se abre el perfil —**sin las preguntas de afeitado, porque no marcó esa casilla**— y se contesta.

### Archivos
- **Nuevos:** `src/lib/perfilBarba.js`, `scripts/test-perfil-barba.mjs`.
- **Modificados:** `src/lib/cuestionarios.js` (el contexto del módulo en `cuando`),
  `src/views/EstiloHombreView.jsx` (cinco pantallas nuevas y la plaquita),
  `docs/03` (**C-25**), `scripts/smoke-vistas.jsx`, `scripts/test-app-real.mjs`,
  `scripts/verificar.sh`.

---

## v1.83.0 — EH Fase 17/65: productos, farmacia, Amazon y packs de skincare

### Qué se ha construido
El sistema de productos de Skincare, entero: ficha, categorías, tiendas, enlaces, recomendaciones
"Para ti", buscador, filtros, comparación, alternativas, valoración y packs. Se llega desde
**Más → Estilo de hombre → Skincare → 🛒 Productos**.

### Las cinco decisiones que gobiernan la fase

**1. ⚠️ El propio enunciado pedía el motor.** Su condición de finalización lo dice con estas
palabras: *"este sistema debe diseñarse de forma que podamos reutilizar exactamente la misma
arquitectura de productos para Pelo, Cuerpo, Higiene y otros módulos, **evitando crear cinco
catálogos diferentes**"*. La Fase 10 ya la había construido para el pelo, así que lo genérico se
extrajo a **`src/lib/motorProductos.js`** y los dos módulos lo usan. **Las 169 pruebas de la Fase 10
pasaron sin tocar ni una.** Tercer motor extraído de este bloque, después de `motorRutinas.js`
(F14) y `motorRecomendaciones.js` (F16).

Lo que **no** se comparte, a propósito: las categorías y **las filas de la tabla de comparación**.
La Fase 10 dibuja cuatro y la 17 dibuja cinco — son dos tablas distintas en dos enunciados
distintos, y forzarlas a compartir una habría sido inventarse una que no pide ninguno de los dos.

**2. ⚠️ UN inventario, el de la Fase 13.** El apartado 13 dice que *"Ya lo tengo" alimentará la
información de productos del usuario*: esa información **ya existía** —`datosPiel().productos`, que
creó F13 y usa F14 para enganchar productos a los pasos de una rutina—. Esta fase **la amplía**, no
crea otra. Hay una prueba de que un producto creado aquí lo ve `productosDePiel()` de la Fase 14.

**3. 🐛 Y ahí saltó el fallo de normalizador por DECIMOCTAVA vez, y de los caros.** `normalizarPiel`
recortaba cada producto a `{ id, nombre }`, que es lo que guardaba la Fase 13. Con la regla 5
(`saveData` sobrescribe), el siguiente guardado se habría llevado por delante marca, categoría,
precio, tiendas, objetivos, tipos de piel y valoración: la ficha entera, en silencio. Arreglado, con
cuatro pruebas que normalizan dos veces seguidas. `packs` también se declaró en `DEFAULT_PIEL`.

**4. ⚠️ El catálogo está VACÍO, y es D2-03.** *"Amazon: arquitectura sí, afiliación no. Ni catálogo,
ni productos, ni API, ni cuenta de afiliados inventados."* Se ha construido la arquitectura entera
—ficha, cinco tipos de tienda, enlace de afiliado, aviso de transparencia, packs, comparación,
alternativas, filtros y buscador— y **todo producto que existe lo ha metido él**. La pantalla lo
dice con una frase en vez de fingir una tienda. Y **nunca un enlace inventado** (apartado 4): una
"url" que no lo es se guarda como `null` y se dice que no hay enlace, en vez de fabricar una
búsqueda de Amazon "por si acaso".

**5. ⚠️ Amazon no es una limitación** (apartados 5 y 6). Un producto que solo está en la farmacia se
recomienda igual, y *"Disponible en farmacia"* es una respuesta completa aunque no haya ningún
enlace. El aviso de afiliación sale **solo donde hay afiliación** —ponerlo donde no la hay es tan
poco honesto como quitarlo donde sí—, y el usuario ve siempre la misma etiqueta: *"Ver producto"*.

### Y el apartado 22, que es el que cierra
*"Nunca comprar. Nunca añadir al carrito externamente. Nunca elegir por el usuario."* Cinco pruebas
sobre el código y tres ceros declarados en la auditoría. `packSugeridoPiel` **sugiere y no escribe**
—la prueba serializa el estado antes y después—, igual que `aplicarARutina`: es el sexto
`aplicarPlan` del proyecto.

### Un fallo de verdad, encontrado de paso
`CATALOGO_VACIO_PORQUE` estaba escrita **dos veces, palabra por palabra**, en `productosPelo.js` y
en `productosPiel.js`. Se mudó al motor, donde vive la decisión. Al hacerlo apareció un fallo real
que cazaron las pruebas de renderizado: **`export … from` no crea binding local**, así que el propio
archivo la usaba sin tenerla, y cuatro pantallas de Pelo reventaban con
`CATALOGO_VACIO_PORQUE is not defined`. Se importa y se reexporta la variable.

### Verificación
`bash scripts/verificar.sh` — build de Vite, **199 comprobaciones nuevas** en
`scripts/test-productos-piel.mjs`, **696 casos de renderizado** (13 nuevos, incluidos los de la
Fase 16, que no tenía ninguno) y **41 comprobaciones en Chromium** sobre la aplicación de verdad: se
llega a Productos desde Más → Estilo de hombre → Skincare, se crea un producto con su categoría y su
farmacia, **se escribe en Supabase con la ficha entera** y la pantalla lo enseña.

### Archivos
- **Nuevos:** `src/lib/motorProductos.js`, `src/lib/productosPiel.js`,
  `scripts/test-productos-piel.mjs`.
- **Modificados:** `src/lib/perfilPiel.js` (el normalizador y `DEFAULT_PIEL`), `src/lib/rutinasPiel.js`
  (la parte `productos` y su plaquita), `src/lib/productosPelo.js` (delega en el motor),
  `src/views/EstiloHombreView.jsx` (`ProductosPielEH` y su sitio en `PanelPiel`),
  `scripts/smoke-vistas.jsx`, `scripts/test-app-real.mjs`, `scripts/verificar.sh`.

---

## 🚨 v1.82.0 — LA APLICACIÓN NO ARRANCABA. Dos fallos fatales, y EH Fase 16/65

### Lo primero, porque es lo que importa
Josué dijo que **por más fases que se construyeran, al abrir la aplicación la veía prácticamente
igual**. Tenía razón, y la causa no era la documentación: **la aplicación no funcionaba**. Dos
fallos, los dos fatales, los dos invisibles para las 5 844 comprobaciones que había.

**1. `App.jsx` nunca importó `papelera.js`** (desde ME F3, v1.25.0). `purgarCaducados(...)` lanzaba
un `TypeError` **en mitad de la carga de datos**, y no hay `try/catch` en toda esa ruta. Todo lo que
venía después no llegaba a ejecutarse:

```
  línea 456   purgarCaducados(...)        ← TypeError
  línea 457   setPapelera(...)            ← nunca
  línea 464   setArmario(...)             ← nunca
  línea 471   setHorarioTop(...)          ← nunca
  línea 472   setEstiloHombre(...)        ← nunca
```

**Ningún módulo de la Entrega 2 cargaba sus datos guardados.** Cada arranque los dejaba en su valor
por defecto: por eso todo salía "sin configurar" y por eso lo que Josué configuraba parecía
desaparecer al recargar.

**2. Cinco hooks estaban DESPUÉS de los `return` condicionales de `App.jsx`** — la regla 4 del
proyecto, rota otra vez. En el primer render `session` es `undefined` y se sale por
`<LoadingScreen />`, así que esos hooks no se ejecutan; en cuanto llega la sesión, React encuentra
cinco hooks más que la vez anterior y lanza **"Rendered more hooks than during the previous
render"**, que **tumba la aplicación entera**.

Los dos están arreglados. Comprobado abriendo la aplicación en un navegador de verdad.

### ⚠️ Por qué ninguna prueba lo veía, y qué se ha hecho al respecto
**`App.jsx` no se renderizaba en ninguna prueba.** El build no comprueba identificadores, y las 648
pruebas de renderizado montan las *vistas*, no la aplicación — porque `App.jsx` necesita Supabase y
un navegador.

Ahora sí: **`scripts/test-app-real.mjs`** arranca Vite, abre la app en Chromium con la sesión y las
respuestas de Supabase simuladas, y comprueba la cadena entera:

**arranca → carga lo guardado → se llega al módulo → se toca → se guarda → se ve.**

25 comprobaciones, incluidas dos que existen solo para estos dos fallos: que no aparezca *"Rendered
more hooks"* y que no haya ningún *"is not a function"*. Playwright **no es dependencia del
proyecto** (Vercel no debe instalarlo): si no está, la prueba se salta con un aviso.

Y **`scripts/test-imports.mjs`**, la regla invariante que encontró el primer fallo, recorre los
1 319 nombres que exporta `src/lib/` y comprueba que los 38 archivos de `src/` importen los que usan.

### Lo que esto significa para las fases anteriores
**Estaban bien construidas.** Se ha comprobado en el navegador: Estilo de Hombre se abre desde Más,
carga los módulos que había guardados, el panel de Pelo enseña sus seis plaquitas (F7 a F12),
Peluquería abre con su frecuencia y su planificación, "Mi estilo de corte" está dentro, y registrar
un corte **escribe en Supabase y se ve en pantalla**. Lo que fallaba era el arranque, no las fases.

### EH Fase 16/65 — Skincare: motor de recomendaciones
Tercera fase que necesitaba reglas con `requiere`/`cuando`/`porque`: la 9 lo construyó para el pelo,
la 12 escribió su propia copia del mismo `if`, y ésta era la tercera. Lo genérico se ha extraído a
**`motorRecomendaciones.js`** y las tres lo usan — **las 146 pruebas de F9 y las 209 de F12 pasaron
sin tocar ni una**.

- ⚠️ **La aplicación nunca modifica la rutina** (apartados 4 y 11): `anadirARutina` exige
  `confirmado: true`, y calcular no escribe. Quinto `aplicarPlan` del proyecto.
- ⚠️ **La prioridad la marca él** (apartado 2) y pesa **sin tapar el resto**.
- ⚠️ **El nivel se respeta** (apartado 7); sin nivel elegido, se enseña todo.
- ⚠️ *"No quiero recomendaciones similares"* **calla el tema entero**, que es lo que significa.
- ⚠️ **Apartado 16**: seis pruebas de "sin IA" sobre el código, y cuatro ceros declarados.

### Y una prueba con fecha de caducidad, arreglada
`test-peluqueria.mjs` comparaba el "Hoy" de `registrarCorte` contra una fecha fija: pasaba el día que
se escribió y fallaba al siguiente. Ahora compara contra `todayISO()`, sea el día que sea.

### Verificación
`bash scripts/verificar.sh` — **6030 comprobaciones**, todas correctas: build de Vite, 160 nuevas
para EH F16, 648 casos de renderizado, 11 reglas invariantes y **25 comprobaciones sobre la
aplicación de verdad, en Chromium**.

## Entrega 2 · EH Fase 15/65 — Skincare: seguimiento y evolución (v1.81.0)

### 🐛 Un fallo real y grave, encontrado de paso: `App.jsx` nunca importó `papelera.js`
Al enganchar los registros de piel a la papelera desde `App.jsx`, escribí la llamada y **me olvidé
del import**. Como eso no lo ve nadie —JavaScript no comprueba los identificadores al compilar, y
`App.jsx` no se renderiza en las pruebas porque necesita Supabase— se ha escrito una **regla
invariante** que sí lo ve: `scripts/test-imports.mjs`.

En su primera ejecución encontró cinco cosas. Una era mía. **Las otras cuatro llevaban ahí desde
ME F3:** `DEFAULT_PAPELERA`, `purgarCaducados`, `prepararEliminacion` y `prepararRestauracion` se
usan en `App.jsx` **y nunca se importaron**.

`DEFAULT_PAPELERA` se usa en un `useState` de la línea 262, así que **la aplicación lanzaba un
`ReferenceError` en el primer render**. Es el tipo de fallo que sólo aparece en el iPhone de Josué, al
abrir la app — el peor sitio posible para descubrirlo.

Corregido con una línea. Y la regla se queda: recoge los 1319 nombres que exporta `src/lib/` y
comprueba, para cada uno de los 38 archivos de `src/`, que los que use estén importados ahí.

### ⚠️ No se crea otro diario
El apartado 11, con esas palabras: *"como ya existe el Diario general de JC Fitness, **NO** crear
otro diario de skincare"*.

Aquí solo viven *"los datos específicos necesarios para este módulo"*: una valoración, unos aspectos
y una nota corta —280 caracteres a propósito, porque el sitio para escribir es el Diario—. Hay una
prueba que lee este código y falla si aparece la palabra.

### ⚠️ No se crea otra papelera
El apartado 13: *"si JC Fitness ya tiene Eliminados recientemente, utilizar ese sistema en lugar de
crear otro"*. Y no hizo falta tocar el motor de ME F3: es genérico sobre la lista que se le pasa, así
que bastó con **una línea en `CATALOGO_PAPELERA`** — exactamente lo que ese archivo decía que haría
falta.

El borrado sale por `eliminarConPapelera`, la única puerta de borrado de la app. Cuando fue por un
atajo, **la auditoría de ME F4 lo cazó** —*"el catálogo describe colecciones sin borrado real"*— y
tenía razón: una colección en el catálogo sin un borrado visible es una entrada que nadie puede
comprobar.

### ⚠️ No se registra cada día
El apartado 9, que el propio enunciado marca como *"esto es importante"*: *"no crear 🔴 has perdido
tu racha, ni exigir registros diarios"*.

**Un día sin registrar no existe.** No es un cero, no se cuenta y no se menciona. Siete pruebas
barren todos los textos buscando "racha", "has perdido", "has fallado", "constancia" y "cada día", y
`resumenSeguimientoPiel` devuelve `racha: null` a propósito, con una prueba de que no hay ningún
cálculo de racha en el archivo.

### ⚠️ Las tendencias nunca afirman una causa
Apartado 7: *"no afirmar que un producto ha causado un resultado"*. Apartado 12: *"pero no establecer
causalidad médica. Simplemente mostrar los datos registrados."*

Se enseña *"Hidratación ↑ Mejorando"* y *"Desde que empezaste a utilizar X has registrado 4
valoraciones"*, y ahí se para — con una prueba que busca "gracias a", "ha mejorado tu", "funciona",
"ha causado", "provoca", "cura" y "por culpa".

**Con menos de cuatro registros no se afirma nada**, con la frase literal del apartado 8: *"todavía
no hay suficientes registros para mostrar una evolución"*. Y esa frase dice que faltan **datos**, no
que él haya fallado — hay una prueba de eso también.

**Medio punto de margen** para llamar a algo "mejorando": sin él, una diferencia de 0,1 entre cinco
registros se anunciaría como una mejora que no existe.

### ⚠️ Sin fotos y sin exportación propia
Apartado 10: nada de fotos, ni ahora ni como obligación. Apartado 14: *"no crear un sistema de
exportación independiente"* — `datosParaExportar()` **prepara** los datos con `exporta: false`
escrito en el propio dato, y no hay nada en el archivo que descargue.

### Un fallo propio, cazado por la prueba
`evolucionPiel` hacía `{ id: a.id, nombre: a.nombre, ...tendencia(t) }`, y **la tendencia también
tiene `id` y `nombre`** —'sube' y 'Mejorando'—, así que el spread se llevaba por delante los del
aspecto: la hidratación pasaba a llamarse "sube". Ahora los campos se copian uno a uno.

### Verificación
`bash scripts/verificar.sh` — **5844 comprobaciones**, todas correctas: build de Vite,
121 nuevas en `scripts/test-seguimiento-piel.mjs` (los trece tests del apartado 16 que no son
"comprobar móvil"), **648 casos de renderizado** (16 nuevos) y **una regla invariante nueva**.

⚠️ Y **la sexta vez en este bloque que una comprobación salta con algo que estaba bien**: los
barridos de "esto no existe" cazaban su propia evidencia (`fotos: 0` y `diariosNuevos: 0` viven
dentro de la función de auditoría), y el primer barrido de imports dio un falso positivo con la
cadena *"Mano dominante (opcional)"*. Mirar qué línea hace saltar la prueba antes de tocar el código.

## Entrega 2 · EH Fase 14/65 — Skincare: rutinas y cuidado diario (v1.80.0)

### ⚠️ El apartado 19 se titula "NO DUPLICAR", y esta fase pedía la máquina que ya existía
Pasos, frecuencia, lista del día, historial y eventos de calendario: exactamente lo que la **Fase 8**
construyó para el pelo, otra vez para la piel.

Copiar `rutinasPelo.js` habría sido el segundo sistema de siempre —y, peor, el segundo sitio donde
arreglar el mismo fallo—. Así que lo genérico se ha extraído a **`src/lib/motorRutinas.js`**, y los
dos módulos lo usan: Pelo pasa su catálogo de pasos, Skincare el suyo, y **el cálculo de qué toca hoy
es uno solo**.

**Las 171 pruebas de la Fase 8 son la red que demuestra que la extracción no cambió nada.** Pasaron
sin tocar ni una.

### ⚠️ La lista de frecuencias es de cada módulo; el comportamiento es del motor
La Fase 8 ofrecía cinco opciones y esta pide seis —*"Diario, Días concretos, Varias veces por semana,
Semanal, Cada X días, Personalizado"*—, pero **debajo solo hay cuatro reglas distintas**: todos los
días, unos días de la semana, cada X días, y ninguno por su cuenta.

*"Días concretos"*, *"varias veces por semana"* y *"semanal"* son tres formas de decir lo mismo. Se
guarda con su id propio —Josué eligió esa palabra y esa palabra se conserva— y cada una declara **de
qué tipo es**. Hay una prueba de que Pelo y Skincare dan **la misma respuesta al mismo caso**.

### ⚠️ Omitir no es fallar
El apartado 10: *"Un usuario puede decidir: 'hoy no quiero hacer este paso'. Debe poder marcarlo como
Omitir hoy. **Sin penalización**."*

Un paso omitido es una **tercera cosa**: no pendiente —eso sería el reproche que el apartado
prohíbe— y no hecho —eso sería mentir—. **Sale de la cuenta del día**, así que una rutina de tres
pasos con uno omitido y dos hechos está **hecha**, no a medias.

Y un paso no puede estar hecho y omitido a la vez: marcar quita lo uno, omitir quita lo otro.

### ⚠️ Los productos son los de la Fase 13
Apartados 6 y 19: *"si todavía no existe: + Añadir producto. **No crear un segundo inventario**."*

Un paso guarda el `id` de un producto que ya vive en el perfil de piel, y *"+ Añadir producto"*
**escribe allí** y luego lo engancha: dos escrituras, un solo inventario. Hay una prueba que lee este
código y falla si aparece una lista de productos propia.

### ⚠️ Las plantillas sugieren, no crean
Apartado 12: *"son plantillas, no obligaciones"*. Apartado 13: *"el usuario debe confirmar: Usar esta
rutina"*.

`plantillaSugerida()` devuelve una propuesta con `guardado: false` escrito en el propio dato y **no
escribe nada** —la prueba serializa el estado antes y después—. Crearla es `usarPlantilla()`, que
**sin `confirmado` no hace nada**. Cuarto `aplicarPlan` del proyecto, tras HT F9, EH F9 y EH F12.

Y la propuesta se adapta al perfil, que es lo que pide el apartado 13: si ha dicho que no usa
protección solar, ese paso no aparece en la propuesta. **Sin nivel elegido no se propone ninguna**:
elegir una por él sería decidir por él.

### ⚠️ Cambiar de nivel no borra la rutina anterior
El apartado 14, con esas palabras: *"cambiar de nivel no debe borrar la rutina anterior. Simplemente
modifica las opciones que se muestran."*

El nivel filtra **lo que se ofrece**, no lo que existe. Hay una prueba que crea una rutina con pasos
avanzados, baja el nivel a básico y cuenta las rutinas y los pasos antes y después.

**Sin nivel elegido se ofrece todo**: esconder opciones a quien no ha dicho nada es decidir por él.

### El seguimiento es una frase
Apartado 16: *"con información sencilla… no hace falta llenar la pantalla de estadísticas"*. Así que
es exactamente eso: *"Esta semana: 3 rutinas realizadas."*

Sin porcentajes, sin rachas, sin comparación con la semana pasada — con una prueba que busca todo
eso en el texto. Y **sin días en los que tocara no hay cumplimiento**, ni 0 ni 100, como en la Fase 8.

### El calendario es el que ya existe
Apartado 17: *"no crear un calendario de skincare independiente"*. Entra por `eventosDerivados`, con
la misma forma de evento que el Armario y las rutinas de pelo.

Un año de eventos no guarda ni una fecha (regla 11), y **ninguno es anterior al día en que la creó**:
una rutina no existe antes de existir.

### Verificación
`bash scripts/verificar.sh` — **5707 comprobaciones**, todas correctas: build de Vite,
148 nuevas en `scripts/test-rutinas-piel.mjs` (los diecisiete tests del apartado 20) y **632 casos de
renderizado** (28 nuevos). Y, sobre todo, las **171 de la Fase 8 intactas** tras el refactor.

## Entrega 2 · EH Fase 13/65 — Skincare: perfil de piel y configuración inicial (v1.79.0)

Empieza el bloque de Skincare, *"uno de los apartados importantes de Estilo de hombre"*. El enunciado
pone las reglas antes de pedir nada: **sin IA, sin diagnósticos médicos, el usuario decide siempre,
todo es opcional.**

### ⚠️ El apartado 15 ya era código, y ya estaba escrito
*"Antes de preguntar: comprobar la información ya registrada. Si un dato compatible ya existe:
reutilizarlo. No preguntar dos veces."*

**El registro de la Fase 4 ya declaraba `tipoPiel` y `sensibilidadPiel` como datos de esta fase**
(`desde: 13`), compartidos con Productos, Barba y Cuerpo — más `sinPerfume`, que usan Cuerpo y
Productos. Así que esas tres respuestas van solas a la capa compartida: **no hay un `if` que lo
decida**, lo decide `destinoDe()` mirando el registro.

Y funciona en las dos direcciones, con prueba: un `tipoPiel` que guardó Productos aparece aquí ya
contestado, y contestarlo aquí lo deja donde los demás módulos lo encuentran.

Esto es la diferencia entre una regla escrita en un documento y una regla que es una función. La
Fase 4 la escribió hace nueve fases; esta es la primera que la cobra entera.

### ⚠️ El formulario adaptativo vive en el motor, no en la pantalla
El apartado 14 pide *"no mostrar preguntas irrelevantes"*, con su ejemplo: *"si el usuario dice 'no
utilizo productos', no mostrar inmediatamente 15 preguntas sobre productos"*.

Se le ha añadido `cuando` a la forma de una pregunta y `preguntasVisibles()` / `progresoVisible()` a
`cuestionarios.js`. **Barba, Cuerpo, Manos y Perfumes van a querer exactamente lo mismo**, y una
pregunta que se esconde con un `if` en el JSX es una pregunta que nadie puede comprobar.

Cuatro de las trece preguntas están condicionadas, y el ejemplo del enunciado es una prueba.

### ⚠️ Y esconder no es borrar
Si dice que no usa productos, esas preguntas desaparecen **y sus respuestas de antes siguen
guardadas**; si mañana dice que sí, reaparecen contestadas. Es la regla 5 otra vez, aplicada a lo que
se ve en lugar de a lo que se guarda — y es lo que separa un formulario adaptativo de uno que castiga
por cambiar de opinión.

**El progreso cuenta lo visible.** Decirle *"has contestado 4 de 13"* de un formulario donde cuatro
preguntas no le aplican sería una nota inventada.

### ⚠️ Objetivos de cuidado, nunca un diagnóstico
El apartado 4 lleva la advertencia dentro: *"estas opciones son objetivos de cuidado, **no
diagnósticos**"*. Y el objetivo de la fase lo repite: *"sin diagnósticos médicos"*.

Por eso la pregunta es *"¿Qué te gustaría mejorar o cuidar?"* y **no** *"¿qué te pasa?"*. Hay una
prueba que recorre **todos** los textos de la fase —títulos, ayudas, opciones, secciones, frases—
buscando veinte palabras clínicas, y otra que comprueba que en ningún sitio se le pregunta qué le
pasa.

### ⚠️ Apartado 17 — esto no sale de aquí
*"Toda la información debe permanecer dentro del sistema de usuario. No enviar estos datos a una IA.
No crear perfiles externos."*

Siete pruebas sobre el código buscan `askAI`, `AI_SYSTEM`, `anthropic`, `fetch(`, `XMLHttpRequest`,
`openai` y `supabase`. El contexto que este módulo entrega a las fases 14-17 lleva `paraIA: false`
escrito en el propio dato, y `auditarPiel()` devuelve `perfilesExternos: 0`.

### Los niveles 🟢🟡🔴, otra vez importados
El apartado 9 lo dice literalmente: *"esto conecta directamente con el sistema de niveles"*. Así que
`COMPLEJIDADES_PIEL` toma los ids y los iconos de `NIVELES_ESTILO` (F6) con los nombres del enunciado
—Básica / Intermedia / Completa—. Segunda fase seguida que lo hace.

### Y una duplicación que NO lo era
El apartado 8 pregunta cuánto tiempo quiere dedicar a su cuidado, y se parece mucho a la del apartado
5 de la Fase 12, que sí resultó ser una repetición. **No lo es:** allí las opciones eran menos de 5 /
5–10 / 10–20 / más de 20 minutos y hablaban del pelo; aquí son menos de 2 / 2–5 / 5–10 / más de 10 y
hablan de la piel. Otra escala, otro asunto, otra pregunta — y hay una prueba que compara las dos
listas para dejarlo dicho.

### ⚠️ Lo que esta fase NO construye
El enunciado cierra con *"todavía no implementar esas funciones dentro de esta fase"*, refiriéndose a
rutinas, seguimiento, recomendaciones, productos, packs e integración.

`auditarPiel()` devuelve cinco ceros, y cinco pruebas buscan `crearRutina`, `recomendar`, `CATALOGO`,
`crearPack` y `aplicarA` en el archivo. Un producto aquí **es un nombre**: ni marca, ni precio, ni
tienda, ni valoración. Y la pantalla dice en qué fases llega lo demás, en vez de "próximamente"
(regla 8).

### Un vocabulario de estado, no dos
Sobre la marcha, el módulo tenía `estadoPerfilPiel` devolviendo las palabras del motor (`contestado`)
y `estadoDeEntrada` devolviendo las suyas (`configurado`). Dos nombres para lo mismo dentro del mismo
archivo es cómo se acaba comparando contra la palabra equivocada, así que se ha quedado uno: el que
sabe de *"Ahora no"* (apartado 1), que el motor no puede conocer.

### Verificación
`bash scripts/verificar.sh` — **5531 comprobaciones**, todas correctas: build de Vite,
227 nuevas en `scripts/test-perfil-piel.mjs` (los doce tests del apartado 18 que no son "probar
móvil") y **604 casos de renderizado** (28 nuevos).

## Entrega 2 · EH Fase 12/65 — Peluquería: cortes, preferencias y recomendaciones (v1.78.0)

### ⚠️ El apartado 5 ya estaba contestado, y no se vuelve a preguntar
El apartado 5 pide preguntar *"¿Cuánto tiempo quieres dedicar a peinarte?"* con cinco opciones:
menos de 5 min, 5–10, 10–20, más de 20, me da igual.

**La Fase 7 ya hizo esa pregunta** (`tiempoPelo`) **con esas cinco opciones exactas**, y dejó escrito
para qué servía: *"así las recomendaciones futuras no propondrán una rutina de 20 minutos a alguien
que quiere tardar 3"*. Esta fase la quiere justamente para eso.

Volver a preguntarla habría dejado a Josué con **dos respuestas a la misma pregunta y ninguna forma
de saber cuál manda** — que es exactamente el fallo que el apartado 10 de la Fase 1 existe para
evitar, y que en este proyecto ya es código (`FUENTES_GLOBALES`, `esDatoGlobal()`, `destinoDe()`).

Así que se **lee** de allí, y la pantalla dice dónde se cambia: *"lo dijiste en Pelo → Mi pelo, ahí
se cambia"*. Cuatro pruebas lo sostienen: que la pregunta de F7 tiene esas cinco opciones, que F12
**no** la repite, que no la repite con otro nombre, y que lo contestado allí llega hasta aquí.

**Queda anotado como D-15 en `docs/03`.** No activa la regla 49: esa regla detiene una fase ante una
*contradicción* sin decisión tomada, y aquí no hay contradicción —los dos enunciados quieren lo
mismo— ni falta decisión.

⚠️ **Consecuencia visible para Josué: el perfil de corte tiene seis preguntas, no siete. La séptima
no falta — ya está contestada.**

### ⚠️ Los niveles 🟢🟡🔴 se importan de la Fase 6
El apartado 6 pide tres niveles de mantenimiento con esos tres iconos. `NIVELES_ESTILO` (F6) ya es
esa escala, y las fases 9, 18 y 22 la comparten.

`NIVELES_MANTENIMIENTO` toma **sus ids y sus iconos** —para que un nivel siga significando lo mismo
en todo el proyecto— con **los nombres que escribió Josué**: Bajo / Medio / Alto, no Básico /
Intermedio / Avanzado. Reescribir la escala habría creado dos escalas de tres niveles.

### Añadir un corte es añadir una línea
Mantenimiento, minutos, longitudes, tipos de pelo y estilos compatibles van EN LA LÍNEA del catálogo,
como `MODULOS_EH` en la Fase 1 y `REGLAS_PELO` en la Fase 9. El motor no lleva un `if` por corte.

Y *"la lista debe ser ampliable"* (apartado 3) es ampliable de verdad: los cortes que añade Josué
salen mezclados con los nueve del enunciado **y llegan hasta la pregunta de estilos**, porque la
pregunta lee el catálogo en vez de una copia congelada al importar el archivo.

### ⚠️ Nada sin confirmar
El apartado 18 enumera cinco cosas que la aplicación nunca hace sola: cambiar el corte actual, crear
una cita, modificar el calendario, añadir un producto y cambiar preferencias.

Mirar recomendaciones, comparar, ver patrones y abrir el panel **no cambian ni un byte del estado**,
con una prueba que lo serializa antes y después. Guardar un favorito, fijar el corte actual y marcar
un objetivo son tres llamadas distintas, y las hace él.

Y una que no es obvia: **el corte que ya lleva no se le recomienda**. Eso no es una recomendación.

### ⚠️ El historial no diagnostica
El apartado 15 pide detectar patrones *"sin presentarlo como diagnóstico ni como una conclusión
absoluta"*. Con **un** corte valorado bien no se afirma nada; hacen falta dos, y entonces la frase es
la del enunciado: *"parece que este estilo encaja bastante con tus preferencias"*.

Misma disciplina que `frecuenciaReal` (F11), la analítica del Horario (HT F11) y las estadísticas del
Armario (AR F4). Y un corte que **no** le gustó no entra en el patrón por mucho que se repita.

### Sin IA, y sin "el mejor corte para ti"
Como la Fase 9, comprobado sobre el código: seis pruebas buscan `askAI`, `anthropic`, `fetch(`,
`XMLHttpRequest` y `openai`.

La frase que el enunciado prohíbe expresamente —*"este es el mejor corte para ti"*— tiene su propio
guardián, porque no lleva ninguna palabra de la lista de la Fase 9. Todos los textos que el motor
puede generar se comprueban contra **las dos** listas.

### El objetivo entra en el evento que ya existe
*"🎯 Quiero probar"* (apartado 12) sale en el calendario dentro de la `notas` de la cita de la Fase
11 — no en una clave nueva, que rompería la forma común con los eventos del Armario y las rutinas, y
desde luego no en un segundo evento (apartado 6). Y lleva su nombre encima, así que borrar el corte
del catálogo no lo deja apuntando a un fantasma.

### ⚠️ El normalizador, décima vez — y otra vez cazado en el mismo turno
`normalizarPelo` no conocía el campo `corte`, así que **lo descartaba en cada lectura**: añadir un
corte y guardar una referencia no tenían ningún efecto. Lo encontró la prueba en el mismo turno en
que se introdujo, como en las fases 9, 10 y 11.

`corteId`, `valoracion` (en `normalizarCorte`) y `objetivo` (en `normalizarPeluqueria`) son el
undécimo, duodécimo y decimotercero.

### Verificación
`bash scripts/verificar.sh` — **5276 comprobaciones**, todas correctas: build de Vite,
209 nuevas en `scripts/test-cortes-pelo.mjs` (los doce tests del apartado 19, más el apartado 5, más
el apartado 18 byte a byte) y **576 casos de renderizado** (24 nuevos).

**Y dos comprobaciones de fases anteriores que saltaron con algo que estaba bien:** la cuenta exacta
de colecciones de `DEFAULT_PELO` (F8) y la de llaves de `DEFAULT_PELUQUERIA` (F11), las dos ampliadas
legítimamente por esta fase. La segunda se ha reescrito para comprobar **lo que de verdad guarda**
—que `cortes` y `cita` sigan siendo dos cosas— en vez de contar llaves. Quinta vez en este bloque.

## Entrega 2 · EH Fase 11/65 — Peluquería: calendario y seguimiento de cortes (v1.77.0)

### ⚠️ La decisión que gobierna la fase entera
El apartado 15, literal: *"Esto eliminará el evento del calendario, **pero no el historial del
corte**."*

Un corte planificado y un corte que ocurrió **no son la misma cosa**, así que no viven en la misma
lista. `cortes` es la historia; `cita` es el plan. Borrar la cita no puede tocar un corte **porque
no tiene manera de hacerlo**, y hay una prueba que cuenta los cortes antes y después de borrarla.

Un solo array con un campo `hecho` habría puesto las dos cosas a un `filter` de distancia, y ese
`filter` habría llegado tarde o temprano.

### ⚠️ Una sola respuesta a "cada cuánto te lo cortas"
`frecuenciaDeCorte()` hace exactamente lo que `tallaDe()` en la Fase 5: **lo que ya contestó en el
perfil capilar (F7) manda**, lo que ponga a mano rellena el hueco, y **si los dos existen y no
coinciden se enseña el choque** en vez de elegir en silencio.

*"Cuando lo necesito"* es una respuesta legítima que sencillamente no permite calcular una fecha. Se
dice —*"sin frecuencia fija"*— y **no se inventa una por defecto**: un valor puesto para llenar el
hueco habría empezado a proponer fechas que él nunca pidió.

### ⚠️ Sugerir no es reservar
`sugerirProximoCorte()` devuelve *"tu próximo corte podría ser alrededor del…"* con `guardado: false`
escrito en el propio dato. Guardarlo es `planificarCorte`, y esa la llama él tocando un botón.

Tercera vez que aparece el mismo patrón: `aplicarPlan` (HT F9), `aplicarARutina` (EH F9) y ahora
esto. El apartado 16 lo pide con esas palabras: *"no reservar ni crear automáticamente nada sin que
el usuario lo confirme"*.

### ⚠️ Decide aquí, manda `notificaciones.js`
`avisoDeCorte()` dice **qué habría que avisar y cuándo**; quien emite sigue siendo el emisor único
del proyecto, con su permiso, su interruptor global y su horario de descanso. Mismo reparto que
`avisosHorario.js` en el Horario. Un segundo emisor daría dos avisos.

El recordatorio **nace apagado** (apartado 5: *"nunca activarlos de forma invasiva"*), y el apartado
13 se cumple literalmente: **el calendario funciona sin recordatorios**, son dos cosas
independientes, y la pantalla lo dice — *"salga o no el aviso, el corte sigue en tu calendario"*.

### Desactivar oculta, no borra
`impactoDesactivarPeluqueria()` avisa de la cita futura **antes** de apagar y devuelve
`seBorraAlgo: false`. Reactivar lo devuelve todo: historial, sitios, preferencias y la propia cita.
Es el apartado 14, y es también la regla de siempre: apagar no es cancelar.

### Los sitios no son un sistema de reservas
El apartado 12 lo dice: *"no crear todavía un sistema completo de reservas de peluquería"*. Así que
un sitio es **un nombre, un lugar y una nota**. Ni horarios, ni teléfonos, ni disponibilidad. Y la
pantalla lo dice —*"aquí solo se apunta dónde vas"*— en vez de dejar un botón muerto (regla 8).

Borrar un sitio **desengancha** los cortes que lo usaban; no los borra.

### El calendario que ya existe
`eventosDePeluqueria()` devuelve el evento con la misma forma que los del Armario y los de las
rutinas de F8, y entra por `eventosDerivados` como todo lo demás: **derivado y de solo lectura**
(regla 11). **Una cita, no una serie** — el próximo corte es un plan concreto, así que a diferencia
de las rutinas no necesita rango. Hay cinco comprobaciones sobre el enchufe en sí, no sobre la
función: `eventosDePeluqueria` puede funcionar perfectamente y no salir en ningún sitio si nadie la
llama.

### Dos fallos silenciosos que encontró la prueba
1. **`planificarCorte({modo: 'semanas'})` sin cantidad planificaba el corte para HOY.** `Number(null)`
   es `0` y `Number.isInteger(0)` es `true`, así que la comprobación pasaba y `addDays(hoy, 0)`
   devolvía hoy. Sin error, sin aviso: una cita para esta tarde.
2. **`'25:99'` encajaba con `/^\d{2}:\d{2}$/`** y se guardaba como hora de la cita. La forma no
   basta: ahora se comprueban las horas y los minutos.

### La frecuencia real, derivada
`frecuenciaReal()` mira los intervalos entre cortes y dice *"de media te lo cortas cada N semanas"*.
**Con menos de dos intervalos no afirma nada** — misma disciplina que HT F11 y AR F4 —, y en el corte
más antiguo `diasDesdeElAnterior` es `null`, no `0`: no hay con qué compararlo.

### Verificación
`bash scripts/verificar.sh` — **5041 comprobaciones**, todas correctas: build de Vite,
189 nuevas en `scripts/test-peluqueria.mjs` (los catorce tests del apartado 17, más los dos fallos
silenciosos, más el enchufe al calendario) y **552 casos de renderizado** (28 nuevos).

⚠️ **`peluqueria` es el noveno campo que se enseña a un normalizador en este proyecto.** Tercero
seguido que se recuerda a la primera.

## Entrega 2 · EH Fase 10/65 — Pelo: productos, catálogo y recomendaciones (v1.76.0)

### ⚠️ La decisión que gobierna la fase entera
El enunciado habla de catálogo, de Amazon y de afiliación. **D2-03 de Josué** dice: *"Amazon:
arquitectura sí, afiliación no. Ni catálogo, ni productos, ni API, ni cuenta de afiliados
inventados."*

**No hay contradicción que resolver: el propio enunciado dice lo mismo.** Apartado 3: *"No llenar
todavía la aplicación con cientos de productos manualmente en esta fase."* Apartado 11: *"**No poner
enlaces inventados**."*

Así que se construye **la arquitectura entera** —la ficha con sus doce campos, las cinco clases de
tienda, la distinción entre enlace normal y de afiliado, el aviso de transparencia, los packs, la
comparación, los favoritos, "ya lo tengo" y la valoración— y **el catálogo está vacío, declarado
vacío y comprobado vacío**.

Todo producto que existe en la aplicación lo ha metido él (apartado 9). El día que haya catálogo,
entra por `CATALOGO_PELO` sin tocar nada más.

### ⚠️ Nunca un enlace inventado
Una "url" que no lo es se guarda como `null`, y la pantalla **dice que no hay enlace** en vez de
fabricar una búsqueda de Amazon "por si acaso" — que es inventarse un enlace con otro nombre.

Hay una prueba de que **no aparece ni una URL literal ni un dominio de tienda ni una etiqueta de
afiliado en todo el código**.

### ⚠️ Nunca una compra automática
El apartado 19: *"La aplicación únicamente: recomienda → muestra información → ofrece enlace →
usuario decide."*

Cinco pruebas buscan funciones de "comprar", "checkout", "carrito", "pagar" y "pedido". Lo más lejos
que llega esto es un objeto con la URL que él guardó.

Y el apartado 12: **el usuario ve siempre "Ver producto"**, lleve el enlace la marca que lleve. El
aviso de transparencia —*"Algunos enlaces pueden ser enlaces de afiliado"*— sale **solo si alguno lo
es**. Poner el aviso donde no hay afiliación es tan poco honesto como quitarlo donde sí la hay.

### No disponible no es borrado
El apartado 10: *"Si un producto deja de estar disponible: **no eliminarlo automáticamente del
historial**."* Se marca, se avisa y se ofrecen alternativas de entre los suyos.

Y una que no es obvia: **una alternativa que tampoco está disponible no se ofrece**.

### ⚠️ Una sola lista de productos
La Fase 8 creó una con nombre y paso. Esta le ha añadido marca, categoría, descripción, para qué
sirve, características, nivel, precio, tiendas, estado, valoración y opinión — **en la misma lista**.

*"No duplicar productos"* está en la lista de pruebas del apartado 20, y dos listas de productos
capilares es exactamente cómo se incumple. Mismo nombre y misma marca es el mismo producto, aunque
cambien las mayúsculas.

### El precio lleva su fecha
El apartado 16: *"si el precio puede cambiar, no tratarlo como un dato permanente"*. Así que viaja
con `precioAnotado`, y se re-sella al cambiarlo.

### ⚠️ El pack sugerido sugiere, no crea
El apartado 15 pide que el sistema pueda armar packs por reglas. `packSugerido` devuelve una
propuesta — y hay una prueba de que **el estado no cambia**. Guardarlo es `crearPack`, y eso lo hace
él, igual que `aplicarARutina` en la Fase 9.

### Las recomendaciones se apagan, los productos siguen
El apartado 18 lo dice con esas palabras, y hay una prueba de las dos mitades: con las
recomendaciones apagadas no sale ninguna, **y los tres productos siguen ahí**.

### `packs` es el octavo campo que se enseña a un normalizador
Y como en la Fase 9, el que se olvidó lo cazó la prueba en el mismo turno. La costumbre está
funcionando.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **4 295 comprobaciones unitarias**, 5 de
auditoría, **524 casos de renderizado real** y 10 reglas invariantes — **4 824 en total**. De ellas,
**169 nuevas** para EH F10.

---

## Entrega 2 · EH Fase 9/65 — Pelo: sistema de recomendaciones (v1.75.0)

### El enunciado abre con dos palabras en mayúsculas
**NO IA.** *"Las recomendaciones deben salir de la información que ya tenemos guardada y de reglas
internas de la aplicación. El usuario siempre tiene la última palabra."*

Seis pruebas buscan `askAI`, `AI_SYSTEM`, `anthropic`, `fetch(`, `XMLHttpRequest` y `openai` en el
código. Se comprueba sobre el archivo, no sobre la buena voluntad.

### ⚠️ Si un dato no existe, no se asume
Es el apartado 2, y es la diferencia entre un motor de reglas y uno que se inventa cosas.

Cada una de las catorce reglas declara **qué necesita saber**. Si falta algo, no se dispara. Con el
perfil vacío salen **cero** recomendaciones.

Y una comprobación que no es obvia: **una regla sin requisitos declarados no se aplica nunca**. Si se
permitiera, se dispararía con el contexto vacío y acabaría recomendándole cosas a alguien de quien no
sabemos nada — el fallo silencioso de este tipo de motor.

**"No lo sé" tampoco es un valor**: es la ausencia declarada de uno (Fase 7), así que no dispara nada.

### ⚠️ Nunca "debes"
El apartado 4: *"Nunca 'Debes hacer esto'. Utilizar: Podría venirte bien / Podrías probar / Una opción
compatible contigo."*

Hay una prueba que genera **todos** los textos posibles del motor —con el perfil entero contestado y
con el de ejemplo— y busca diez imperativos. Y comprueba que **sí** aparecen las fórmulas del
enunciado. Y, como en la Fase 7, que no se diagnostica nada.

### ⚠️ Una recomendación no modifica nada
El apartado 10: *"Una recomendación no debe modificar rutina, productos, preferencias ni
calendario."*

`aplicarARutina` **exige `confirmado: true`**, y la prueba serializa el estado antes y después para
comprobar que **no ha cambiado ni un byte**. Es la regla 7 del proyecto en código, igual que
`aplicarPlan` en HT F9. Nunca darle un valor por defecto.

Y calcular recomendaciones tampoco escribe: **mostrar y registrar que se ha mostrado son dos llamadas
distintas**, para que repintar una pantalla no ensucie el historial.

### Los ejemplos del enunciado son reglas con su id
- *"Si pelo = rizado + objetivo = definición"* → `definicion_rizado`.
- *"Si cuero cabelludo = graso"* → `cuero_graso`.
- *"Buscas hidratación y tu rutina tiene pocos pasos de hidratación"* → `hidratacion_sin_paso`, que
  **mira de verdad los pasos de su rutina**.

Y el tiempo disponible entra en las reglas, no en el texto: la mascarilla semanal solo se propone a
quien ha dicho que puede dedicarle más de diez minutos. Es para lo que servía esa pregunta de la
Fase 7.

### Los niveles vienen de la Fase 6
El apartado 6 dice *"utilizar los niveles que ya hemos definido"*, y eso es lo que se hace: se
importan 🟢🟡🔴, no se redefinen. Hay una prueba de que no aparece un `const NIVELES` aquí, y otra de
que **hay reglas en los tres** — un nivel vacío sería un control decorativo.

### Descartar tiene memoria, pero con caducidad
*"No me interesa"* calla 30 días, *"ya lo hago"* 90, y **"no quiero verlo" es para siempre** — por eso
es el único de los cuatro sin plazo asignado: "para siempre" no es un número de días.

Y todo se puede deshacer. Un toque no condena una recomendación.

### ⚠️ Un fallo real, encontrado en el mismo turno
`normalizarPelo` (Fase 8) no conocía el campo `recomendaciones`, así que **lo descartaba en cada
lectura**: descartar o guardar una recomendación no tenía ningún efecto.

Es la **séptima vez** que este proyecto se topa con el mismo fallo de normalizador, y la primera en
que se detecta en el turno en que se introduce, en lugar de fases después.

### El apartado 9 pide integrar el sistema global de guardados "si existe"
**No existe.** Nutrición y los colores tienen cada uno los suyos, y no hay ninguno general. Así que
los guardados de pelo viven en la `config` de Pelo, y queda dicho para que la fase que cree el global
sepa que tiene que absorberlos.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **4 126 comprobaciones unitarias**, 5 de
auditoría, **504 casos de renderizado real** y 10 reglas invariantes — **4 635 en total**. De ellas,
**146 nuevas** para EH F9.

---

## Entrega 2 · EH Fase 8/65 — Pelo: rutina, cuidados y seguimiento (v1.74.0)

### La filosofía, que el propio enunciado escribe
*"La aplicación recomienda y organiza; el usuario decide. No vamos a convertirlo en una obligación ni
en un sistema médico."*

### ⚠️ No castigar, y probado en el peor escenario
El apartado 7 lo dice sin rodeos: *"No queremos 'Has fallado'. Simplemente 'Pendiente'."*

Un día sin hacer la rutina **no es un día perdido**. Hay una prueba que monta el peor caso posible
—una rutina diaria abandonada durante dos meses— y recorre **todos** los textos que el módulo genera
buscando "fallado", "fallo", "perdido", "deberías", "mal", "incumplido", "abandonado", "racha rota" y
"castigo". Nueve comprobaciones sobre el mismo escenario.

Y una consecuencia que no es obvia: **sin días en los que tocara, no hay cumplimiento** — ni 0 % ni
100 %. Una rutina "personalizada", que Josué hace cuando quiere, no puede salir con un 0 %: decir eso
de algo que nunca tocó es exactamente el reproche que el apartado prohíbe.

### ⚠️ Nada se materializa
El apartado 17: *"No crear un segundo calendario. Debe utilizarse el calendario existente."* Y la
regla 11 del proyecto dice lo mismo para cualquier recurrencia.

Una rutina "cada 3 días" guarda **su regla**, no cien fechas. La prueba pide **un año entero** de
eventos, comprueba que salen más de cien… **y que el estado guardado sigue por debajo de 3 KB**.

El efecto: cambiar la frecuencia cambia los eventos al momento, porque no hay nada que sincronizar.

Las rutinas entran en el Calendario con **la misma forma** que los usos del Armario, así que encajan
sin adaptadores.

### ⚠️ Ni un contador guardado
Cuántas veces la ha hecho, cuántos días le tocaba, el cumplimiento — todo se deriva del historial. Un
contador guardado miente en cuanto Josué borra un registro. Hay una prueba de que la rutina guardada
no lleva ninguna cifra acumulada.

Y el estado de hoy también es derivado: **marcada ayer no significa marcada hoy**.

### Lo que no se construye, y está declarado
- **Sin gamificación** (D2-02 de Josué): ni XP, ni niveles, ni medallas.
- **Sin fotos** (apartado 10): *"no crear una galería fotográfica obligatoria"*.
- **Sin catálogo de productos** (apartado 11 + D2-03): un producto aquí es **un nombre que él
  escribe**. Seis pruebas buscan "amazon", "afiliad", "precio", "comprar", "http" y "marca:".
- **Sin recomendaciones** (apartado 13): existe la estructura, que declara las seis fuentes que
  usará y que llega en la fase 9.

### Recordatorios nace apagado
El apartado 5: *"nunca deben ser obligatorios"*. Y el enunciado lo dibuja así — `☐ Recordatorios` —
así que es la única de las cuatro partes que empieza en off.

### Dos cosas pequeñas que evitan sustos
**Borrar una rutina dice antes qué se lleva por delante**: *"se borrará X y 3 días registrados"*. Y
**borrar un producto desengancha** los pasos que lo usaban, no los borra.

### ⚠️ Otra prueba mal escrita, corregida
Los barridos de *"esto NO existe"* cazaban su propia evidencia: `fotos: 0` y `xp: 0` viven dentro de
`auditarPelo()`, que es justo la función que **declara los ceros**. Ahora el barrido excluye esa
función.

Es la tercera vez en este bloque que una comprobación salta con algo que estaba bien. Conviene mirar
**qué línea** la hace saltar antes de tocar el código: dos de las tres veces, el código era correcto
y la prueba estaba mal.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **3 979 comprobaciones unitarias**, 5 de
auditoría, **488 casos de renderizado real** y 10 reglas invariantes — **4 472 en total**. De ellas,
**170 nuevas** para EH F8.

---

## Entrega 2 · EH Fase 7/65 — Pelo: perfil capilar y necesidades (v1.73.0)

### La primera fase que pregunta cosas de verdad
Y no será la última: Skincare (13), Cuerpo (18), Barba (20), Manos (22) y Perfumes (24) traen cada
una su propio cuestionario de perfil.

Así que lo que se construye es **el motor** (`cuestionarios.js`), y las doce preguntas de Pelo son su
primera configuración. Están en un array; las fases siguientes traerán el suyo **sin tocar una línea
de aquí**.

### ⚠️ El motor no guarda nada por su cuenta
Cada respuesta va a uno de los dos sitios que ya existen, y la elección es una regla, no un `if`
suelto:

- **Si el dato está en `REGISTRO_DATOS`** (Fase 4), va allí. Eso significa que lo comparten varios
  módulos — `tipoPelo` lo usan Pelo y Productos — y por tanto **no se puede volver a preguntar**.
- **Si no está**, es solo de ese módulo y va a su `config` (Fase 1, apartado 8: *"configuración
  específica futura"*), que `alternarModulo` **nunca toca**.

De las doce preguntas, **solo `tipoPelo` es compartida**.

Esa única decisión es la que hace pasar los Tests 7, 8 y 9 a la vez. Y si estuviera mal, **nada
reventaría**: simplemente Productos volvería a preguntar el tipo de pelo, o apagar Pelo se llevaría
once respuestas. Por eso hay pruebas de las tres cosas.

### ⚠️ "No lo sé" es una respuesta, no un hueco
El apartado 14 lo dice con esas palabras: *"Nunca obligar a inventar una respuesta."* Así que:

- **Se guarda, y cuenta como contestada.** No es lo mismo que no haber respondido: *"no lo sé"* es
  información —se le puede ofrecer contenido educativo— y *"aún no ha llegado"* no lo es.
- **Es exclusivo.** Marcarlo borra lo demás, y marcar algo de verdad lo quita. *"Cuero cabelludo
  graso y no lo sé"* es un estado imposible que luego nadie sabe interpretar.
- **Por defecto toda pregunta lo admite.** El valor por defecto tiene que ser el que no obliga a
  inventar. Solo se quita donde el enunciado no lo ofrece: preguntar cada cuánto se corta el pelo ya
  tiene su *"Cuando lo necesito"*.

### ⚠️ "No diagnosticar problemas"
Es el apartado 7, y se cumple en la forma de las preguntas: se pregunta **qué quiere cuidar**, no qué
le falla. Hay siete pruebas que buscan "caspa", "alopecia", "calvicie", "problema", "diagnos",
"enfermedad" y "sintoma" en el código.

Un chaval de 16 años no necesita una aplicación diciéndole que tiene un problema.

### Ni calendario, ni productos, ni recomendaciones
El enunciado lo prohíbe tres veces (apartados 11, 12 y 17). Hay pruebas de que no se define ninguno
— **pero sí se dice cuándo llegan**, que es la regla 8: *"Se usará para el calendario de peluquería,
que llega en la fase 11."*

### ⚠️ Una prueba mal escrita, corregida
La primera versión de esa comprobación prohibía la **palabra** "calendario" en todo el archivo, y
saltaba justo con la frase que le dice a Josué cuándo llega. Ahora comprueba que no se **defina**
ninguno, y además comprueba que **sí se diga cuándo llega**.

Una prueba que castiga la honestidad está mal escrita, y arreglarla es más barato que descubrir dentro
de diez fases que se dejó de explicar nada por no hacerla saltar.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **3 809 comprobaciones unitarias**, 5 de
auditoría, **448 casos de renderizado real** y 10 reglas invariantes — **4 262 en total**. De ellas,
**118 nuevas** para EH F7. El **Test 10** (flujo en móvil) necesita un iPhone: **R1**.

---

## Entrega 2 · EH Fase 6/65 — Perfil de estilo y preferencias personales (v1.72.0)

### La diferencia, en una línea
*"Armario → qué prendas tiene el usuario. Perfil de estilo → qué le gusta, qué quiere conseguir y
qué tipo de imagen quiere transmitir."*

Y va **dentro** de Estilo y Armario (apartado 1: *"no crear otro apartado principal"*), no como un
módulo nuevo del catálogo.

### ⚠️ Once campos y ningún almacén propio
Todo el perfil se guarda en **la capa de datos de la Fase 4**, con una línea por preferencia en el
registro. No es por ahorrar: **`estilosFavoritos` y `coloresFavoritos` ya existían** desde la Fase 5.
Crear aquí unos paralelos habría dado dos listas de estilos favoritos que se separan con el tiempo, y
el Test 9 de esta fase dice literalmente *"comprobar que no se duplica la información"*.

El efecto secundario bueno: el panel **Mis datos** enseña el perfil entero sin que nadie lo enchufe, y
`hayQuePreguntar()` ya sabe que Productos no tiene que volver a preguntar los colores.

### Tres listas se toman prestadas y no se declaran
Los colores son `COLORES_ARMARIO` (apartado 4: *"no duplicar el sistema de paletas si ya existe"*),
las marcas salen de sus propias prendas (apartado 5: *"reutilizar las marcas existentes"*) y las
ocasiones son `OCASIONES_OUTFIT` (apartado 6). Hay pruebas que leen el código y fallan si aparece una
lista nueva.

### ⚠️ Los niveles nacen aquí
El apartado 10 dice *"mantener el sistema de niveles que ya definimos"* (🟢 Básico 🟡 Intermedio
🔴 Avanzado). En la especificación se definen en las fases 18 y 22 — que en orden de construcción
todavía no existen. Así que se definen **una vez, aquí**, y esas fases los importarán en vez de
escribir los suyos. El día que alguien teclee `['Básico', 'Intermedio', 'Avanzado']` por su cuenta,
habrá dos listas.

### ⚠️ Un perfil vacío es un perfil válido
El Test 7 es exactamente eso: *"no rellenar ningún campo → el módulo sigue funcionando"*. Así que:

- No hay barra de progreso, ni porcentaje, ni la palabra "incompleto". Hay una prueba que lo busca.
- **Quitar el último valor borra el dato**, en vez de guardar `[]` y decir después "no lo has
  indicado". Guardar una lista vacía y llamarla "sin indicar" es mentir a medias.
- Con el perfil vacío, el motor de reglas devuelve **cero reglas**, no un error.

### ⚠️ "Lo que refleja tu armario" no clasifica prendas
El apartado 14 pide *"Tu armario refleja principalmente: Deportivo · Casual · Minimalista"*. La
tentación es deducir el estilo de cada prenda, y eso es adivinar: un pantalón negro puede ser de
cualquier estilo.

Así que la tabla va de **ocasión** —que la eligió él para cada outfit— a estilo, y de categoría a
estilo **solo donde la prenda lo dice sin ambigüedad**. `chandal` está; `pantalones` no, y hay una
prueba de que no está. Por debajo de cuatro prendas no se afirma nada, y cada frase dice de dónde
sale — misma regla que la analítica del Horario (HT F11).

**Y el contraste describe, no corrige:** si él dice "elegante" y su armario refleja "deportivo", el
texto es *"puede ser justo lo que buscas cambiar"*. Cinco pruebas comprueban que nunca aparece
"deberías", "error", "incorrecto", "mal" ni "no encaja".

### Lo personal no viaja a las recomendaciones
El apartado 15 pide respetar la privacidad. *"Cosas que me gustaría hacer"* **no sale** en el contexto
que se entrega a quien recomiende ropa, con el motivo escrito y una prueba que lo busca. Los
intereses sí — el propio enunciado los pone como ejemplo de contexto útil.

### ⚠️ Esta fase obligó a afinar una prueba de la Fase 5
La Fase 5 comprobaba que ningún id del registro contuviera la palabra "marca" u "ocasion", y
`marcasFavoritas` la hizo saltar. **No era una duplicación:** el armario sabe qué marcas *tiene*, no
cuáles le *gustan*. Lo que hay que prohibir es el catálogo, no la preferencia — así que ahora compara
ids exactos.

Y dos comprobaciones nuevas cazaban **comentarios en vez de código**: una saltaba con la frase que
explica que *no* hay un almacén paralelo, y otra con "con**seguir**". Ahora las dos leen el archivo
con los comentarios quitados. Una prueba que salta con la prosa acaba haciendo que se reescriba la
prosa en vez del código.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **3 691 comprobaciones unitarias**, 5 de
auditoría, **432 casos de renderizado real** y 10 reglas invariantes — **4 128 en total**. De ellas,
**119 nuevas** para EH F6.

---

## Entrega 2 · EH Fase 5/65 — Estilo + Armario: integración con el sistema existente (v1.71.0)

### El enunciado empieza con tres avisos, y los tres dicen lo mismo
> ⚠️ NO reconstruir el armario.
> ⚠️ NO duplicar sus datos.
> ⚠️ NO crear un segundo sistema de ropa.

Así que este archivo **no guarda ni una prenda**. Ni un outfit, ni un uso, ni una marca, ni una
ocasión. Todo sigue en `armario.js` y `armarioInteligencia.js`, donde lo dejó AR F1-F4.

### ⚠️ La prueba que más importa no es ninguna de las diez del enunciado
El apartado 7 dice que *"una recomendación nunca debe convertirse automáticamente en una modificación
del armario"*. La forma de garantizar eso no es acordarse: es que **la capacidad no exista**.

Hay una prueba que **lee el código fuente** de `armarioEnEstiloHombre.js` y falla si aparece
`crearPrenda(`, `actualizarPrenda(`, `crearOutfit(`, `crearUso(`… o una llamada a la IA (apartado 11).
Nueve comprobaciones, todas sobre el texto del archivo.

Y otra que serializa el estado de Estilo de Hombre y comprueba que **no contiene el id de ninguna
prenda, ni el del outfit, ni la marca "Zara"**.

### ⚠️ Un solo perfil de tallas (Test 8)
El armario ya sabe qué talla gasta Josué: lo dice cada prenda. Así que **se deriva de ahí** —tres de
sus cuatro camisetas son M, luego gasta M— y lo guardado en la capa de la Fase 4 solo rellena los
huecos, como el calzado, del que no tiene ninguna prenda.

Dos decisiones que no son obvias:

- **Si los dos existen y no coinciden, se enseña el choque.** El armario manda, pero Josué ve
  "guardada: L · armario: M" y decide. Elegir uno en silencio sería crear el segundo perfil por la
  puerta de atrás: vería M en un sitio y L en otro sin saber por qué.
- **Un empate no es una respuesta.** Un 43 y un 44 con la misma frecuencia significan que el armario
  **no sabe** cuál es la suya, y entonces gana la que él indicó.

### El motor de recomendación tampoco se reescribe
`recomendarOutfits()` es de AR F4 y ya sabe de repetición, de prendas en la lavadora y de outfits
olvidados. Lo que añade esta fase es la capa de preferencias por encima.

Y **si no ha indicado colores favoritos, no se afirma que nada encaje**: `encajaConTusColores` sale
`false` en lugar de inventarse una afinidad.

### El apartado 8 no bloquea
*"No tenemos registrada tu talla de calzado"* con su *"Añadir talla"*… **y la recomendación sale
igual**. El enunciado lo dice con esas palabras: *"No obligar al usuario a completar todo su
perfil."*

### ⚠️ Un fallo real que encontró la prueba
El puente leía `outfit.ocasiones` como si fuera una lista. Un outfit guarda **una** ocasión, en
`ocasion`. Devolvía cero ocasiones siempre, y en silencio — la clase de error que nadie nota hasta
que una pantalla lleva meses vacía.

La forma que existe manda sobre la que uno supone. Es literalmente el tema de esta fase.

### Apagar el apartado no esconde el armario: lo saca de aquí
El apartado 10 pide que *"el sistema global de armario siga intacto si existe fuera de este
apartado"*. Así que al apagarlo la plaquita desaparece **y la pantalla dice** *"el armario sigue en su
sitio de siempre, con todo lo que tienes guardado"*, en vez de dejar un hueco.

### Las preferencias que el armario ya tiene no se declaran
Marcas, colores y ocasiones **se derivan de sus prendas y sus outfits**. Hay cinco pruebas que fallan
si aparecen en el registro de datos de la Fase 4. Solo se guardan las tres que no existían: estilos
favoritos, colores favoritos y formalidad — **una línea cada una**, que es lo que la Fase 1 prometió.

### Productos: el enlace declarado, ni un producto
Apartado 12 más **D2-03** de Josué (*arquitectura sí, afiliación no*). `PUENTE_PRODUCTOS` dice qué le
pasará el día que exista y que hoy no existe. Cinco pruebas buscan "amazon", "afiliad", "precio",
"comprar" y "http" dentro de él.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **3 569 comprobaciones unitarias**, 5 de
auditoría, **420 casos de renderizado real** y 10 reglas invariantes — **3 994 en total**. De ellas,
**138 nuevas** para EH F5. El **Test 10** (navegación en móvil) necesita un iPhone: **R1**, y la
auditoría lo declara en vez de darlo por bueno.

---

## Entrega 2 · EH Fase 4/65 — Sistema de datos, perfil y reutilización global (v1.70.0)

### La regla, en una línea
*"Un dato debe existir una sola vez y poder ser utilizado por todos los módulos que lo necesiten."*

### ⚠️ Una sola función lee, venga el dato de donde venga
`leerDato()` resuelve igual el **peso** —que vive en Salud— que el **tipo de piel** —que vivirá
aquí— y devuelve **exactamente la misma forma**. Hay una prueba que compara las claves de las dos
respuestas.

Eso importa dentro de cuarenta fases: cuando Skincare necesite los dos, **no tendrá que saber cuál
es cuál**. Si tuviera que distinguirlos, tarde o temprano alguien pediría el peso por el camino
equivocado, se lo encontraría vacío y crearía "su" copia.

### ⚠️ Y su gemela: guardar un dato global se rechaza
El apartado 3 lo escribe con un ejemplo: *"No puede existir Perfil → 72 kg, Estilo de hombre → 70
kg."*

`guardarDato(estado, 'peso', 70)` **no guarda nada**, y no falla en silencio: devuelve un error con
**el sitio donde sí se edita**, para que la pantalla pueda mandar a Josué allí. Hay una prueba que lo
intenta y comprueba que el peso sigue siendo el 73 de Salud y que no se ha creado ninguna copia.

Lo mismo con borrar (apartado 12): un dato propio se elimina, uno de JosStyle no se toca desde aquí.

### El Test 4 sale gratis, y ese es el punto
*"Modificar dato → todos los módulos compatibles reciben el cambio."* Productos cambia el tipo de
piel y Skincare lo ve **porque es el mismo dato**, no porque haya un mecanismo que los sincronice. Si
hubiera dos copias, cada módulo enseñaría un valor distinto y **nada reventaría**: por eso este test
importa más que los otros nueve.

### El historial es opcional, y está declarado
Las tallas lo llevan (apartado 9: *"peso, medidas, rendimiento…"*), el tipo de piel no. Ponérselo a
todo llenaría el guardado de ruido. Y guardar el mismo valor dos veces **no crea dos entradas**.

### La antigüedad describe, no juzga
*"Tipo de piel — Actualizado hace 3 meses"*, el ejemplo literal del enunciado, con su prueba. Y cinco
comprobaciones de que el texto nunca dice "deberías", "llevas", "olvidado", "demasiado" ni "mal". Es
la misma línea que se trazó en la analítica del Horario (HT F11).

### ⚠️ El apartado 14 pide NO ROMPER, y eso empieza por el texto
*"Productos → necesita preferencias de Skincare. Si Skincare está desactivado: no debe romper
Productos."*

Lo que sale es *"Añade tu tipo de piel para personalizar esto"*, y hay cinco pruebas de que nunca
aparecen las palabras "error", "undefined", "null", "falta" ni "no se puede". Un mensaje que asusta
rompe igual que una excepción.

Y una cosa más: **el dato sigue disponible con su módulo apagado**. Los datos no dependen de que su
módulo esté encendido — eso es el apartado 13, que el enunciado repite entero *"porque será
fundamental"*.

### Solo los datos que la especificación nombra
Tipo de piel, sensibilidad, tipo de pelo, preferencia de corte, preferencia de textura, productos sin
perfume, ropa oversize y tres tallas. **Ni uno inventado.** *"No crear todavía todos los campos
específicos. Solo preparar la arquitectura."* Añadir uno es añadir una línea.

### Privacidad: hoy ninguno
Ningún dato está marcado como privado, y decirlo es más honesto que fingir una protección que no
protege nada todavía. Lo que sí existe es el filtro, para que la fase que marque el primero no tenga
que construirlo — y para que nadie mande a la IA lo que no debe.

### Sexto campo nuevo, segundo seguido que el normalizador conoce
`datos` entra en `normalizarEstiloHombre` desde el primer commit. Y un dato guardado de una versión
anterior del registro **no se borra solo** (apartados 12 y 17).

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **3 431 comprobaciones unitarias**, 5 de
auditoría, **408 casos de renderizado real** y 10 reglas invariantes — **3 844 en total**. De ellas,
**141 nuevas** para EH F4. El **Test 10** (*"sincronización → no aparecen duplicados"*) se comprueba
hasta donde llega Node; que dos iPhones acaben con lo mismo es **R1**.

---

## Entrega 2 · EH Fase 3/65 — Sistema de primera configuración y perfil de usuario (v1.69.0)

### Lo que pide el enunciado, en una línea
*"La aplicación debe conocer qué necesita el usuario sin obligarle a rellenar un formulario
interminable."* Sencilla, progresiva, saltable, personalizable, reutilizable y **sin IA**.

Y subrayado: **"No preguntar información que JC Fitness ya conoce."**

### ⚠️ El asistente guarda por dónde va, no lo que sabe
Es la decisión que gobierna toda la fase. Se guardan **cinco cosas** —el paso, la selección en curso,
el estado y dos fechas— y **ni un dato de Josué**.

Su peso, su altura, su nombre y sus objetivos **se leen** de Perfil, Salud y Objetivos cada vez que
hacen falta. Guardar aquí una copia "para no volver a preguntarlo" sería exactamente lo contrario de
lo que pide el apartado 7, y daría dos pesos distintos el día que se corrija uno.

Hay cuatro pruebas que buscan `"Josué"`, `"2010-07-29"`, `"187"` y `"Masculino"` dentro de lo que se
guarda, y **fallan si aparecen**.

### El peso sale de donde es más reciente
`salud.medidas` tiene la última medida; `perfil.peso` tiene la del día que rellenó el perfil. Gana la
de Salud, y si no hay ninguna, vale la del perfil. Está probado con las dos.

### ⚠️ Quinto campo nuevo, primer normalizador que no se olvida
`asistente` es el quinto campo que se añade a una entidad de este proyecto. Las cuatro veces
anteriores —`visible`, `archivado`, `materiales`, y el módulo retirado de la semana pasada— **el
siguiente guardado se lo llevaba**, porque `saveData` sobrescribe y no fusiona (regla 5).

Esta vez `normalizarEstiloHombre` lo conoce desde el primer commit, y hay una prueba que serializa,
recarga y comprueba que el paso sigue ahí.

### ⚠️ Dos fallos reales que encontraron las pruebas

**1. Modificar la configuración reordenaba las plaquitas en silencio.** Entrar en *"Modificar mi
configuración"*, no tocar nada y confirmar **cambiaba el orden**, porque la selección de partida
salía en orden de catálogo y `terminarAsistente` reescribe el `orden` a partir de ella. Ahora sale en
el orden que él eligió.

**2. Pulsar "Empezar" enseñaba "Lo dejaste a medias".** El botón pasa el asistente a `en_curso`, y el
enlazado interpretaba eso como "vuelve de una configuración abandonada". Lo que el apartado 15
distingue es **volver** de **seguir**, y eso no está en el estado guardado: está en si ya estaba a
medias cuando abrió la pantalla. Ahora se calcula una sola vez, al entrar.

### Omitir marca configurado, y eso no es un descuido
El apartado 6 pide *"Omitir por ahora"* y que **no se rompa nada**. Si omitir no marcara
`configurado`, la próxima vez que entrase le saldría otra vez la bienvenida — que es justo lo
contrario de saltárselo. Y no enciende nada: entra en la pantalla vacía de la Fase 2, que ya sabe qué
decir.

### "Empezar de nuevo" reinicia el asistente, no los módulos
Los datos de cada apartado siguen donde estaban. Es la diferencia entre *volver a elegir* y *perderlo
todo*, y el apartado 15 pide la primera.

### ⚠️ Apartado 17 — ni una pregunta construida
*"Esta fase solo construye el sistema que las podrá alojar."* Así que no hay ningún formulario de piel,
pelo o fitness. Lo que hay es, por módulo:

- **`usa`** — qué datos globales reutilizará. Eso es lo que **no** se le va a preguntar.
- **`pregunta`** — en qué fase hará las suyas. Un número, no un formulario.

Hay una prueba que recorre todo `NECESIDADES_MODULO` buscando un signo de interrogación y falla si lo
encuentra.

### Mis datos: lo de fuera se edita fuera
El apartado 13 pide poder modificar las respuestas. "Mis datos" enseña el peso y **dice que está en
Salud**; no ofrece un campo para cambiarlo aquí. Dos sitios donde se edita el mismo dato y uno de los
dos acaba mintiendo.

### Los diez tests del apartado 18
Están los diez. El **Test 10** (*"probar todo el flujo en móvil"*) necesita un iPhone: es **R1**, y el
archivo de pruebas lo imprime en vez de darlo por bueno.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **3 290 comprobaciones unitarias**, 5 de
auditoría, **396 casos de renderizado real** y 10 reglas invariantes — **3 691 en total**. De ellas,
**139 nuevas** para EH F3.

---

## Entrega 2 · EH Fase 2/65 — Sistema de gestión y personalización de módulos (v1.68.0)

### La regla que gobierna la fase
*"El usuario decide qué quiere ver y qué no. No debemos mostrar 30 funcionalidades a alguien que
solo quiere utilizar 5."*

La Fase 1 dejó el catálogo y el interruptor. Esta construye **la gestión de verdad**: siete
categorías, buscador, orden, confirmación al apagar, recomendados y ficha.

### ⚠️ Y arregla un fallo real de la Fase 1, que avisaba la propia especificación
El apartado 17 dice: *"Módulo eliminado del catálogo en una futura actualización → los datos NO
deben borrarse automáticamente."*

El normalizador de la Fase 1 hacía justo lo contrario: descartaba el módulo entero. Y con la regla 5
del proyecto —**`saveData` sobrescribe, no fusiona**— eso significaba que **el siguiente guardado se
llevaba su `config` para siempre**.

Es la **cuarta vez** que este proyecto tropieza con el mismo fallo de normalizador (pasó con
`visible` en HT F2, con `archivado` en HT F4 y con `materiales` en HT F7). La diferencia es que esta
vez estaba escrito en el enunciado antes de que ocurriera.

Ahora el módulo retirado va a la cuarentena `retirados`: fuera de la lista que se pinta —nadie
sabría dibujarlo— pero **guardado entero**. Si vuelve al catálogo, `restaurarRetirados` lo devuelve
con sus datos, no desde cero.

### Una única fuente de verdad, comprobada contra el código
El apartado 15: *"No crear `skincareSettings` en un lugar distinto simplemente para saber si Skincare
está activo."*

Por eso categoría, confirmación, recomendación y sinónimos de búsqueda **están en la línea del
módulo**, dentro de `MODULOS_EH`. Un segundo mapa `id → categoría` se separaría del primero el día
que alguien añada un módulo y se olvide del otro sitio.

Y no es una promesa: hay una prueba que **lee `gestionModulos.js` y la vista** y falla si aparece un
segundo catálogo o un id de módulo suelto.

### El buscador tiene sinónimos porque el enunciado lo obliga
*"Buscar: pelo → 💇 Pelo, 🧔 Barba."* El nombre de Barba no contiene "pelo", así que un `includes`
sobre el nombre fallaría el ejemplo literal del enunciado. Cada módulo lleva sus términos.

Y aguanta lo que Josué escribe de verdad desde el iPhone: mayúsculas, tildes puestas o quitadas
("habito" encuentra **Hábitos**) y la eñe.

### ⚠️ El aviso al desactivar solo sale si hay algo que perder
El apartado 6 pide confirmación *"para módulos que puedan contener información importante"*, y que
la aplicación pueda definir cuáles.

Está definido —`confirmar: true` en el catálogo— **pero además se mira si el módulo tiene datos**.
Un cartel que dice *"tus datos no se eliminarán"* sobre un módulo vacío no protege nada: enseña a
pulsar "Desactivar" sin leer, y entonces no sirve el día que sí importa.

### ⚠️ Subir y bajar se mueven dentro de los ACTIVOS
Si la flecha saltara por encima de un módulo apagado, Josué la pulsaría y **no vería moverse nada**,
porque el que ha adelantado no se pinta. Hay una prueba con un módulo apagado justo en medio.

En los extremos las flechas salen **apagadas**, no desaparecen: una flecha que se esconde mueve la
interfaz debajo del dedo.

La estructura ya está lista para drag & drop, que es lo que pide el apartado 9: `moverA(estado, id,
posición)` acepta el destino directo, y `reordenar` acepta la lista entera de una vez.

### Recomendados: dos reglas, sin IA
*"Debe ser informativo, nunca obligatorio. No utilizar IA."* Solo se sugiere lo que está apagado, y
entre los apagados van primero los marcados en el catálogo y después los que **antes tendrán
contenido**: recomendar hoy algo que llega en la fase 55 es prometer.

Y **no sale nada** si no ha configurado todavía o si lo tiene todo encendido. Una sección con título
y sin contenido es peor que ninguna sección.

### ⚠️ Seis módulos que el enunciado nombra y no se han creado
El apartado 3 enumera, dentro de las categorías, **Nutrición, Recuperación, Salud preventiva, Salud
dental, Salud visual y Objetivos**. No están, y cada uno lleva su motivo escrito en el código:

- **Nutrición y Objetivos ya son módulos enteros de JosStyle.** Copiarlos dentro de Estilo de Hombre
  es literalmente lo que prohíben el apartado 10 de la Fase 1 y el 15 de esta.
- **Recuperación** es contenido de Fitness (fase 26).
- **Las tres de salud** son subdivisiones de Salud (fase 33) e Higiene (fase 18). Partirlas hoy sería
  decidir por adelantado la forma de fases que no tocan.

Las siete categorías están las siete. Si una fase futura crea uno de esos módulos, **entra con una
línea**.

### Los diez tests del apartado 18
Están los diez. Los dos que no se pueden ejecutar aquí lo dicen en vez de darse por buenos: el
**Test E** (*"cerrar aplicación"*) se comprueba hasta donde llega Node —el estado sobrevive al viaje
por JSON y por el normalizador, que es lo que hacen `saveData`/`loadData`— y que Supabase responda es
**R1**; el **Test J** (*"probar en móvil"*) necesita un iPhone, también **R1**.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **3 151 comprobaciones unitarias**, 5 de
auditoría, **352 casos de renderizado real** y 10 reglas invariantes — **3 508 en total**. De ellas,
**157 nuevas** para EH F2.

---

## Entrega 2 · EH Fase 1/65 — Arquitectura base y sistema modular (v1.67.0)

### Empieza el bloque más grande del proyecto
Estilo de Hombre son **65 fases**: más que todo JosStyle construido hasta hoy. Esta primera no
construye ni un apartado de contenido —el enunciado lo prohíbe expresamente, apartado 14— sino **el
sistema que va a sostener a los otros 64**.

### Añadir un módulo es añadir una línea
Es el apartado 9: *"la arquitectura permita añadir decenas de módulos posteriormente sin rehacer
este sistema"*. En `src/lib/estiloDeHombre.js` los trece apartados son trece líneas de un array:

```js
{ id: 'skincare', nombre: 'Skincare', icono: '🧴', sub: 'Rutina de piel', fase: 6 },
```

Nada más. Ni un `case`, ni un `if`, ni un sitio donde acordarse de registrarlo. **Esa es la única
razón por la que este archivo existe antes que ninguna pantalla.**

### El catálogo va a cambiar, y el normalizador lo sabe
Sesenta y cuatro fases por delante significan que el catálogo **va a crecer**, y probablemente
también a encoger. `normalizarEstiloHombre` aguanta las dos direcciones:

- **Lo guardado que ya no está en el catálogo se descarta.** Un módulo retirado no puede quedarse
  como un id fantasma que ninguna pantalla sabe pintar.
- **Lo nuevo del catálogo aparece apagado.** Si apareciera encendido, cada fase futura le encendería
  a Josué un apartado que él no ha pedido — y son sesenta y cuatro fases de eso.

### ⚠️ `alternarModulo` no toca `config`. Jamás
El apartado 7 lo dice con esas palabras: *"desactivar un módulo NO elimine sus datos"*. Aquí el
peligro no es el del normalizador de siempre —olvidar un campo y borrarlo sin querer— sino el
contrario: **limpiar los datos "por orden"** al apagar el interruptor.

Apagar es apagar. Los datos de skincare siguen ahí seis meses después, y al volver a encenderlo
están como los dejó. Hay una prueba que guarda una configuración, apaga, enciende y comprueba que
sigue entera; es una de las dos que **fallan en silencio** si alguien se despista.

### ⚠️ El apartado 10, escrito como función y no como recordatorio
*"Estilo de hombre NO debe crear una copia de los datos globales."* Peso, altura, sueño, agua,
entrenamiento — ya viven en Salud, Sueño, Nutrición y Calistenia.

Un documento diciéndolo se olvida. Así que están declarados en `FUENTES_GLOBALES`, y `esDatoGlobal()`
responde. Una fase futura que quiera guardar el peso aquí **choca con una función**, no con la buena
memoria de quien lea el documento.

### Las plaquitas dicen la verdad
Ninguno de los trece apartados tiene contenido todavía. Podrían abrir trece pantallas vacías; en vez
de eso **la pantalla escribe que el contenido llega en las siguientes fases**. Es la regla 8: nada de
"próximamente", pero tampoco fingir que algo funciona.

### La pantalla no decide su propio estado
Los tres casos del apartado 13 —sin configurar, configurado sin nada encendido, con apartados— los
calcula `estadoPantalla()`, que se prueba con Node. Tres `if` encadenados en una vista es donde
aparece el cuarto caso que nadie contempló.

### Dónde vive
`app_data`, clave `estiloHombre`. **Sin SQL nuevo.** Entra por *Más → Estilo de hombre*, dentro de un
área que ya existía: las cinco pestañas de abajo siguen siendo cinco (regla 10).

### ⚠️ C-24 — el "106" de la portada no cuadra
Al abrir el bloque: toda la documentación llama a la Entrega 2 *"las 106 fases"*, pero el desglose
por módulos suma **110** (EH 65 + HT 12 + FO 12 + SR 9 + ME 4 + BI 4 + AR 4). Las fases de EH están
numeradas *"x/65"* en la propia especificación de Josué, así que el desglose es el que manda sobre el
trabajo. No lo he cambiado por mi cuenta: está anotado en `docs/03` como **C-24** y **no bloquea
nada**, porque el trabajo ya se está haciendo con el número bueno.

### Verificación
`bash scripts/verificar.sh` en verde: build de Vite, **2 994 comprobaciones unitarias**, 5 de
auditoría, **332 casos de renderizado real** y 10 reglas invariantes — **3 331 en total**. De ellas,
**69 nuevas** para EH F1, con los 7 tests obligatorios del apartado 15 cubiertos.

---

## Entrega 2 · SO Fase 4 — Diseño y especificación de los sonidos (v1.66.0)

### Lo que esta fase puede hacer, y lo que no
*"Definir y preparar la biblioteca sonora."*

**No crea los sonidos, y no puede.** No hay ni un archivo de audio en el proyecto, y generarlos sería
inventarse la mitad del trabajo (regla 8).

Lo que sí hace —y es exactamente el verbo del enunciado— es **definir**: la ficha de cada archivo,
escrita como código. Nombre exacto, carpeta, familia, duración mínima y máxima, si lleva variantes y
si tiene que ser único.

**Eso convierte *"dame los sonidos"* en una lista precisa.** El día que estén en `public/sonidos/`
con estos nombres, suenan sin tocar una línea: el motor de SO F1 ya los busca ahí.

### La familia manda sobre el tramo
El enunciado da dos cosas: familias (UI, feedback, reward…) y tramos de duración (microinteracción
40-150 ms, feedback 100-300…). Se cruzan, y **gana la más estricta**.

Un `ui_click` de 300 ms cumpliría "feedback" y aun así **se pisaría con el siguiente toque**. Hay una
prueba de que ningún sonido acaba con un rango imposible.

### La firma, en intervalos y no en notas
*"Un motivo de 2-4 notas que pueda aparecer de forma evolucionada."*

Está definida como **intervalos** (0, 5, 7 — cuarta justa y segunda mayor), no como notas concretas:
así se transporta a cualquier tonalidad y sigue reconociéndose. Con sus cinco evoluciones, de las
tres notas limpias en un logro a la firma completa con cola larga en un gran logro.

Y **se llama "firma de JosStyle"** (D2-08): *JC Lifestyle* es el nombre histórico que aparece en la
especificación, no el del proyecto.

### Los importantes son únicos
Los que se repiten mucho llevan variantes numeradas: `ui_click_01`, `_02`, `_03`. Oír el mismo clic
doscientas veces al día es exactamente lo que cansa.

Pero el enunciado enumera los que **no**: `level_up`, `personal_record`, `grand_achievement`, los
milestones grandes y los 365 días. **Un récord con tres variantes deja de ser un momento** — la misma
razón por la que SO F1 le puso el cooldown más largo.

El validador rechaza un `personal_record_02` por ese motivo, con esas palabras.

### `queFalta()`
La función más honesta del archivo. Hoy devuelve **la lista entera**, porque no hay ni uno.

Dice cuántos faltan, cuáles son los únicos (que son los que más cuestan y más se notan) y **por dónde
empezar**: los de interfaz, que son los que se aprecian nada más usar la app.

### Un hueco que cazó la comprobación cruzada
`goal_progress` estaba en el catálogo de SO F3, podía sonar, y **no tenía archivo definido**. La
prueba que cruza el catálogo con la biblioteca lo encontró.

### Lo que no se ha construido, y es un límite de fase
- **La pantalla de Ajustes de sonido**: SO F1 terminaba con *"DETENTE. No empieces todavía la
  biblioteca de sonidos ni la pantalla de Ajustes"*, y esa pantalla es de **SO F5**.
- **Los archivos**: ⏸ los da Josué *"cuando la web ya tenga todos los botones activos"*. **SO F2 es
  la fase que los necesita y sigue bloqueada.**

### Verificación
**3221 comprobaciones y 10 reglas invariantes en verde** (antes 3162), 59 de la biblioteca definida.
`package.json` → **v1.66.0**.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes: bucket `armario` (AR F1) y bucket
`fondos` (FO F2).


## Entrega 2 · SO Fase 3 — Eventos, feedback, recompensas y racha (v1.65.0)

### Por qué esta fase va antes que la 2
SO F2 es la biblioteca de sonidos y **sigue bloqueada**: no hay ni un archivo de audio en el
proyecto, y Josué dijo que los daría *"cuando la web ya tenga todos los botones activos"*.

El catálogo de eventos y la jerarquía **no los necesitan**. Así que se adelanta, en vez de dejar el
bloque parado esperando.

### Los 42 eventos, sin crear un segundo catálogo
SO F1 dejó 17 eventos y cuatro prioridades, que era lo que el motor necesitaba. Esta fase trae los 42
que pide la especificación.

⚠️ Pero **no redefine ninguno de F1**: los traduce. Dos catálogos que se separan con cada fase es
exactamente lo que el apartado 30 de aquella fase prohíbe.

### Un solo sonido cuando pasan cinco cosas a la vez
*"Completar tarea → +XP → subir de nivel → alcanzar milestone → nuevo récord."* Cinco eventos, un
sonido: **PERSONAL_RECORD**.

Y los otros cuatro **se devuelven**, no se pierden: la especificación dice que *"la interfaz puede
mostrar visualmente todos los acontecimientos, pero el audio debe mantener jerarquía"*.

Esto no sustituye al cooldown de SO F1 — aquel evita que veinte toques den veinte sonidos, esto elige
cuál de los cinco simultáneos suena. Son dos problemas distintos.

### Un bug que cazó su propia prueba
El desempate a igual nivel era "gana el que tenga más días", pensado para milestone contra milestone.
Pero eso hacía que **el milestone de 30 días ganara al récord**, que es justo lo contrario de lo que
dice la especificación con ese ejemplo delante.

Ahora el récord lleva su propio peso de desempate, y el de 365 días sigue ganando al de 100.

### La racha sube de identidad, no de volumen
*"Los milestones deben ser progresivamente más especiales. No quiero simplemente el mismo sonido con
más volumen. Debe existir una evolución real de la identidad sonora."*

Traducido a algo comprobable: **el nivel sube con los días**. El de 3 días es nivel 2, el de 7 es 3,
el de 30 es 4, el de 365 es 5. Hay una prueba que recorre los diez milestones y falla si dos
consecutivos bajan, y otra de punta a punta.

Y **el récord es independiente del milestone**: *"has alcanzado un milestone"* y *"has superado tu
propio récord"* son acontecimientos diferentes, y la especificación lo dice con esas palabras.

### Los eventos que hoy no emite nadie, dichos con su motivo
La especificación lista `xp_small`, `level_up`, `reward_major` y `streak_freeze_used`. Pero:

- **RA F3 decidió no construir XP ni niveles.** Sus apartados los dejaban en condicional, y sin nada
  que gastar un contador de XP es un control decorativo (regla 8). D2-02 lo respalda.
- **El "congelar racha" no existe en RA F1**: el motor deriva la racha del historial y no tiene
  comodines.

Así que esos eventos **están en el catálogo** —para que el día que haya XP suene sin tocar nada— y
**cada uno lleva escrito por qué hoy no lo emite nadie**, con una prueba que lo comprueba. Un evento
fantasma sin explicación es lo que hace que alguien lo conecte mal seis meses después.

### Verificación
**3162 comprobaciones y 10 reglas invariantes en verde** (antes 3115), 47 del catálogo.
`package.json` → **v1.65.0**.

⏸ **Sigue sin sonar nada**, y es lo mismo desde SO F1: no hay archivos de audio. **SO F2 es justo la
fase que los necesita.**

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes: bucket `armario` (AR F1) y bucket
`fondos` (FO F2).


## Entrega 2 · HT Fase 12 — Cloud, sincronización y arquitectura definitiva (v1.64.0) 🔒 CIERRA HORARIO TOP

Con esta fase **el bloque HT queda cerrado: 12 de 12**.

### Una sola puerta
Once archivos de horario no pueden ser once puntos de entrada. `diaCompleto()`, `resumenModulo()` y
`contextoCompletoIA()` son la única puerta desde fuera; cada archivo sigue siendo dueño de lo suyo
(apartados 90 y 91).

### Exportar sin llevarse lo que no es
Se exporta la estructura y los datos: horarios, asignaturas, clases, materiales, mochilas, kits,
reglas y automatizaciones.

**No viajan** lo que confirmaste que hiciste, los avisos que ya se dieron ni lo que metiste en la
mochila cada día. Son de este curso y de este aparato — llevárselos daría un histórico que no
ocurrió. Y está escrito **por qué**, para que nadie los añada sin pensarlo.

### Importar dos veces no duplica el curso
Es la propiedad que evita el desastre, y es la misma idempotencia de RA F2: se compara por id, así
que pegar el mismo archivo dos veces no crea cuarenta clases repetidas.

Antes de escribir se revisa y se dice **cuánto traería y qué no va a traer**. Un archivo de otro
módulo se rechaza; uno de una versión más nueva también, en vez de intentar adivinarlo.

Y sustituir el horario entero **no borra lo que confirmaste**: eso sigue siendo de este dispositivo.

### La auditoría es código, no un documento
El apartado 103 enumera cincuenta y tres cosas que Horario Top tiene que saber hacer. Las 38
comprobables **están atadas a una función que tiene que existir**.

Si alguien borra una, la prueba falla sola. Un documento que dice "está todo" se desactualiza en la
primera fase que venga después; esto no puede.

Es la misma decisión que HT F1 tomó al construir un módulo probado en vez de un documento de
arquitectura.

Y **lo que la auditoría no puede comprobar, lo dice ella misma**: el responsive, la accesibilidad
real con lector de pantalla, el modo oscuro en pantalla, el diseño, los backups de Supabase (son de
la consola) y las Edge Functions (infraestructura que el proyecto no tiene). Decir que están porque
hay una clase de CSS sería mentir.

### Cloud, RLS y multidispositivo: ya estaban
No se ha rehecho nada. **Se resolvieron en HT F2**, y con la decisión más importante del módulo: el
apartado 51 obliga a *"adaptarse a la arquitectura global"*, así que el horario vive en `app_data`
con RLS por usuario — **sin una tabla propia y sin un SQL que Josué tenga que ejecutar**.

La auditoría lo comprueba de verdad: **no hay `user_id` que falsear** en el modelo.

### Lo que queda montado
`Horario → Estudios → Mochila → Tareas → Objetivos → Entrenamiento → Productividad → IA →
Notificaciones → Analítica`, entero, y cada eslabón **lee** del dueño del dato en vez de copiarlo.

### Verificación
**3115 comprobaciones y 10 reglas invariantes en verde** (antes 3066), 45 del cierre y 308 casos de
renderizado. `package.json` → **v1.64.0**.

⚠️ **Ningún SQL nuevo, en las doce fases del módulo.** Siguen los dos bloques pendientes de siempre,
que son de otras fases: bucket `armario` (AR F1) y bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 11 — Analítica personal, carga, progreso y aprendizaje (v1.63.0)

### La frase que decidió cómo construir la fase
Esta es la especificación más corta de las doce: veintitrés puntos y ninguna letra pequeña. Pero uno
de ellos dice cómo hay que hacer todo lo demás:

> *"…y un sistema de aprendizaje que mejore las sugerencias **sin convertirlo en una caja negra**."*

Así que aquí **no hay ni un número que no se pueda explicar**. Cada cifra viene con de dónde sale
—*"de 9 días con clases, confirmadas a mano"*— y lo que el sistema "aprende" son frases que se leen y
se comprueban: *"por la tarde confirmas menos (3 de 12)"*.

### Sin datos no se inventa una tendencia
Con tres días no hay tendencia; hay tres días.

- **Por debajo de 3 ocurrencias no se afirma ningún patrón.** "Los martes te saltas el estudio"
  basado en un martes es una afirmación inventada.
- **La tendencia necesita los dos periodos con datos.** Comparar una semana llena con una de
  vacaciones diría "has bajado un 80 %", y sería mentira.
- **Menos de 10 puntos de diferencia no es tendencia**: es ruido de una semana.

Y cuando no hay bastante, se dice: *"todavía no hay suficientes semanas para comparar"*, no un cero.

### Un bug de diseño que cazó su propia prueba
`suficientesDatos` solo miraba si había clases planificadas. Con cero confirmaciones eso daba *"esta
semana 0 %, la anterior 0 %"* — que **da por hecho que Josué no hizo nada**, cuando lo que pasa es
que no ha usado el botón de confirmar.

Ahora hace falta también **alguna confirmación**, y si no la hay se dice con esas palabras: *"hay 40
actividades en esos días, pero ninguna confirmada todavía"*.

### Describe, no juzga
Es la misma línea de la mochila (*"sin castigo"*), del planificador (*"no castigar"*) y de D2-02
(*"no sobregamificar"*). Un 40 % es un dato, no una nota.

Hay una **lista declarada de palabras prohibidas** y una prueba que **recorre todos los textos que
genera el archivo** —resumen, orígenes, patrones, tendencia y recomendaciones— buscando reproches, en
el peor escenario posible: cuatro semanas de clases y nada confirmado. Más otra que comprueba que no
hay ni puntos, ni niveles, ni rachas.

### Detalles que evitan medias verdades
- **Solo cuentan los días ya pasados**: incluir el futuro daría un cumplimiento que baja solo según
  avanza la semana.
- **La media es de los días ocupados**: incluir los domingos vacíos la hunde y deja de describir cómo
  es un día de instituto.
- **Los días sin mochila no cuentan**: un domingo no es un olvido.
- **Las tareas sin fecha se cuentan aparte**, no como vencidas.

### Lo que no se ha construido, y por qué
- **Gráficas**: la especificación no las pide, y el proyecto **ya tiene** un módulo de Estadísticas
  con las suyas. Un segundo sistema de gráficas dentro del horario sería la duplicación de siempre.
- **Cumplimiento de objetivos y hábitos**: los objetivos son su módulo y los hábitos viven en
  Productividad con sus rachas. Medirlos aquí daría dos números distintos para lo mismo.

### Verificación
**3066 comprobaciones y 10 reglas invariantes en verde** (antes 3009), 49 de la analítica y 304 casos
de renderizado. `package.json` → **v1.63.0**.

⚠️ Sin probar: la pantalla del informe. Como todo desde R1.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes de siempre: bucket `armario` (AR F1) y
bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 10 — Notificaciones, recordatorios y contexto proactivo (v1.62.0)

### La mitad que faltaba: decidir, no mandar
El proyecto **ya tiene** quien manda notificaciones: `notificaciones.js`, de la Fase A4, con el
permiso del navegador, el interruptor global, las categorías y el horario de descanso. Un segundo
emisor daría dos avisos por lo mismo.

Así que lo construido es la otra mitad:

- **`avisosHorario.js` decide** qué avisar, cuándo y con qué prioridad. Puro, se prueba con Node.
- **`notificaciones.js` manda.** Toca el navegador.

Es el mismo reparto de SO F1 (`audio.js` decide, `audioEngine.js` suena), y por el mismo motivo: la
decisión es donde están los errores que importan, y la decisión sí se puede probar.

### Que exista un evento no significa que haya que avisar
Es la regla fundamental de la fase (apartado 4). Por eso hay un motor con las seis preguntas del
apartado 5 en vez de un `if`:

¿Es importante? → ¿Está configurado? → ¿Es el momento? → ¿Ya se avisó? → ¿Sigue valiendo? → Enviar.

Y **cada rechazo lleva su motivo por escrito**: "todavía no toca", "ya se avisó de esto", "estás en
horas de descanso". Sin eso, contestar *"¿por qué no me ha avisado?"* sería adivinar.

### Tres avisos se convierten en uno
Seis clases un martes no son seis notificaciones (apartado 34). Cuando hay más de uno que mandar a la
vez, se junta en uno solo — *"3 cosas hoy: Examen, Mates, Biología"* — con **lo más importante
primero**.

Y el resumen nocturno **calla si mañana no hay nada**. Uno que dice "mañana no tienes nada" todas las
noches de las vacaciones es exactamente el ruido que el apartado quiere evitar.

### No molestar se respeta también con lo crítico
Un aviso de mochila a las 3 de la mañana **no es más útil por ser urgente**. Así que las horas de
descanso ganan a todo, incluida la prioridad crítica. Tiene su propia prueba.

### Un aviso caduca
Si la clase ya pasó o la tarea ya está hecha, el aviso programado **no se manda** (apartado 52).
Avisar de algo que ya no aplica es peor que no avisar.

Y con más de dos horas de retraso tampoco: avisar a las 12 de una clase de las 8 solo hace ruido.

### Lo crítico es lo crítico
Un examen **mañana** es lo único que sube a crítica solo. Uno de dentro de tres días es alta. Uno de
dentro de un mes no avisa todavía.

Y **que falte material en la mochila no es crítico**: es importante. Confundirlos hace que lo crítico
deje de serlo, que es cómo se acaba ignorando el aviso que sí importaba.

Si la mochila está completa, no se avisa. Si no hay tareas vencidas, no se avisa de tareas.

### El centro de avisos
Lo que se ha avisado, con los **sin leer primero**, y las tres acciones del apartado 57: posponer, dar
por leído y archivar. Archivar da por leído — nadie archiva algo sin mirarlo.

Posponer vive en la sesión, no se guarda: es una decisión de este rato, no un dato.

### Lo que no se ha construido, y por qué
- **Push Cloud con la app cerrada** (47-49): exige un Service Worker que escuche `push`, una tabla de
  suscripciones y otra función serverless. Es infraestructura nueva —ya documentada como fuera de
  alcance desde la Fase A4— y añadiría un tercer bloque de SQL a los dos que Josué tiene pendientes.
- **Ubicación y contexto de dispositivo** (44-45): necesita GPS.
- **Sonido y vibración** (82-84): el sonido es **SO · Sonido**, con su motor y su regla invariante.
  Meterlo aquí sería el segundo sistema que esa regla impide.
- **Cloud y conflictos** (86-88): resuelto desde HT F2.

### Verificación
**3009 comprobaciones y 10 reglas invariantes en verde** (antes 2934), 71 del motor de avisos y 296
casos de renderizado. `package.json` → **v1.62.0**.

⚠️ Sin probar: que la notificación llegue de verdad al iPhone, el permiso del navegador y Web Push
con la app cerrada. Como todo desde R1 y la Fase A4.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes de siempre: bucket `armario` (AR F1) y
bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 9 — IA de horario y planificador personal (v1.61.0)

### Dónde está la IA en la arquitectura
El apartado 52 lo dibuja así:

    DATOS → MOTOR TEMPORAL → MOTOR DE PLANIFICACIÓN → IA → PROPUESTA → CONFIRMACIÓN → CAMBIOS

La IA está **después del planificador y antes de la confirmación**. No calcula y no escribe. Lo que
se ha construido es el motor que va antes: `planificador.js`, **determinista** — los mismos datos dan
el mismo plan, y se prueba entero con Node.

### Sin confirmar no se escribe nada
`aplicarPlan` sin `confirmado: true` **no hace nada**. No es una comprobación defensiva: es la regla
7 del proyecto puesta en código, para que sea imposible que una respuesta de la IA cambie el horario
sola.

Y el botón dice exactamente qué va a pasar: *"se van a crear 4 sesiones en tu horario; puedes
cambiarlas o borrarlas después como cualquier otra clase"*.

### Los números salen del motor, no de una estimación
*"Tienes 1 h 20 min libres"* lo dice el motor temporal (apartado 51). Por eso el contexto que se le
manda a la IA lleva los huecos, la carga y las prioridades **ya calculados**.

Y **no se manda toda la base de datos** (apartado 50): solo lo relevante. Nunca las notas privadas de
una actividad, nunca una palabra del módulo de Relación. Hay pruebas de las dos cosas.

### Un hueco de 35 minutos no sirve para una sesión de 30
Hay que levantarse, llegar y sentarse. Por eso el planificador descuenta margen y transición, y el
hueco propuesto **empieza después de la transición**, no pegado a la clase anterior.

Y *"no estudiar después de entrenar"* funciona de verdad: lo que se pidió evitar **no sale en la
lista**, no se ordena al final. Si saliera, acabaría eligiéndose un día con prisa.

### La víspera es repaso, no materia nueva
El plan reparte el temario entre los días que quedan y **deja la víspera para repasar**. Meter el
último tema el día antes es exactamente lo que hace llegar al examen sin haberlo visto dos veces.

El día del examen no se estudia. Y si el examen es hoy, lo dice y desea suerte — no propone nada.

### No castiga
El apartado 19 se titula así. Si el martes no estudiaste, el plan **no dice "has fallado"**: dice
*"te quedan dos sesiones antes del examen, el plan se reajusta así"*.

Hay una prueba que falla si aparece "has fallado", "mal", "deberías" o "penalización".

### Ninguna acción de la IA borra nada
Cuatro acciones estructuradas y cerradas: crear una sesión de estudio, crear una tarea, mover un
bloque, añadir algo a la mochila. **Ninguna borra.** Una IA que pueda proponer un borrado acabará
proponiéndolo el día que no te fijes.

Se validan antes de tocar nada —fecha, horas coherentes, que el bloque exista— y se previsualizan sin
escribir, igual que los `impacto*()` de HT F4.

Y una tarea **no se escribe aquí**: se devuelve marcada para Productividad, que es su dueña.

### El número de prioridad no se enseña
El cálculo existe (apartado 21) y es determinista: vencido, hoy, examen, prioridad y días de margen.
Pero "esto vale 87 puntos" no le dice nada a nadie. Lo que se enseña es **el orden y el motivo**:
*"se pasó hace 1 día"*, *"es mañana"*, *"faltan 3 días"*.

### Lo que no se ha construido, y por qué
- **Chat contextual** (3, 41, 46-48): el proyecto **ya tiene** buscador con IA (BI F3-F4) y el proxy
  de `api/ask-ai.js`. Un segundo chat sería la cuarta lista que D2-07 prohíbe. Lo que faltaba —el
  contexto que se le manda— es lo que está hecho.
- **Descomponer tareas grandes** (22-24): trocear "hacer el trabajo de Historia" exige entender el
  trabajo, no el horario.
- **Tiempo de desplazamiento** (29): necesita mapas.
- **Memoria de IA** (65): guardar preferencias aprendidas sin que Josué las vea sería justo lo que la
  regla 7 evita. Las preferencias **se declaran**, no se deducen.

### Verificación
**2934 comprobaciones y 10 reglas invariantes en verde** (antes 2854), 72 del planificador y 292
casos de renderizado. `package.json` → **v1.61.0**.

⚠️ Sin probar: la respuesta real de la IA y la pantalla. Como todo desde R1.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes de siempre: bucket `armario` (AR F1) y
bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 8 — Motor temporal y automatizaciones inteligentes (v1.60.0)

### "Pasada" no es "completada"
Es la distinción que sostiene la fase entera. *"La hora terminó"* y *"la actividad se realizó"* son
cosas distintas: una clase a la que no fuiste terminó igual, pero no la hiciste.

Confundirlas rompe el histórico, así que:

- **"Pasada" se calcula del reloj.** Guardarlo dejaría de ser verdad en un minuto, y a las 23:59
  media app estaría diciendo "en curso" de algo de por la mañana.
- **"Completada" se guarda**, porque no hay forma de deducir del reloj si fuiste a clase. Y es lo
  único que se guarda de todo esto.

Confirmar es siempre opcional. Nada obliga a marcar nada.

### El tablón se vacía solo
Lo terminado **sale del tablón principal** y se consulta con un toque: a las 20:00 lo que importa no
es la clase de las 8.

Debajo, el día lleva su cuenta: *"2 de 3 terminadas confirmadas"*. Las completadas cuentan también
como terminadas — contarlas aparte daría totales que no suman.

### El cambio de día, dicho con honestidad
No hay proceso de fondo en una PWA. Un temporizador que corriera toda la noche no existe en iOS.

Así que el "cambio de día" es lo que sí se puede hacer: comparar la fecha que la pantalla creía con
la de ahora, y recalcular si no coinciden. Funciona, y no finge un servicio que no está corriendo.

### La excepción gana a la regla
El motor es trigger → condiciones → acción, con **todas** las condiciones exigidas.

Y el apartado 45 pone el caso: *"añadir bata"* como regla general, *"no llevar bata el 15 de
septiembre"* como excepción. **El 15 no se lleva bata.** Sin esto, una regla general no se podría
matizar nunca, y la única salida sería borrarla y volver a crearla.

El motor es **deliberadamente cerrado**: cuatro triggers, cinco condiciones y cuatro acciones. Uno
abierto sería un lenguaje de programación dentro de una app de instituto, y nadie podría depurar por
qué apareció una bata.

### Nada crítico se ejecuta solo
Las acciones tienen nivel: informativa, reversible e importante. **No hay críticas** — nada de lo
que puede hacer una regla borra datos.

Y lo importante **no se ejecuta sin confirmar**, ni siquiera dentro de un "hacerlo todo": ahí se
queda fuera del lote y se pregunta aparte. Ejecutarlo "porque estaba en el lote" sería saltarse el
apartado 53 por comodidad.

### Todo lo automático se explica y se deshace
*"21:00 → Añadida bata automáticamente por Biología."* Con su hora, su motivo y un botón.

⚠️ Y **deshacer un aviso ya dado no revierte nada** — no se puede "no avisar". Así que se marca en el
historial y se dice que no tuvo efecto, en vez de fingir que sí.

Lo que pone una regla en la mochila **no se marca como manual** a propósito: si lo hiciera, sería
eterno y el motor de la mochila no podría recalcularlo nunca.

### La IA no es el motor
El apartado 55 lo dice y aquí se cumple: el motor es determinista y se prueba entero con Node. La IA,
cuando llegue en la Fase 9, **propondrá** reglas para que Josué las apruebe — no las ejecutará.

### Verificación
**2854 comprobaciones y 10 reglas invariantes en verde** (antes 2772), 74 del motor temporal y 284
casos de renderizado. `package.json` → **v1.60.0**.

⚠️ Sin probar: que la pantalla se refresque sola al pasar la hora y el cambio de día con la app
cerrada. Como todo desde R1.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes de siempre: bucket `armario` (AR F1) y
bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 7 — Mochila inteligente, materiales y preparación automática (v1.59.0)

### La mochila es una consecuencia, no una lista
*"Día → actividades → materiales → excepciones → mochila."*

Nada de lo que sale en la mochila se ha escrito a mano: sale del horario de ese día y de los
materiales de cada asignatura. Lo único que se guarda es lo que **no se puede deducir**: qué has
metido ya, qué has añadido tú, en qué estado está cada cosa y dónde la tienes.

Se ve dentro de HOY, con dos tarjetas: **la de hoy** y **la de mañana**, que es la que de verdad se
prepara por la noche. Y la de mañana ya existe hoy, sin esperar a las 00:00, porque no se genera:
se deriva.

### Lo que añades a mano no se borra solo
Es la regla que se rompe sin que nadie se entere. Si escribes "llevar bata igualmente", el recálculo
de mañana **no puede** hacerla desaparecer (apartado 57).

Por eso cada elemento sabe de dónde viene (apartado 58) y el motor solo toca los automáticos. Tiene
su prueba: se añade a mano, se recalcula entero y sigue ahí.

### Una libreta es una libreta, pero dos hojas y tres son cinco
Dos asignaturas que piden libreta dan **1 libreta, para Biología y Matemáticas** — no dos entradas
iguales (apartado 60).

Pero con los **consumibles** es al revés: dos hojas y tres hojas **son cinco hojas** (apartado 61).
El inventario es quien sabe qué es consumible, así que se lo dice al agrupador de HT F2 en vez de
escribir un segundo agrupador.

### Cada cosa dice por qué está
Tocar la bata explica: *"la necesitas porque tienes Biología"*. Y si es una dependencia, *"va con el
iPad"*; si es de la base, *"siempre lo llevas"*; si la pusiste tú, lo dice.

Una checklist que no se explica es una checklist que se ignora.

### "Meter todo" no marca lo que no tienes
Si la bata está prestada o perdida, "Meter todo" **la salta**. Marcarla sería mentira, y la mochila
dejaría de servir justo el día que importa.

En su lugar sale tachada, con el motivo: *"necesitas la bata y la tiene Jorge"* (apartado 38).
Devolverla borra ese nombre — si no, seguiría diciendo "la tiene Jorge" para siempre.

### Kits, dependencias y reglas
- **Dependencias** (96-97): iPad → cargador → cable, resuelto en cadena. ⚠️ Y un ciclo (A necesita B
  y B necesita A) **no cuelga la app**: sin cortarlo, la pantalla se quedaría en blanco.
- **Reglas** (75-79): tres condiciones — por actividad, por día de la semana, por etiqueta.
  Deliberadamente simple: un motor con anidamiento sería un lenguaje de programación dentro de una
  mochila.
- **Mochila base** (26): estuche, botella, cargador. Lo que va siempre, sin depender del horario.

### Sin castigo
El apartado 105 se titula exactamente así. Se detecta que faltó algo y **no se riñe**: el mensaje es
*"pasa"*. Hay una prueba que falla si aparece la palabra "fallo", "mal" o "penalización", y otra que
comprueba que no hay ni puntos, ni niveles, ni rachas de mochila (D2-02).

### Un bug de datos evitado antes de que pasara
`normalizarHorarioTop` no conocía `materiales`, `enlacesMaterial`, `mochila` ni las cinco colecciones
nuevas. Y decenas de funciones devuelven `normalizarHorarioTop(estado)` — cualquiera de ellas habría
borrado **el material y la mochila enteros** en el siguiente guardado.

Es el mismo fallo de `visible` (HT F2), `archivado` (HT F4) y `grupos` (HT F5), pero con muchos más
datos por delante. Esta vez se vio al añadir los campos, no al perderlos.

Y otro: el campo se llama `metido` desde HT F2. Inventar aquí un `preparado` habría dado un botón
que se olvida al recargar. Se reutiliza el que ya existía.

### Lo que no se ha construido, y por qué
- **Recordatorio a las 21:00** (47-49): es una notificación, y eso es la Fase 10. Lo que sí está es
  **qué** diría: el aviso con los nombres de lo que falta.
- **Conexión con Economía** (65): la lista de compra dice qué falta; crear un gasto por una libreta
  que no se ha comprado sería inventarse un movimiento.
- **IA para configurar reglas** (80): la IA nunca se dispara sola (regla 7), y esto es Fase 9.
- **Widget y pantalla de bloqueo** (111-112): la propia especificación los llama "futuro", y una PWA
  en iOS no puede hacerlos.

### Verificación
**2772 comprobaciones y 10 reglas invariantes en verde** (antes 2679), 85 de la mochila y 276 casos
de renderizado. `package.json` → **v1.59.0**.

⚠️ Sin probar: la pantalla, los gestos y el recordatorio de las 21:00. Como todo desde R1.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes de siempre: bucket `armario` (AR F1) y
bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 6 — Calendario, agenda y sistema HOY (v1.58.0)

### HOY es ahora la primera pantalla del horario
Cuatro tarjetas, en el orden de las preguntas que uno se hace al abrir la app:

**AHORA** (qué estoy haciendo, y cuánto le queda) · **SIGUIENTE** (qué viene, y en cuántos minutos) ·
**PENDIENTE** (qué se me olvida) · **MAÑANA** (qué preparo esta noche).

Es una vista más dentro del módulo Horario, la primera y la que sale por defecto. **La barra inferior
sigue teniendo cinco pestañas**: un módulo nuevo entra en un área existente, nunca en la barra.

### No guarda una copia de nada
El apartado 102 decide la forma del archivo entero: *"HOY no almacenará una copia independiente de
todo. Consultará las entidades originales."*

Así que `hoy.js` es una función de lectura y nada más. Completar una tarea desde Productividad cambia
HOY sin que HOY se entere, y hay una prueba que lo demuestra. Si guardara "las cosas de hoy" habría
dos verdades, y la copia empieza a mentir en cuanto se toca la original.

### El 90 % del trabajo fue no volver a construir
La especificación describe HOY como si el proyecto empezara de cero. No empieza:

- **Los eventos de otros módulos** ya los reúne `eventosDerivados`, del Calendario, con exámenes,
  tareas, entrenamientos y objetivos. Se lee de ahí; no hay un segundo recolector.
- **La línea del día, los huecos, los conflictos y los avisos** ya estaban en `horario.js` desde
  HT F1.
- **La puntuación del día** (apartado 37) ya es `puntuacion.js`, la del Dashboard. Una segunda daría
  dos números distintos para el mismo día, que es peor que no tener ninguno.

Lo que faltaba de verdad era **la pregunta**: qué pasa ahora, cuánto queda, qué viene, qué está
pendiente y en qué orden. Eso es `contextoTemporal()`, que responde las ocho preguntas del apartado
101 en una sola llamada — porque si cada tarjeta preguntara por su cuenta, acabarían diciendo cosas
distintas.

### Una tarea vencida no desaparece
El apartado 33 es explícito. Sigue arriba del todo, diciendo cuántos días lleva, y con las dos cosas
que hacen falta a un toque:

- **Completar sin abrir Productividad** (apartado 35).
- **Reprogramar en un toque** (apartado 34): mañana, este fin de semana o la semana que viene.

Y "este fin de semana" pedido un domingo por la tarde es el sábado **que viene**, no el de ayer.

### Un día sin nada no es una pantalla rota
El apartado 69 lo pide con esas palabras. Un domingo vacío dice que no hay nada programado y ofrece
montar el día; un festivo dice que es día libre. Los dos casos tienen su prueba de renderizado.

Y un domingo **no dice "clase pendiente"** si el horario escolar es de lunes a viernes (apartado 70).

### El contador baja solo
*"El contador deberá actualizarse automáticamente sin recargar la página."* (apartado 5)

Un tic de un minuto basta, porque el número se dice en minutos. Sin él, "empieza en 42 min" se
queda congelado y sigue diciendo 42 cuando la clase empezó hace diez.

### Los avisos se agrupan en uno
*"No se debe bombardear al usuario."* (apartado 81) Un mensaje —"tienes 3 cosas importantes hoy"— en
vez de tres avisos, con las tres prioridades del apartado 82: una tarea vencida y un examen mañana
son altas; algo de dentro de una semana, baja.

Aquí se **describen**. Mandarlas es la Fase 10, y el proyecto ya tiene su emisor: dos darían dos
avisos por lo mismo.

### Un bug que dejaba la pantalla en blanco
`lineaDelDia` devuelve el día entero —eventos, en curso, festivo, total, minutos—, no una lista.
Tratarlo como un array reventaba con `linea.map is not a function`. Lo cazó su propia prueba antes
de llegar a ninguna pantalla.

### Lo que no se ha construido, y por qué
- **Arrastrar bloques** (30-31): misma decisión que HT F3 — en móvil manda "Mover a…".
- **Recordatorios, ubicación y tiempo de desplazamiento** (47-52): los recordatorios son la Fase 10;
  el desplazamiento necesita mapas, que el proyecto no tiene ni ha pedido.
- **IA proactiva y planificar desde un hueco** (59, 61, 66-67): es la Fase 9. Aquí está el contexto
  que la alimentará, y la IA nunca se dispara sola (regla 7).
- **Centro de notificaciones** (83): ya existe uno. Un segundo historial sería la duplicación que el
  apartado 102 prohíbe.
- **Comando rápido** (108-109): el buscador global de BI F3-F4 ya es exactamente eso, y D2-07
  prohíbe una cuarta lista.

### Verificación
**2679 comprobaciones y 10 reglas invariantes en verde** (antes 2596), 83 del motor temporal y 268
casos de renderizado. `package.json` → **v1.58.0**.

⚠️ Sin probar: el contador que baja solo en pantalla, el aspecto en un iPhone y el recorrido tocando.
Como todo desde R1.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes de siempre: bucket `armario` (AR F1) y
bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 5 — Asignaturas, actividades, colores, iconos y contexto (v1.57.0)

### "Biología" deja de ser una palabra dentro de una celda
Ahora es una entidad con identidad, color, icono, nombre corto, alias, etiquetas, profesor, aula,
material, notas, exámenes y tareas — y con una ficha que las junta todas.

Tocar el nombre de una clase en el horario abre esa ficha. Y hay una lista de todas las asignaturas,
porque una archivada ya no tiene ningún bloque y aun así hay que poder abrirla para recuperarla.

### Todo lo que se puede derivar, se deriva
Es la decisión que gobierna la fase entera. Los usos, el tiempo semanal, las más utilizadas, las
recientes y la carga de cada día **no se guardan en ninguna parte**: salen de los bloques.

Un contador de "veces usada" empieza a mentir en cuanto se borra un bloque. Y ese número es
precisamente el que decide si una asignatura se borra o se archiva: "Biología está en 6 clases"
diciendo 6 cuando quedan 4 sería peor que no decir nada.

Lo único que se guarda es lo que no se puede calcular: que Josué la marcó como favorita.

### Nunca se fusionan dos actividades solas
Antes de crear "Biología" el sistema mira si ya existe — sin importar tildes ni mayúsculas — y
enseña también las parecidas: "Biología 2", "Biología y Geología".

El apartado 57 lo dice literalmente: *"no deberá fusionar automáticamente entidades ambiguas"*.
Pueden ser dos asignaturas de dos cursos distintos, y juntarlas no se deshace. Se enseñan las tres y
elige Josué.

### Las notas privadas no llegan a la IA
El apartado 52 permite guardar una nota privada: *"recordar preguntar por la recuperación"*. El 73
dice que la información adicional es privada por defecto.

Así que la nota **sale en la ficha** —que es la pantalla de Josué— y **no viaja en el contexto que
se le manda a la IA**. Hay una prueba que falla si aparece. Lo que no sale de aquí no puede acabar
en un servidor.

Y el contexto para la IA devuelve **estructura, no un texto**, sin llamar a nadie (regla 7).

### Borrar avisa primero, y recomienda archivar
*"Biología está utilizada en 6 bloques, 4 tareas y 1 examen."* (apartado 58)

Se calcula antes de decidir y la opción recomendada es archivar: una asignatura del curso pasado
tiene exámenes, notas y horas de estudio colgando. Si no la usa nada, se dice también, y entonces
borrar no se lleva nada por delante.

Y si se borra de todas formas, **los bloques no desaparecen**: se quedan sin actividad. Perder la
hora de una clase por haber borrado la asignatura sería mucho peor que un hueco que se rellena — la
misma decisión que HT F1 y AR F2 ya tomaron.

### Las tareas se dicen como lo que son
Los exámenes se enlazan de verdad, por `asignaturaId`. Las tareas de Productividad **no tienen campo
de asignatura**, así que se enseñan las que mencionan la actividad por su nombre, y debajo pone:
*"salen las que escribiste con su nombre: las tareas todavía no se pueden enlazar a una asignatura"*.

Fingir un enlace que no existe habría sido un dato inventado (regla 8).

### Oculta no es archivada, y el color del bloque no es el de la asignatura
Dos distinciones que la especificación pide y que juntar habría roto algo:

- **Oculta** es "existe y sigue viva, pero no la quiero ver aquí"; **archivada** es "esto es del
  curso pasado". Sin las dos, el "Trabajo personal" del apartado 51 —que sale en HOY pero no en el
  horario escolar— sería imposible.
- El color va **bloque → actividad → grupo → acento**. Marcar un examen en rojo **no repinta
  Biología entera** (apartado 44).

### Un bug que se habría comido la pantalla
Una actividad puede tener madre (apartado 63: Estudios → Biología, Física, Matemáticas). Sin
comprobarlo, nada impedía ponerse a sí misma de madre — o a su propia abuela — y pintar el árbol se
habría colgado en un bucle, dejando la pantalla en blanco. `puedeSerPadre` recorre la cadena antes
de aceptar.

### Y otro que perdía datos, por tercera vez
`grupos` no estaba ni en el estado por defecto ni en el normalizador, así que se habría perdido en
el siguiente guardado. Es el mismo fallo de HT F2 (`visible`) y HT F4 (`archivado`). Esta vez se vio
antes de que llegara a pasar.

### Verificación
**2596 comprobaciones y 10 reglas invariantes en verde** (antes 2468), 116 de las actividades y 252
casos de renderizado. `package.json` → **v1.57.0**.

⚠️ Sin probar: la ficha en pantalla, el selector de iconos y el recorrido tocando en un iPhone. Como
todo desde R1.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes de siempre: bucket `armario` (AR F1) y
bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 4 — Configuración avanzada de columnas, filas y bloques (v1.56.0)

### Todo detrás de un solo botón
*"Toda la potencia estará disponible, pero sin complicar la interfaz básica."* (apartado 63)

Esta fase añade semanas A/B, generación de franjas, búsqueda, zoom, densidad, archivado y validación
estructural. Si todo eso apareciera en la cuadrícula, la pantalla de todos los días sería ilegible en
un iPhone. Así que vive entero detrás de **"Opciones avanzadas", dentro del modo edición**: quien
solo quiere mirar qué le toca ahora no ve ni uno de esos controles.

### Nada se mueve en silencio
El apartado 30 es el que manda sobre toda la fase: *"No se deben mover datos silenciosamente."*

Regenerar la rejilla de horas puede dejar clases fuera de sitio. Eliminar una columna puede llevarse
bloques por delante. Cambiar el horario de una franja puede descolocar lo que había dentro.

Las tres operaciones **calculan el impacto y lo enseñan antes de escribir**, con el número exacto de
clases afectadas y un botón de "Hacerlo igualmente". Nunca se escribe primero y se avisa después.

Y regenerar las franjas **no mueve ni un bloque**: conservan sus horas, solo pierden la fila a la que
apuntaban. Las filas son la rejilla visual; los bloques guardan sus propias horas desde HT F2.

### Las semanas A/B se calculan, no se guardan
Un horario puede alternar entre semana A y semana B, hasta ocho semanas de ciclo.

**La semana en la que estamos se calcula desde una fecha ancla.** Guardar "esta semana es la B" sería
un contador, y un contador miente en cuanto pasa un lunes sin abrir la app — el mismo error que RA F1
evitó con las rachas.

Y **sin ancla no se adivina**: se enseña la semana A y se dice por qué. Adivinar sería peor que no
alternar, porque haría desaparecer clases sin motivo aparente.

Una columna sin grupo vale para todas las semanas del ciclo, que es lo que permite tener "Lunes"
fijo y solo "Miércoles A/B" alternando.

### Archivar no es borrar, y bloquear no es ocultar
Dos distinciones que la especificación pide expresamente (apartados 56 y 8):

- Un horario **archivado** sale del selector y deja de resolver fechas, pero sus bloques siguen
  guardados y se recupera de un toque. Y si están **todos** archivados, la pantalla vacía ofrece
  recuperarlos — si no, sería un callejón sin salida.
- Una columna **bloqueada** se sigue viendo y sigue resolviendo fechas: solo no se edita sin querer.

### El zoom del móvil no cambia el del ordenador
El apartado 59 separa configuración local de configuración en la nube. Aquí la línea está clara:
**estructura y datos a Supabase, preferencias de vista al aparato.**

El zoom (60–140 %) y la densidad de las filas van a `localStorage`. Sincronizarlos haría que
ajustarlos en el iPhone estropeara la vista en el ordenador, que no tiene la misma pantalla.

El zoom escala **alto y ancho** de la cuadrícula. Escalar solo hacia abajo dejaría las columnas
igual de estrechas y el nombre de la asignatura igual de ilegible.

### Un bug que perdía datos, otra vez el mismo
El normalizador de `horario.js` no conocía `archivado`, `icono`, `color`, `zonaHoraria` ni `ciclo`,
así que **archivar un horario funcionaba hasta el siguiente guardado**, y entonces volvía solo. Es
exactamente el fallo que HT F2 tuvo con `visible` y que el comentario encima de la función avisa de
que puede repetirse. Lo cazó su propia prueba.

### Una configuración extrema no puede destruir la app
El apartado 20 lo pide y hay dos topes que lo cumplen: el generador de franjas **no pasa de 40
filas** (un intervalo de 1 minuto sobre doce horas daría 720 y dejaría la app inservible) y el ciclo
de semanas se **acota a 8** en vez de descartarse — devolver 1 apagaría el ciclo entero por un
dedazo, y las clases alternas desaparecerían sin que nada lo explicara.

### Lo que no se ha construido, y por qué
- **Bloques multifila y multicolumna** (15-18): el modelo ya los permite, falta pintarlos estirados.
  Es trabajo de cuadrícula y va con la Fase 5, donde se rehace la celda.
- **Atajos de teclado** (42): Josué trabaja desde el iPhone. Sería un control decorativo.
- **Versionado, importar, exportar, imprimir y compartir** (46-52): la propia especificación llama al
  46 *"versionado futuro"*, exportar e imprimir son de la Fase 12, y compartir depende de decisiones
  de privacidad que Josué no ha tomado.
- **Cambio de hora** (54): el cambio de hora español no mueve las clases. No hay nada que construir.
- **Rendimiento de horarios enormes** (60-62): un horario de instituto son 5 columnas y 7 franjas.

### Verificación
**2468 comprobaciones y 10 reglas invariantes en verde** (antes 2308), 121 de la configuración
avanzada y 240 casos de renderizado. `package.json` → **v1.56.0**.

⚠️ Sin probar: el zoom y la densidad en pantalla real, el aspecto en un iPhone y el recorrido
tocando. Como todo desde R1.

⚠️ **Ningún SQL nuevo.** Siguen los dos bloques pendientes de siempre: bucket `armario` (AR F1) y
bucket `fondos` (FO F2).


## Entrega 2 · HT Fase 3 — Editor visual de horarios (v1.55.0)

### Un módulo nuevo: Horario
En el área Vida, junto al Calendario. La barra inferior sigue con cinco pestañas.

Dentro: cuadrícula de la semana, vista de día, agenda, acceso a HOY, y un interruptor entre **modo
consulta y modo edición** — que en un iPhone no es estética: los controles de añadir, mover y borrar
ocupan media pantalla, y el 95 % de las veces solo se quiere mirar qué toca ahora.

### Montar un horario tiene que ser minutos, no media hora
Tocar una celda, escribir "Matemáticas", Enter. El sistema busca si ya existe, la reutiliza si sí, la
crea si no, le pone un color automático y guarda.

El paso que importa es **reutilizar**: escribir "Matemáticas" otro día usa la misma actividad, con su
mismo color. Sin eso habría cuatro Matemáticas de cuatro colores, y no habría forma de cambiar el
color de la asignatura de una vez.

Y el autocompletado sugiere también **las asignaturas de Estudios que aún no están en el horario** —
sin eso, apuntar a Estudios en vez de duplicarlas no serviría de nada en la práctica.

### "Solo este lunes" no puede cargarse todos los lunes
Es lo más delicado de la fase. Cambiar la hora de Matemáticas porque hoy hubo un cambio de aula no
puede modificar todos los lunes del curso.

Se resuelve con dos alcances, y **sin valor por defecto**: si no se dice cuál, no se escribe nada. Un
defecto silencioso sería justo el error que el apartado quiere evitar, y sería irreversible sin darse
cuenta. "Solo este día" crea una excepción; el horario base no se toca.

### Cuatro cosas que no se han construido porque ya existían
Autoguardado, sincronización, deshacer y rehacer. Cada operación entra por `snapshotAndSave`, que
guarda y alimenta el "Deshacer" global — y ese cubre literalmente la lista del apartado 38: eliminar
bloque, mover bloque, cambiar color, eliminar fila, eliminar columna. Un segundo autoguardado daría
dos sistemas escribiendo la misma clave.

### Sin drag & drop, y es una decisión
El apartado 25 lo pide *"en dispositivos compatibles"*; el 26 exige que en móvil exista igualmente
"Mover a…". Se ha construido lo segundo, que es lo que Josué va a usar desde el iPhone. El arrastre se
añade encima sin tocar nada, porque acabaría en la misma función.

Y mover **conserva la duración**: arrastrar una clase de una hora a otro sitio no puede convertirla en
una de diez minutos.

### Detalles que evitan perder cosas
- **Eliminar una franja no borra los bloques que caen en ella.** Las filas son la rejilla visual; los
  bloques guardan sus propias horas. Quitar la fila de las 10:00 no puede hacer desaparecer la clase
  de las 10:00.
- **Duplicar un día sobre otro que ya tiene clases se rechaza**, con el número. Forzar sustituye, no
  acumula: es lo que espera quien dice "haz el martes igual que el lunes".
- **Un conflicto se detecta antes de escribir.** Forzar existe, pero hay que pedirlo.
- **Importar exige revisar**: la previsualización no escribe nada y aplicar solo acepta lo que salió
  de ella. Y avisa de las actividades que ya existen, para no crear una segunda Matemáticas.

### La columna de horas se queda fija
Con siete días no caben en 390 px. La hora vive **fuera** del contenedor que hace scroll, no con
`position: sticky`: en iOS, `sticky` dentro de un scroll horizontal es irregular, y aquí la solución
simple es además la robusta.

### Verificación
**2308 comprobaciones y 10 reglas invariantes en verde**, con 224 casos de renderizado. Los veinte
criterios de aceptación comprobables tienen prueba propia. `package.json` → **v1.55.0**. Van 32 de
las 106 fases; quedan 74.

⚠️ **Lo que sigue sin probarse, y se dice en la propia salida:** el aspecto en un iPhone, los gestos
y el modo oscuro.

## Entrega 2 · SO Fase 1 — Sistema global de sonido (v1.54.0)

### Lo primero: hoy no suena nada, y está dicho
**No hay ni un archivo de audio en el proyecto**, y el apartado 38 prohíbe crearlos: *"En esta fase
NO quiero: biblioteca completa de sonidos…"*. El 21 lo remata: *"Esta fase solo necesita dejar la
arquitectura lista."*

Así que el motor está entero y no suena — que es exactamente el camino de fallback del apartado 25
(*"si tampoco existe: silencio"*), no una función a medias. En cuanto los archivos estén en
`public/sonidos/`, suena sin tocar una línea de código.

Y **el sonido está apagado de fábrica**, a propósito: encenderlo sin biblioteca daría un interruptor
que dice "Sonidos: sí" y no suena nunca.

### Una regla invariante nueva
*"Queda prohibido crear lógica como `new Audio(...)` repartida por la aplicación."*

`verificar.sh` ahora **falla si `new Audio(` o un contexto de audio aparecen fuera de
`audioEngine.js`**, aunque sea dentro de un comentario. Sin ella, el primer botón que quiera sonar se
traería el suyo y el motor dejaría de ser central: no se le aplicarían ni el volumen por categoría,
ni el cooldown, ni las colisiones. Me cazó a mí dos veces escribiendo esta misma fase.

### Nunca como una máquina tragaperras
Completar un entrenamiento puede disparar `ACTION_COMPLETED`, `STREAK_CONTINUED` y `SUCCESS` casi a
la vez. Suena **una** vez: dentro de una ventana de 180 ms solo pasa lo más importante.

Y veinte toques rapidísimos en un botón dan **un** sonido, no veinte. Las dos cosas tienen su prueba
con ese caso exacto.

### Web Audio API, y por qué
Con un `<audio>` solo se pierde una de las siete prioridades que pide la especificación — pero es la
que sostiene el apartado 8: **un elemento tiene un `volume` y nada más**. "Interfaz al 30 % y Rachas
al 90 %" habría que calcularlo a mano en cada reproducción, y no habría forma de bajar una categoría
entera de golpe. Con Web Audio es un `GainNode` por categoría, que es la forma exacta del problema.

Además iOS limita cuántos `<audio>` suenan a la vez. Sin librerías: hacen falta un contexto, un nodo
por categoría y un `fetch`.

### iOS no se intenta esquivar
Safari crea el contexto suspendido y no deja reanudarlo sin un gesto. El motor se engancha al primer
toque y se desbloquea ahí. Hasta entonces **no falla: simplemente no suena**. Y hay **un solo
contexto**, creado en ese primer toque y no al arrancar.

### El bus, y lo que deliberadamente no hace
No había Event Bus en el proyecto, así que se ha creado uno ligero. **No define ni un evento propio
de rachas**: los de RA F3 llegan con sus nombres y se traducen con dos alias. Redefinirlos habría
dejado dos catálogos separándose con cada fase.

Rachas no sabe que existe el audio, y el audio no sabe qué es una racha. Cuando lleguen haptics,
notificaciones o analítica, se enganchan al mismo bus.

Y un suscriptor que revienta **no tumba al emisor**: si el motor de audio falla, el entrenamiento
queda guardado igual.

### El sonido nunca es el único canal
El apartado 35 lo pide, y no se puede imponer con una comprobación… salvo **no dándole al motor
ninguna forma de suprimir la interfaz**. La decisión solo dice si suena y por qué. Hay una prueba que
falla si aparece un campo que pudiera usarse para ocultar algo.

### Verificación
**2176 comprobaciones y 10 reglas invariantes en verde**. `package.json` → **v1.54.0**. Van 31 de las
106 fases; quedan 75.

⚠️ **Lo que no se ha podido comprobar aquí, y se dice en la propia salida de las pruebas:** iOS,
Android, PWA y navegador de escritorio. Son del navegador real.

✅ **C-23 queda resuelta a medias:** Josué pasó el texto que faltaba. ⏸ Siguen faltando **los archivos
de audio**, que él dará *"cuando la web ya tenga todos los botones activos"*.

## Entrega 2 · HT Fase 2 — Modelo de datos, Cloud y Supabase (v1.53.0)

### Ni una tabla nueva, ni un SQL que ejecutar
La especificación propone trece tablas —`schedules`, `schedule_columns`, `schedule_blocks`,
`subjects`, `materials`…— y en el apartado 51 dice cómo decidir: *"HORARIO TOP no podrá crear una
arquitectura incompatible con los demás módulos. La implementación final deberá adaptarse a la
arquitectura global del Sistema Personal."*

JosStyle no tiene una tabla por entidad. Tiene **una**, `app_data`, con RLS por usuario, que usan los
veintiún módulos. Trece tablas serían el segundo sistema de persistencia del proyecto y **trece
bloques de SQL que ejecutar a mano desde el iPhone**.

Así que lo que en PostgreSQL serían restricciones son aquí funciones que se ejecutan de verdad: los
índices son mapas, las validaciones son código, el `user_id` no existe —no hay ninguno que falsear— y
el borrado reversible es la papelera que ya tiene el proyecto.

### El curso pasado deja de resolver solo
Un horario ya no tiene solo una etiqueta de periodo: tiene `desde` y `hasta` de verdad, y
`resolverDia()` los respeta. Acabado junio, el horario 26/27 deja de aparecer sin que nadie se
acuerde de desactivarlo, y sus bloques siguen guardados.

### Los materiales dejan de ser textos sueltos
En la Fase 1 el material era `['Libro', 'Libreta']` dentro de la actividad. Con textos, "Libreta" en
Biología y "Libreta" en Matemáticas eran dos cosas distintas que solo se parecían al escribirlas.

Ahora son entidades con su enlace, y la migración **une las repetidas**: tres asignaturas con libreta
dan **un** material y tres enlaces, no tres libretas. Pasarla dos veces no duplica nada, y el texto
original se conserva para que sea reversible.

### La mochila es una consecuencia, no una lista
*"La mochila será una consecuencia de los datos existentes y no una lista completamente
independiente."* `mochilaDelDia()` deriva: horario → actividades → material. Lo único que se guarda
es lo que no se puede derivar — si ya está metido, y lo que se añada a mano.

Y agrupa: "Libreta — para Biología y Matemáticas", no dos libretas. Con cinco clases al día, la
diferencia es entre una mochila útil y una lista de veinte cosas repetidas.

### El calendario no se duplica
Catorce días de agenda **no crean catorce registros**: se calculan. El horario aporta eventos
derivados con `origen` y `origenId` al calendario común que ya existe — exactamente los `source` y
`source_id` que pide la especificación.

### Cuando dos dispositivos cambian lo mismo
`detectarConflicto()` usa los timestamps para decir "esto lo cambió otro dispositivo después de que
tú lo abrieras". **Detecta y avisa; no resuelve**: la especificación dice que *"no se deberá
sobrescribir información silenciosamente sin criterio"*, y quién gana es una decisión que deja para
más adelante.

### Tres bugs míos, y uno perdía datos
1. **El normalizador de horarios tiraba los campos nuevos de columnas y filas.** Ocultar el sábado
   funcionaba… hasta recargar la app: `crearColumna` escribía `visible`, pero el normalizador no lo
   conocía y se perdía en el primer guardado.
2. **Un item de mochila añadido a mano se borraba solo**, porque el normalizador exigía un
   `materialId` que un "Bocadillo" escrito a mano no tiene.
3. **`validarHorario` no detectaba un nombre vacío**, porque miraba el objeto ya normalizado y el
   normalizador lo rellena con la etiqueta del tipo.

Los tres los cazaron sus propias pruebas.

### Verificación
**2085 comprobaciones y 9 reglas invariantes en verde**, build incluido. `package.json` →
**v1.53.0**. Van 30 de las 106 fases; quedan 76.

⏸ **Queda confirmado lo que HT F1 dejó abierto:** el horario se guarda en `app_data` con la clave
`horarioTop`. Sin tabla nueva y sin SQL pendiente.

## Entrega 2 · HT Fase 1 — Arquitectura de Horario Top (v1.52.0)

### Esta fase no pide construir: pide definir
*"No estamos construyendo todavía la interfaz definitiva, la base de datos definitiva, el editor
definitivo, la mochila, las notificaciones ni la IA. Estamos estableciendo cómo debe funcionar todo
el ecosistema antes de empezar a construirlo."*

En este proyecto eso ha significado siempre lo mismo: **un módulo puro y probado, no un documento.**
Un documento se contradice con el código en la segunda fase; un modelo con 131 comprobaciones no
puede. `src/lib/horario.js` es el ecosistema entero como código, **sin una sola pantalla**.

### El horario es una regla, no una lista de eventos
Es la distinción de la que cuelga todo lo demás. La regla base vive en `bloques` —"los martes a las
10:00 hay Biología"— y los cambios puntuales en `excepciones`. `resolverDia()` los compone al vuelo.

Materializarlo —crear cuarenta "Biología" para el curso— haría que cambiar la hora de la clase
obligara a editar cuarenta filas, y que un festivo tuviera que borrar seis. Es el mismo error que el
proyecto ya evitó en el Calendario.

Con esto: el mismo bloque resuelve en todos los martes del curso (probado con dos martes distintos),
cancelar un día no toca el siguiente, y **un festivo se declara una vez** en vez de cancelar seis
clases a mano. Y un festivo de instituto **no cancela el entrenamiento**.

### Las asignaturas no se duplican
*"Si el usuario crea Biología, no debería tener que volver a escribir «Biología» para Horario,
Tareas, Exámenes, Mochila y Estudios."*

Y JosStyle **ya tiene las asignaturas de Josué**, en `estudios.asignaturas` desde la Fase 6. Así que
una actividad escolar no las copia: **apunta a ellas**, y el nombre se resuelve al leer. Renombrar
"Bio" a "Biología" en Estudios lo cambia en el horario sin tocar el horario.

Sin esto habría dos "Biología" —una en cada módulo— y ningún examen podría enlazarse con su clase.

### Una columna guarda su día aparte de su nombre
Es la pieza que permite las dos cosas que pide la especificación a la vez: que "Martes" resuelva a
una fecha, y que "Semana A", "Persona 2" o "Proyecto 1" sigan siendo columnas posibles. Sin ese
campo habría que adivinar el día por el nombre, y "Semana A" no es ningún día.

Una columna sin día no cae en ninguna fecha — está probado, y es exactamente el hueco donde entrarán
las semanas A/B más adelante sin tocar el modelo.

### Los enganches de lo que viene, y solo los enganches
- **Mochila** (Fase 7): `materialDelDia()` agrupa y dice **para qué** hace falta cada cosa —
  "Libreta — para Biología y Matemáticas" es más útil que la libreta repetida dos veces.
- **Notificaciones** (Fase 10): `avisosDelDia()` **describe, no notifica**. Devuelve qué se podría
  avisar y a qué hora; quién avise es de esa fase. Así dos sistemas no mandan el mismo aviso.
- **IA** (Fase 9): `contextoIA()` devuelve estructura, no una lista de textos, y omite los campos
  vacíos. Y no llama a ninguna IA: la IA nunca se dispara sola.

### Dos decisiones que se llevan por delante un error futuro
1. **Borrar una actividad no borra sus bloques**: los deja sin actividad. Perder la hora de una clase
   porque se borró la asignatura sería mucho peor que quedarse con un hueco que se vuelve a rellenar.
2. **Un evento resuelto no tiene id propio.** No es una entidad guardada, es el resultado de componer
   otras; darle un id invitaría a guardarlo, que es justo lo que esta arquitectura evita.

### Un fallo mío, cazado por su propia prueba
`crearColumna({ dia: 9 })` reventaba. El día es *truthy* pero está fuera de rango, y se usaba para
construir el nombre **antes** de validarlo, así que indexaba una posición que no existe.

### Verificación
**1961 comprobaciones y 9 reglas invariantes en verde**, build incluido. `package.json` →
**v1.52.0**. Van 29 de las 106 fases; quedan 77.

⏸ **Lo decidirá HT F2, no esta fase:** dónde se guarda. Aquí se ha asumido `app_data` con la clave
`horarioTop`, por coherencia con los otros veintiún módulos y para no añadir SQL pendiente. **La
Fase 2 es literalmente la del modelo de datos y Supabase**, así que lo confirmará o lo cambiará con
su especificación delante. Nada de lo construido aquí depende de esa elección: el módulo es puro.

⏸ **SO · Sonido sigue esperando a Josué (C-23):** su Fase 1 no aparece en la especificación, y además
necesita archivos de audio que él dará cuando la web tenga todos los botones activos.

## Entrega 2 · RA Fase 4 — Centro de Rachas y experiencia visual (v1.51.0) 🔒 CIERRA EL BLOQUE RA

### Un módulo nuevo: Rachas
Vive en el área **Vida**, junto a Productividad, que es donde están los hábitos. La barra inferior
sigue teniendo cinco pestañas: un módulo nuevo entra en un área que ya existe, nunca en la barra.

Dentro: resumen (racha actual · mejor · logros), la racha principal grande, las demás compactas,
detalle con historial y calendario, logros, y los totales.

### No calcula ni un número
Todo viene de la capa de gamificación, que lo deriva del historial. Si esta pantalla dijera un
número distinto del Dashboard sería porque alguien contó por su cuenta — y aquí nadie cuenta.

### Una sola celebración, no cuatro avisos
Es lo que pide el apartado 19: si un mismo día trae hito, récord y logro, no pueden salir tres
tarjetas. `Celebracion` recibe la lista entera de eventos y saca **un** mensaje. Hay una prueba de
renderizado con los tres a la vez.

Y completar un día normal **no abre nada**: su feedback va en la propia tarjeta de la racha. Las
celebraciones grandes se reservan para 30, 100 y 365 días.

### La racha rota no castiga
Literalmente lo que pedía la especificación: *"La racha terminó. Hoy puedes empezar una nueva"*, con
el récord y el historial siempre visibles — *"el usuario nunca debe sentir que su progreso histórico
desapareció"*.

### El calendario, con puntos y no con emojis
La especificación proponía 🔥 por día, *"pero quiero algo más elegante si el sistema de iconografía
actual permite algo mejor"*. Una rejilla de puntos ocupa la mitad, se lee de un vistazo y —esto es
lo importante— **no distingue los estados solo por color**: completado es un punto lleno, perdido un
aro, pendiente un aro marcado. Con leyenda y `aria-label` por día.

### Sin colores propios, sin animaciones propias, sin sonido
- Los colores salen de `COLORS` y del acento del usuario, así que el modo claro y el oscuro
  funcionan **solos**.
- La única animación es la barra de progreso, y la gobiernan `prefers-reduced-motion` y el ajuste de
  animaciones de la Fase A3 desde `index.css`. No hay un segundo sistema.
- **Ni un archivo de audio en un componente** (apartados 20 y 38). La pantalla emite eventos; el
  sistema de audio los escuchará cuando exista.

### Un efecto secundario en el rendimiento
El resumen del hub de Rachas recorre historiales, y hasta ahora `resumenesTodos` en `App.jsx` se
recalculaba en cada render porque todo lo que había era barato. Ahora va memoizado.

### Cómo se ha resuelto el duplicado que dejó anotado RA F3
`logros.js` (Fase 20) tiene doce insignias de **toda la app**. Las de aquí son de **las rachas** y
son por racha, así que pueden ser muchas. Juntarlas daría una lista larguísima mezclando dos cosas
distintas, así que se quedan separadas: las de racha en el Centro de Rachas, las generales en
Logros. No es irreversible — si Josué las prefiere juntas, es mover una lista.

### Un hábito no se marca desde aquí
Aparece en el Centro con su racha, pero el botón de completar solo sale en las rachas propias: el
dato de un hábito vive en Productividad, y un segundo sitio donde escribirlo sería duplicar el
camino.

### Verificación
Las doce pruebas visuales del apartado 36, **montadas con el servicio real** y no con datos escritos
a mano: si el motor cambiara de forma, se enterarían. Los casos de renderizado suben de 140 a 192.
**1830 comprobaciones y 9 reglas invariantes en verde**, build incluido. `package.json` →
**v1.51.0**.

⚠️ **Lo que sigue sin estar probado, y hay que decirlo:** el aspecto real en un iPhone, los gestos y
el scroll. Como todo lo demás desde R1.

**Con esto el bloque RA queda cerrado: 4 de 4.** Van 28 de las 106 fases de la Entrega 2; quedan 78.

## Entrega 2 · RA Fase 3 — Gamificación, hitos, logros y progresión (v1.50.0)

### La frase que marca el tono
*"No quiero que el usuario sienta «tengo que usar la app para ganar puntos». Quiero que sienta
«estoy progresando en mi vida y la app me ayuda a verlo»."*

De ahí salen las tres decisiones que se notan en el código: sin XP ni niveles, doce logros en vez de
cien, y celebraciones que se reservan.

### Sin XP ni niveles, y dicho con claridad
Los apartados 14 y 15 los dejan en condicional: *"no conviertas automáticamente las rachas en
niveles si no es necesario"*, *"si decides preparar XP"*. Y no es necesario: no hay nada que gastar
ni con qué compararse. Un contador de XP sin uso sería un control decorativo.

Lo que sí queda es el punto de enganche: los eventos llevan los días y el hito, que es todo lo que
necesitaría una capa de XP futura. Y por D2-02, si llega, se queda dentro de Rachas y Sonido.

### Un hito se anuncia una sola vez
Un evento derivado del estado se emitiría cada vez que alguien mirase la pantalla. Por eso se apunta
qué hitos ya se anunciaron, por racha. Y al volver después de una semana fuera se anuncian **todos
los intermedios**, no solo el último: llegar a 30 días no puede saltarse el 7, el 14 y el 21 en
silencio.

### La barra de progreso se mide desde el hito anterior
Con 25 días y el siguiente hito en 30, va por el **44 %**, no por el 83 %. Medirlo desde cero haría
que la barra apenas se moviera entre 200 y 365 días.

### No se puede hacer trampa, por construcción
El apartado 27 lo pide con nombre: `currentStreak = 1000` no debe desbloquear nada sin días reales
detrás. Aquí se cumple sin vigilar nada, porque **el contexto no acepta ningún número de fuera**: lo
pide todo al servicio, que lo deriva del historial de cumplimientos. Y un logro inyectado a mano que
no esté en el catálogo se descarta al cargar.

### Un logro conseguido no se pierde
Es la decisión que había que tomar (apartado 28). Josué cumplió treinta días seguidos; corregir
después un entrenamiento mal apuntado no deshace haberlos cumplido, y quitarle el logro por eso
sería castigarle por ordenar sus datos. Los números —racha, récord, progreso— sí se corrigen solos,
porque se derivan. `revisarLogros()` **informa**; revocar es una decisión explícita, y solo ocurre
sola al borrar la racha entera.

### La racha global no es max()
El apartado 22 lo prohíbe expresamente. La condición aquí es "días seguidos cumpliendo al menos una
racha", y hay una prueba que lo demuestra: **dos rachas que se turnan dan una global mayor que
cualquiera de las dos**, que es imposible con un máximo.

### Dos expectativas mías mal puestas
Con la lista de doce hitos, el siguiente después de 17 días es **21**, no 30. Y con 5 días los hitos
alcanzados son dos (el 1 y el 3), no tres: **5 no es un hito**. El código estaba bien las dos veces.

### Verificación
**Las diez pruebas que pide el apartado 34**, una por una y marcadas como tales. **1778
comprobaciones y 9 reglas invariantes en verde**, build incluido. `package.json` → **v1.50.0**. Van
27 de las 106 fases; quedan 79.

⚠️ **Un duplicado anotado para RA F4:** el proyecto ya tiene `src/lib/logros.js` (Fase 20) con doce
insignias de toda la app, dos de ellas de racha. Los logros de aquí todavía no tienen pantalla, así
que hoy no hay duplicación visible; cuando F4 construya el Centro de Rachas habrá que decidir si son
dos listas o una.

## Entrega 2 · RA Fase 2 — Persistencia, seguridad y sincronización (v1.49.0)

### Ni una tabla nueva, ni un SQL que ejecutar
La especificación propone tablas `streaks` y `streak_days` en Supabase, y acto seguido dice: *"No
copies estos nombres obligatoriamente si el proyecto ya utiliza otra convención"*, y *"No dupliques
sistemas existentes"*.

JosStyle tiene una convención: **una sola tabla `app_data`**, una fila por usuario y clave, con RLS
por `auth.uid()`, que usan los veinte módulos. Las rachas entran ahí. Montar tablas propias habría
sido el segundo sistema de persistencia del proyecto **y un tercer bloque de SQL que Josué tendría
que ejecutar a mano desde el iPhone** —ya tiene dos pendientes— sin el cual las rachas no
funcionarían.

Lo que en la especificación son políticas RLS y una restricción `UNIQUE`, aquí es:

- **Aislamiento entre usuarios** → las cuatro políticas de `app_data`, ya vigentes.
- **`UNIQUE(streak_id, local_date)`** → la clave lógica `racha + día`, aplicada en el servicio, que
  es el único sitio del proyecto que escribe cumplimientos.
- **Contadores no manipulables** → no existen. Mandar `{currentStreak: 9999}` no tiene dónde
  aterrizar, porque no se guarda ningún contador.

Y algo más fuerte que "no confiar en el `user_id` del cliente": **el modelo no tiene campo
`user_id`.** No hay ninguno que falsear. Hay una prueba que comprueba que la palabra no aparece.

### Un solo sitio escribe rachas
`src/lib/rachasServicio.js`. Dashboard, Productividad y lo que venga después llaman ahí; ninguno
toca Supabase ni recalcula por su cuenta. Los hábitos, que guardan su historial en su propio módulo
desde la Fase 8, también se consultan por el servicio: no se ha migrado su dato —es de Josué y
moverlo no aporta nada— pero sí su camino.

Con él llega `src/hooks/useRachas.js`, el hook central. No añade lógica: envuelve el servicio y
memoiza lo caro, para que el panel se calcule una vez por cambio real de estado y no una por render.

### La cola offline funciona por una sola razón
Reintentar es idempotente. Un cumplimiento que se reenvía cinco veces sigue siendo **un** día — hay
una prueba que lo hace. Sin esa propiedad, una cola offline infla rachas; con ella, no puede.

### Cuando se borra la actividad que sostenía la racha
Es el caso que la especificación describe con detalle: un entrenamiento genera un cumplimiento, la
racha llega a 15, y después se borra ese entrenamiento. Con contadores guardados habría que
acordarse de decrementar. Aquí basta con que desaparezca el día: **el número se corrige solo**,
porque nunca estuvo guardado. Lo que faltaba era poder encontrar el cumplimiento a partir de su
actividad, y para eso cada uno guarda ahora `origen` y `origenId`.

### Sobre TypeScript, con honestidad
El apartado 22 pide tipos y evitar `any`. **El proyecto no usa TypeScript**: es JavaScript con Vite
y no hay un solo `.ts` en `src/`. Meterlo por un módulo obligaría a configurar el compilador para el
resto. El equivalente honesto es lo que se ha hecho: `@typedef` para las cuatro entidades —que el
editor sí lee— y, sobre todo, **normalizadores que se ejecutan de verdad**. Un typedef avisa; un
normalizador impide.

### Un fallo mío, cazado por su propia prueba
La revisión de integridad buscaba los contadores corruptos **después** de normalizar, y el
normalizador ya los había descartado al pasar. Que el motor sea inmune a ellos es bueno; que la
revisión no pudiera avisar de que venían, no.

### Lo que todavía no tiene pantalla, y es deliberado
No hay forma de crear una racha desde la interfaz: el apartado 28 prohíbe expresamente el Centro de
Rachas en esta fase, que llega en RA F4. Lo que sí funciona hoy de punta a punta son los hábitos.

### Verificación
Los **diez casos que pide el apartado 27**, uno por uno y marcados como tales, más lo que sostiene
cada uno. **1660 comprobaciones y 9 reglas invariantes en verde**, build incluido. `package.json` →
**v1.49.0**. Van 26 de las 106 fases; quedan 80.

## Entrega 2 · RA Fase 1 — Motor de rachas (v1.48.0)

### El apartado 24 describía el código que ya teníamos
*"No hagas una solución rápida que simplemente incremente un contador."*

Pues eso era exactamente lo que había. Los hábitos de Productividad guardaban `rachaActual` y
`mejorRacha` como números sueltos, y al desmarcar el día de hoy le restaban uno al contador **a
mano**. Es decir: **desmarcar y volver a marcar el mismo día subía el récord** sin haber cumplido
nada — y con ello se desbloqueaba el logro "Un mes de constancia".

Ahora no se guarda ni un número. Racha actual, récord, historial y porcentaje salen del historial de
días, que es el mismo que ya estaba guardado. Nadie pierde nada y no hay migración destructiva.

### Un día en curso no es un día fallado
Es lo que más repite la especificación, y con razón. Con lunes ✅, martes ✅ y el miércoles todavía
por hacer, a las 10:00 de la mañana la racha vale **2 y está viva**, no 0 y perdida. Los cuatro
estados de un día están separados y no se mezclan: completado, perdido, pendiente y futuro.

### El día es el de Josué, no el del servidor
Cada cumplimiento guarda dos tiempos: el **día local**, que es el que decide la racha, y el instante
en UTC, que solo sirve para desempatar si dos dispositivos escriben a la vez. A las 23:59 cuenta
para hoy; a las 00:01, para mañana. Probado, junto con el fin de año, el cambio de mes y el 29 de
febrero de un bisiesto.

### Pulsar cinco veces no son cinco días
La clave lógica es `racha + día local`, y registrar un cumplimiento **sustituye**, nunca añade. Da
igual si se pulsa una vez o veinte, y da igual si dos dispositivos mandan lo mismo a la vez. Es
también lo que permitirá que una cola offline reintente sin inflar una racha.

### La regla de los hábitos se ha conservado tal cual
En JosStyle un fallo suelto no rompe una racha de hábito: se perdona. Esa regla llevaba ahí desde la
Fase 8, y en vez de cambiársela a Josué sin avisar se ha llevado al motor como una regla más
(`diaria_con_gracia`). Añadir "estudiar 30 minutos al día" es registrar otra entrada, no tocar el
motor.

Una regla **semanal** sería distinta: cuenta semanas, no días, y eso cambia el recorrido entero. Por
eso **no se ha fingido que existe** — el sitio exacto donde entraría está marcado en el código.

### Cuatro fallos reales, tres ya en producción
1. El récord de los hábitos se podía inflar. Una prueba lo intenta diez veces; ya no se mueve.
2. **Un hábito sin `historial` dejaba Productividad en blanco.** Nunca se había visto porque esa
   pantalla no se renderizaba en ninguna prueba; salió en cuanto se añadió.
3. La exportación podía no cuadrar con la pantalla: leía el contador, y la pantalla otra cosa.
4. Mío: `[].every()` es `true`, así que la primera racha de la vida "batía el récord" sin haber
   ningún récord anterior. Lo cazó su propia prueba.

### Lo que NO lleva, y es deliberado
Ni niveles, ni medallas, ni logros, ni recompensas, ni confeti, ni sonidos (apartado 22). Hay una
prueba que **falla si aparecen**. Y por D2-02, cuando lleguen, se quedan dentro de Rachas y Sonido.

### Verificación
**1556 comprobaciones y 9 reglas invariantes en verde**, build incluido. `package.json` →
**v1.48.0**. Van 25 de las 106 fases; quedan 81.

⏸ **Pendiente de Josué (regla 49, ficha C-23):** en `ESPECIFICACION_SONIDO_Y_RACHAS.md` el
encabezado *"Fase 1 — Arquitectura + motor global de audio"* va seguido del texto de *"Fase 4 ·
Sistema de Rachas: interfaz"*. Falta saber dónde está la Fase 1 real del Sonido y en qué orden van
los dos módulos. No bloquea nada de lo entregado aquí.

## Entrega 2 · FO Fase 12 — Eliminados, recuperación y cierre del bloque (v1.47.0)

### En Apariencia no se borra nada, y eso cambia el sentido de la fase
Cambiar de fotografía no borra la anterior de Storage. Quitar el fondo tampoco. En Salud o
Calistenia la papelera guarda el registro treinta días mientras el archivo desaparece; aquí el
archivo **sigue estando**, así que recuperar no es restaurar una copia — es volver a apuntar a algo
que nunca se fue.

Por eso esta fase no monta una papelera nueva. Reutiliza la de ME F3 para lo que sí se borra (los
presets) y añade una lista de fotografías sustituidas dentro del propio fondo para lo que no.

### Las fotografías sustituidas ya no se pierden
Hasta ahora, cambiar de foto dejaba el archivo en el bucket y **ninguna forma de volver a él**.
Ahora se guarda su ficha (hasta ocho, `MAX_FOTOS_ANTERIORES`) y aparecen en Ajustes → Apariencia →
Fondo con su miniatura, su fecha y sus medidas.

Recuperar una devuelve también **sus ajustes de entonces** —encuadre, zoom, luz, overlay— porque
`ajustesPorFoto` ya los guardaba desde la Fase 3. Y la que estaba puesta pasa a la lista, así que
recuperar tampoco pierde nada.

Olvidar una sí es irreversible, y es lo único de esta pantalla que pide confirmación.

### Los presets se podían crear y no borrar
El botón existía, pero se limitaba a filtrarlos de la lista: se perdían para siempre. Ahora pasan
por la papelera universal como todo lo demás. Es el noveno módulo con ese mismo fallo desde que
existe la verificación automática.

### Un preset con fotografía ahora lo dice
La miniatura de un preset se pinta sin firmar la URL de la foto (serían varias firmas a la vez para
un recuadro de 44 px), así que uno con fotografía enseñaba el fondo de respaldo y parecía un
degradado cualquiera. Ahora lleva su icono encima. Es la "dependencia detectada" que pide el
apartado 8: nada se rompe en silencio.

Borrar un preset no borra su fotografía, y olvidar una fotografía no borra los presets que la usen.

### Un error de test que valió la pena
La comprobación de que la lista conserva las más recientes fallaba por uno. La `h12` es la foto
**activa**, así que la primera de las *anteriores* es la `h11`. El código estaba bien; la
expectativa, mal.

### Verificación
**1414 comprobaciones y 9 reglas invariantes en verde**, build de Vite incluido. `package.json` →
**v1.47.0**.

**Con esto el bloque FO queda cerrado: 12 de 12.** Van 24 de las 106 fases de la Entrega 2; quedan
82, todas de módulos aún sin empezar — SR (5+4), HT (12) y EH (65).

⚠️ Siguen pendientes en el SQL Editor de Supabase los bloques de los buckets `armario` (AR F1) y
`fondos` (FO F2).

## Entrega 2 · FO Fase 11 — Rendimiento y optimización (v1.46.0)

### El problema real no era ninguno de los que uno se imagina
Las capas del fondo son CSS puro, el análisis va sobre una miniatura de 96 px y las propuestas son
aritmética. Lo caro era otra cosa: **la fotografía se subía y se servía a resolución original**.
Una foto de iPhone son 4032×3024 y unos 4 MB, y se estaba usando como fondo de una pantalla de
390 px de ancho.

Ahora se redimensiona a 1600 px de lado largo con JPEG al 82 % **justo antes de subir** — no al
elegir, porque entonces cada foto que mirases y descartaras pagaría el trabajo para nada.

Se aplicó también a las fotos de prenda del Armario, que tenían el mismo problema: megabytes para
pintar una miniatura de 150 px.

### Tres decisiones que evitan hacer daño al optimizar
1. **Nunca agrandar.** Escalar hacia arriba no añade detalle, solo peso.
2. **Si la copia pesa más, se queda la original.** Pasa con imágenes ya muy comprimidas.
3. **Si algo falla, se devuelve el original** en vez de lanzar: es peor una foto pesada que ninguna
   foto.

### Caché de URLs firmadas
Duran una hora, y sin caché cada vez que se montaba Ajustes se pedía otra firma para la misma foto.
Ahora, si hay una válida, el fondo aparece **al instante** en vez de parpadear.

Y una a punto de caducar **no se entrega**: se considera vencida un minuto antes, para no dar una
firma que expire mientras la imagen se está descargando.

### Un detalle que habría pasado desapercibido
Al optimizar hay que guardar **las medidas de la foto original**, no las de la copia. La proporción
y la orientación deciden el encuadre inicial, y calcularlo sobre la copia habría funcionado por
casualidad pero habría dejado en el modelo unas dimensiones que no son las de la imagen elegida.

### Verificación
**1380 comprobaciones en verde** (antes 1340): 40 de optimización de imágenes.

---

## Entrega 2 · FO Fase 10 — Integración completa en Aspecto (v1.45.0)

**Esta fase no añade funciones: ordena las que ya hay.** Después de las fases 1-9, Ajustes →
Apariencia había llegado a **trece tarjetas seguidas** — en un iPhone, una pantalla entera de
scroll para encontrar cualquier cosa.

### Vista previa global arriba del todo
Fondo, tarjeta, botón, texto, iconos y barra inferior, en una sola pieza. Es la referencia contra
la que se juzga cualquier cambio de los que hay debajo, sin salir de Ajustes.

Se pinta con **las mismas funciones y los mismos tokens que la app de verdad**. Una imitación
acabaría divergiendo y enseñaría algo que no es lo que se aplica.

### Seis secciones plegables
Fondo · Colores · Recomendado · Apariencias guardadas · Legibilidad · Texto y movimiento. Solo
**Fondo** viene abierta, y su subtítulo dice qué fondo hay puesto, así que se sabe sin abrirla.

### Lo que no se ha tocado, y es deliberado
Tema, acento, tamaño de texto, densidad, bordes y animaciones llevan ahí desde la Fase A3 y **Josué
ya sabe dónde están**. Se han agrupado, no reordenado ni renombrado: mover controles que alguien
tiene memorizados es una regresión aunque el orden nuevo sea mejor.

Tema y la vista previa quedan fuera de las secciones: son lo que más se toca.

### Dos roturas mías, cazadas por la compilación
Reorganizar por rangos de líneas partió un comentario JSX multilínea por la mitad y dejó una sección
sin cerrar. `esbuild` lo señaló con la línea exacta. Después se comprobó pieza por pieza que las
trece tarjetas originales siguen todas ahí.

### Verificación
**1340 comprobaciones en verde**, con 128 casos de renderizado.

---

## Entrega 2 · FO Fase 9 — Legibilidad y contraste inteligente (v1.44.0)

*"Libertad total para personalizar, pero con protección inteligente para que la interfaz siga
siendo usable."* Es la frase del apartado 1 y gobierna toda la fase.

### El problema difícil: ¿contra qué se mide?
Con una fotografía de fondo **no hay un color de fondo único**. Lo que hay detrás de un texto es la
tarjeta translúcida encima de la foto encima del tema. Medir contra `COLORS.bg` daría un número que
no describe lo que se ve — y un aviso falso enseña a ignorar los avisos.

Así que el fondo efectivo **se compone**, capa a capa, en el mismo orden en que se pinta: tema →
foto → luz → overlay → tarjeta. Y con el análisis de la Fase 5 se mide **por zona**: un texto
arriba no está sobre el mismo color que un botón abajo.

### Detectar no es corregir
Revisar no cambia nada. Los avisos traen **qué campo cambiar y a qué valor**, y aplicarlo es un
botón. El modo automático existe, pero **apagado de fábrica**: el apartado 8 dice "debe ser
opcional, nunca obligar".

Y nada se bloquea: un color flojo **se avisa, no se impide**.

### Cuando el problema es la foto, la solución no es cambiar el texto
El apartado 12 lo dice. Foto clara con interfaz oscura → se propone oscurecer **la foto**. Foto con
mucho detalle → un desenfoque ligero. Los colores se quedan en paz.

Y si ya lo habías resuelto —ya la habías oscurecido, ya tenías overlay, ya la habías desenfocado—
no se insiste.

### Dos falsos positivos sobre la propia app, cazados por las pruebas
1. **El texto de los botones.** La prueba ponía blanco a mano (4,28, por debajo de AA). La app no
   usa blanco: lo deriva con `bestReadableText`, que da 4,54. Estaba probando un color que la app
   nunca usa.
2. **La separación entre tarjeta y fondo.** JosStyle separa sus tarjetas **con el borde, no con el
   relleno** — la superficie es apenas más clara que el fondo (1,07) y se ve perfectamente porque
   cada tarjeta lleva su borde. Comprobar solo el relleno marcaba la apariencia de fábrica como
   rota. Ahora se miran las dos vías, y solo hay problema cuando fallan ambas.

### Y una limpieza de raíz
`NEGRO` y `BLANCO` viven ahora en `colorEngine.js` en vez de escribirse a mano en cada archivo que
compone capas. No son colores de interfaz —oscurecer es acercar al negro en tema claro y en
oscuro— así que no pertenecen a `tokens.js`.

### Verificación
**1332 comprobaciones en verde** (antes 1277): 47 de legibilidad y 120 casos de renderizado.

---

## Entrega 2 · FO Fase 8 — Presets de apariencia (v1.43.0)

Guardar tus colores **y tu fondo juntos**, y cambiar entre ellos de un toque.

### Un preset es la apariencia completa
Tema, acento, colores, transparencias, sombras, bordes, overlay **y la fotografía con sus
ajustes**. El sistema anterior (fase V4) guardaba solo los colores: media configuración. Aquí se
reutiliza ese mismo sistema —misma clave de Supabase, mismo estado, mismo límite— y lo único que
cambia es qué se guarda dentro.

### "Activo" dice la verdad
No se compara por id, porque el id no dice nada: puedes aplicar un preset y luego cambiar un color
a mano, y entonces **ya no estás usando ese preset** aunque fuera el último que tocaste. Se compara
una huella de lo que se ve — y de ahí quedan fuera el historial de encuadres y el análisis de
colores, porque no se ven.

### Los incluidos no se tocan, se duplican
JosStyle, Profundo, Claro y Minimal. Intentar actualizar uno **no hace nada** en vez de fallar, y
duplicarlo da un preset tuyo, editable: es la vía que da el propio apartado 14 para personalizarlos
sin perder el original.

Ninguno trae fotografía: una foto es de quien la hizo, y un preset de fábrica con una imagen de
archivo sería contenido inventado.

Y `accent: null` en ellos significa **"no toques el acento"**, no "ponlo a null": aplicar "JosStyle"
devuelve la app a su estado de fábrica **sin imponerte un color que no elegiste**.

### Un fallo que habría aparecido seguro
Aplicar un preset cambia cuatro cosas a la vez, y encadenar los tres setters existentes **habría
perdido el fondo o el tema sin dar ningún error**: cada uno guarda el paquete de ajustes entero
leyendo el resto del closure, y dos llamadas seguidas en la misma función no ven el `setState` de
la anterior. Lo evitó un aviso que la fase V4 había dejado escrito justo al lado.

### Verificación
**1277 comprobaciones en verde** (antes 1209): 60 de los presets y 112 casos de renderizado.

---

## Entrega 2 · FO Fase 7 — Personalización manual avanzada (v1.42.0)

Cierra un hueco que las fases anteriores habían abierto: **FO F4 metió en el modelo el texto
secundario, los iconos activo e inactivo y el fondo de la barra, pero sin control.** Se podían
guardar y no había forma de tocarlos. Ahora el constructor de temas los ofrece los diez.

### Bordes y sombras
El color del borde ya se podía cambiar; lo que faltaba era su **intensidad**. Un borde al 100 %
sobre una tarjeta translúcida encima de una foto se ve como una caja pegada; bajarlo la integra sin
quitarle la separación.

Las sombras son nuevas, con **tope bajo a propósito**: el apartado 11 pide evitar configuraciones
que hagan que la app parezca desordenada.

### Sin tocar nada, nada cambia
Cada añadido tiene su valor de fábrica igual al comportamiento anterior: sombra 0, borde al 100 %,
transparencias al 100 %. Es lo que permite añadir controles sin arriesgar una regresión visual.

Y sin sombra, `cardShadow` es `'none'`, no una sombra de opacidad cero: una sombra invisible sigue
costando pintado en cada tarjeta, y hay muchas por pantalla.

### Verificación
**1209 comprobaciones en verde** (antes 1193).

---

## Entrega 2 · FO Fase 6 — Sistema "Recomendado" (v1.41.0)

JosStyle propone **cinco apariencias completas** sacadas de los colores de tu foto: Equilibrada,
Con contraste, Serena, Intensa y Minimalista. Sin IA — teoría del color sobre lo que el detector
de la Fase 5 encontró de verdad.

### Cinco propuestas, y distintas de verdad
El apartado 8 lo dice con un ejemplo: azul #123456, #123457 y #123458 **no son tres opciones, son
una**. Por eso cada propuesta parte de una **estrategia cromática distinta** —el mismo tono, el
complementario, el mismo desaturado, subido de intensidad, casi todo neutro— y no de un retoque de
la anterior. Hay prueba de que no hay dos acentos iguales y de que la distancia entre ellas es
perceptible.

Cada una es un tema entero: principal, secundario, terciario, transparencia de tarjetas y barra, y
overlay del fondo. No un color suelto.

### Probar antes de decidir
"Probar" la pone en la app de verdad, al instante, **sin guardarla**. "Volver" recupera exactamente
lo que tenías.

Y eso funciona porque se hace una **copia profunda de la apariencia antes de tocar nada** y se
restaura entera — no se deshace cambio por cambio. La copia se hace **una sola vez**, al empezar a
probar: si se rehiciera en cada prueba, la segunda guardaría la apariencia de la primera y "Volver"
devolvería a una propuesta en lugar de a lo tuyo.

### Aplicar no toca la fotografía
Y no porque se acuerde de no hacerlo: `aplicarPropuesta` **ni siquiera la recibe**. Cambia acento,
tema y overlay, y nada más.

### Una foto en blanco y negro sigue dando propuestas
La Fase 5 dejó `acento: null` como dato honesto cuando la foto no tiene color. Aquí se usa: en vez
de inventar uno, se parte del que **ya tenías**.

### Un fallo real y preexistente, encontrado por las pruebas de contraste
`ensureContrast` elegía la dirección con `l <= bgL ? -1 : 1`, o sea por el **orden relativo** entre
los dos colores. Sobre un fondo oscuro, un color aún más oscuro se oscurecía **todavía más**: lo
empujaba hasta el negro puro y salía sin contraste ninguno.

No era solo cosa de esta fase: afectaba a la red de seguridad de `aplicarTema`, así que un texto
personalizado casi negro sobre el fondo oscuro de la app se habría quedado ilegible. Ahora la
dirección la decide **el fondo** —sobre fondo oscuro se aclara, sobre claro se oscurece— y para los
casos normales el resultado es idéntico al de antes.

### Y otro hex duplicado que cazó la regla invariante
El recomendador comparaba el contraste contra `'#0A0C10'` y `'#F3F4F7'` escritos a mano, que son
literalmente `COLORS_OSCURO.bg` y `COLORS_CLARO.bg`. Ahora se importan.

### Verificación
**1193 comprobaciones en verde** (antes 1143): 46 del recomendador y 104 casos de renderizado.

---

## Entrega 2 · FO Fase 5 — Detector de colores (v1.40.0)

JosStyle mira tu foto de fondo y te dice de qué colores es. **Sin IA y sin que la foto salga del
teléfono**: es aritmética sobre los píxeles de un `<canvas>` local, ni una petición.

### Frecuencia no es utilidad
Es la idea que gobierna toda la fase. El color que más superficie ocupa suele ser el **peor**
candidato a acento: en una foto nocturna es "casi negro" y en una de playa "casi blanco". Lo
interesante suele ser ese pequeño azul eléctrico que ocupa el 2 %.

Por eso cada color lleva **dos números distintos**: `peso` (cuánta superficie ocupa) e `interes`
(cuánto destaca). El ejemplo literal del apartado 8 está automatizado: una foto 95 % negra con un
5 % de azul eléctrico devuelve el **negro como dominante y el azul como acento**.

### Detectar no es aplicar
El apartado 15 es tajante y la interfaz lo dice: *"Solo te los enseño: tus colores no cambian
solos"*. Si tienes una foto azul y una paleta roja, tu paleta roja **se queda como está**. Tocar un
color lo copia, y de ahí decides tú. Aplicar automáticamente es la Fase 6.

### Una foto en blanco y negro no es un error
Se identifica como paleta neutra, y **no se inventa un acento que la foto no tiene**: `acento` es
`null`. Eso es información honesta, y la Fase 6 podrá buscar el acento por otro lado sabiendo que
ahí no está.

### Cada análisis va sellado con su fotografía
Cambiar de foto y seguir viendo la paleta de la anterior es imposible por construcción: el análisis
lleva el id de su imagen y se comprueba antes de usarlo. Y una foto ya analizada no se vuelve a
analizar.

### Un fallo real, y de los que no dan ningún error
`rgbToHsl`/`hexToHsl` devuelven la saturación en **0-100, no en 0-1**. Mis umbrales estaban en la
escala equivocada, así que **todo color con más de un 0,6 % de saturación salía como "vivo"** y solo
un gris exacto contaba como neutro: la clasificación entera habría sido inútil, y la Fase 6 habría
construido recomendaciones sobre datos sin sentido. Lo cazó la prueba que clasifica el propio acento
de la app (`#5C7E9A`, s = 25,2).

### Ocho fotos imposibles, ninguna rota
Toda negra, toda blanca, gris plano, extremadamente oscura, extremadamente clara, dos colores, un
solo píxel y saturadísima. El apartado 17 dice que **nunca** debe producirse una configuración rota,
y hay una prueba por cada caso.

Los píxeles transparentes tampoco cuentan: un agujero no es un color, y contarlo metería un falso
negro en toda imagen con transparencia.

### Verificación
**1143 comprobaciones en verde** (antes 1070): 65 del detector y 100 casos de renderizado.

---

## Entrega 2 · FO Fase 4 — Sistema avanzado de colores (v1.39.0)

Amplía el sistema de color que ya existía —`colorEngine.js`, `aplicarTema`, `ColorPicker`,
`TemaBuilder`, temas guardados— con lo que le faltaba para convivir con una fotografía de fondo.

### La transparencia no es un efecto bonito: era la pieza que faltaba
Con una foto detrás, las tarjetas opacas la tapan entera y solo se ve en los márgenes. Sin esto,
las fases 2 y 3 quedaban a medias: podías poner tu foto y **no verla**.

Por eso la transparencia llega hasta los tokens de verdad (`COLORS.surfaceAlpha`,
`COLORS.navBgAlpha`) y hasta los componentes (`Card`, la barra inferior), no solo al modelo. **Al
100 % es exactamente el color sólido de siempre**, así que sin tocar nada nada cambia.

Lleva `backdropFilter` cuando hay transparencia, porque una tarjeta translúcida sobre una foto con
detalle se vuelve ilegible sin él.

### Un fallo real corregido de paso
La barra de navegación tenía un `rgba(5,6,10,0.75)` fijo en el código, así que **en tema claro
seguía siendo negra**. Ahora sale del sistema de colores y respeta el tema.

### Y otro que las pruebas existen para que no vuelva
`Object.assign(COLORS, base)` sobrescribe las claves de `base` pero **no borra** las que no están
en él. `iconActive`, `iconMuted` y `navBg` no existen en las paletas base, así que sin limpiarlos
antes se quedaban pegados del render anterior: quitar un color personalizado habría parecido que no
funcionaba.

### Restablecer colores no puede tocar la fotografía
Y no porque se acuerde de no hacerlo: **ni siquiera la recibe**. `restablecerColores()` no tiene
parámetros, y hay una prueba que comprueba justamente eso. Una garantía que depende de acordarse no
es una garantía.

Un preset de color tampoco vuelve las tarjetas opacas: si habías bajado la opacidad para ver tu
foto, elegir una paleta no tiene por qué taparla.

### Jerarquía de texto e iconos
Texto secundario configurable, con red de seguridad: uno del color del fondo **no se queda
invisible**, `ensureContrast` lo corrige. Iconos activo e inactivo por separado, porque forzar un
solo color para los dos destruye la jerarquía.

### El mínimo de opacidad es 20, no 0
Y la interfaz lo explica cuando te acercas. Por debajo, una tarjeta sobre una foto no es
"translúcida": es texto suelto encima de una imagen. La Fase 9 afinará esto con medidas reales.

### Verificación
**1070 comprobaciones en verde** (antes 1000): 62 nuevas del sistema de colores y 92 casos de
renderizado.

---

## Entrega 2 · FO Fase 3 — Editor de fotografía (v1.38.0)

Zoom, encuadre, desenfoque, luz, opacidad y tinte, con vista previa en tiempo real. Detrás de
"Ajustar foto", para no llenar Ajustes de deslizadores.

### La foto original nunca se toca
Los ajustes son configuración del fondo, no una imagen nueva: después de editar, la ruta, las
medidas y el id de la fotografía son exactamente los mismos. Se puede volver a ajustar cuantas
veces haga falta.

### Cancelar funciona de verdad
El editor trabaja sobre un **borrador local**: mientras está abierto no se guarda nada. Cancelar es
literalmente tirar el borrador. Hay prueba que hace 40 cambios seguidos y comprueba que el fondo
guardado no se ha movido — el apartado 14 pide expresamente que funcione "incluso después de
realizar muchos cambios".

### Un solo control para oscurecer y aclarar
Los apartados 9 y 10 piden las dos cosas. Van en **un control bipolar**, no en dos deslizadores:
dos controles para dos mitades del mismo eje se contradicen en cuanto los dos valen algo (¿qué es
"oscurecer 40 y aclarar 30"?), y el apartado 17 pide no llenar la pantalla. El aclarado llega menos
lejos a propósito, porque el apartado 10 avisa de no perder contraste.

### Tres capas, y el orden importa
Foto → luz → overlay. "Oscurecer la foto" no debe oscurecer el overlay que va encima, y el overlay
no debe desenfocarse con la foto. Por eso tampoco se usa `filter: brightness()` sobre la capa de la
imagen.

### Cambiar de foto no arrastra lo que no toca
El apartado 16 dice que los ajustes no deben transferirse "accidentalmente si no tiene sentido". La
línea está en si el ajuste habla de **esa imagen** o del **gusto** de quien mira: encuadre y zoom se
recalculan —el encuadre bueno de un retrato vertical no significa nada en una panorámica—, mientras
que desenfoque, luz, opacidad y tinte se heredan, porque si querías la foto discreta y oscura para
leer mejor la sigues queriendo así con otra imagen.

Y si esa foto ya se había ajustado antes, mandan **sus** ajustes: se guardan por id de fotografía
(apartado 20), limitados a las últimas diez para que no crezcan sin fin.

### Una decisión de modelo que no era neutral
La Fase 1 guardaba `posicion` con cinco valores fijos; esta fase necesita encuadre libre. **No
conviven**: dos formas de decir dónde va la foto son dos fuentes de verdad. `posicion` se traduce a
`encuadre {x, y}` y lo guardado por v1.36/37 se migra. Lo mismo con `velo`, que era el overlay sin
color.

### Un fallo real que encontró la prueba de esa migración
El traslado de `velo` a `overlay` estaba escrito como `f.overlay?.intensidad ?? f.velo`, y **nunca
se ejecutaba**: `f` ya viene fusionado con el valor por defecto, así que `f.overlay` siempre existe
con `intensidad: 0`, y `??` no salta con 0. A quien tuviera un velo puesto se le habría perdido en
silencio al actualizar. Se arregla mirando el objeto **guardado**, no el fusionado.

### Y otro que cazó la regla invariante de colores
La capa de luz usaba `#000000`/`#FFFFFF` sueltos. No son colores de interfaz —oscurecer es acercar
al negro en tema claro y en oscuro— pero añadir una excepción al comprobador lo habría debilitado.
Se usan las palabras clave de CSS `black` y `white`.

### Verificación
**1000 comprobaciones en verde** (antes 941): 207 del sistema de fondos y 84 casos de renderizado.

---

## Entrega 2 · FO Fase 2 — Galería y selección de fotografías (v1.37.0)

Ya se puede poner una foto propia de fondo. **Ajustes → Apariencia → Fondo → Foto.**

### La foto no se aplica al elegirla
El apartado 3 lo pide expresamente: primero la vista previa, después "Aplicar". Así nadie tiene
que aceptar una configuración que no le gusta y deshacerla después.

Y la **subida a Storage ocurre al aplicar, no al elegir**. Si subiera al elegir, cada foto que
Josué mirara y descartara dejaría un archivo huérfano en su bucket para siempre. La vista previa
se hace con `URL.createObjectURL`, que es local e instantánea: no hay que esperar a la red para
ver cómo queda.

### La vista previa enseña la interfaz, no solo la foto
La foto se pinta **dentro de una representación de JosStyle**, con una tarjeta y su texto
secundario encima. Un rectángulo con la foto solo enseña la foto; lo que hay que poder juzgar es
si el contenido se sigue leyendo.

### El encuadre inicial no es "centrar y ya"
Una foto muy vertical se ancla **arriba** — que es donde está el cielo o el rostro en la inmensa
mayoría de fotos de móvil — en vez de cortar por la cintura. Las horizontales, panorámicas y
cuadradas se centran. Siempre `cover`, así que **la imagen nunca se deforma** (apartado 5).

### Quitar la foto no la borra
Vuelve al fondo anterior —el color o el degradado que hubiera, y si no, al fondo normal— y **la
fotografía se conserva** para la recuperación de la Fase 12, como pide el apartado 9. La interfaz
lo dice para que nadie evite el botón.

Y al revés: **elegir una foto no borra el color ni el degradado** que hubiera configurados
(apartado 14). Hay prueba propia.

### Nunca la pantalla sin fondo
Mientras la URL de la foto se está firmando, `resolverFondo` baja al fondo incluido. Eso da gratis
la transición suave del apartado 16: no hay parpadeo ni un instante sin fondo.

### Bucket nuevo `fondos`
Con sus tres políticas RLS por carpeta de usuario, mismo patrón que `armario`, `progreso` y
`entrenamiento-videos`. Va en su propio bucket a propósito: una foto de prenda se borra con la
prenda, un fondo se sustituye al elegir otro, y mezclarlos obligaría a distinguirlos por convenio
de nombre de archivo — el tipo de acuerdo implícito que se rompe solo.

⚠️ **Josué tiene que ejecutar ese bloque de `supabase/schema.sql` en el SQL Editor.** Hasta
entonces funciona todo menos la fotografía: color, degradado e incluidos no tocan Storage.

### Dos detalles que estaban mal si no se piensan
1. **`URL.createObjectURL` sin `revokeObjectURL` es memoria retenida** hasta recargar la página.
   Se suelta al desmontar y cada vez que se sustituye por otra foto.
2. **Una firma en vuelo puede pisar a la siguiente.** Si Josué cambia de foto mientras la URL
   anterior se firmaba, la respuesta lenta de la vieja llegaría después y sobrescribiría a la
   nueva. El efecto lleva una bandera que descarta el resultado obsoleto.

### Verificación
**941 comprobaciones en verde** (antes 882): 152 del sistema de fondos y 80 casos de renderizado,
incluidos el estado con foto y el estado sin foto todavía, que es donde más fácil sería dejar un
hueco roto.

---

## Entrega 2 · FO Fase 1 — Arquitectura del sistema de fondos (v1.36.0)

Empieza el bloque **FO (Fondos y Fotografías)**. Esta fase no añade una foto de fondo: construye
el sistema que hará falta para que quepan las once fases siguientes sin rehacer nada.

### El fondo es un elemento propio, no "una imagen detrás"
Es lo que pide el apartado 2, y marca la diferencia entre esto y pegar una imagen en el `<body>`.
Hay un solo sistema que sabe qué fondo está activo, cuál usa, cómo se muestra, con qué ajustes y
qué colores usa la interfaz encima.

### Amplía el sistema de apariencia; no compite con él
Ya existían `COLORS`, `aplicarTema()` y `colorEngine.js`. El fondo **se guarda dentro de
`apariencia`**, junto a tema, densidad, radio y alto contraste, y se resuelve en el mismo sitio y
el mismo momento que el tema. Ni una clave nueva en la base de datos, ni un segundo sistema de
apariencia — los dos lo piden los apartados 5 y 12.

### Nunca un fondo roto
El apartado 6 es literal: *"nunca debe aparecer un fondo vacío, roto o indefinido"*. Por eso
`resolverFondo` **no devuelve null jamás**. Un color inválido, un degradado a medias o una foto que
ya no está bajan un escalón de la cadena en vez de dejar un hueco, y dicen por qué. Hay una prueba
que le mete diez entradas rotas a propósito —`null`, `42`, `'texto'`, un tipo inventado— y
comprueba que todas salen con un tipo pintable.

### Cambiar de tema no puede perder el fondo
Los fondos incluidos se definen con **tokens**, no con hex, así que un fondo incluido acompaña al
tema claro/oscuro y al acento de Josué en vez de imponer un color ajeno. La prueba pinta el mismo
fondo con dos paletas distintas y comprueba que sale distinto y que la configuración guardada no
cambia.

### Restablecer no borra nada
El apartado 14 es explícito. "Volver al fondo normal" desactiva el fondo pero conserva el color, la
foto y los ajustes, y **la interfaz lo dice** para que nadie evite el botón por miedo a perder lo
que eligió. Es el mismo criterio que la app tiene desde ME Fase 3: lo reversible no se destruye.

### Un fallo de apilamiento CSS corregido al escribirlo
Una capa `position: fixed; z-index: 0` se pinta en el paso 6 del orden de pintado de CSS, **por
encima** del contenido en flujo normal, que va en el paso 3. Tal cual, el fondo habría tapado la
aplicación entera. Se arregla con `isolation: isolate` en el contenedor y `z-index: -1` en las
capas, que las deja exactamente entre el `background` del contenedor y el contenido.

### Y un hueco de cobertura que se cerró de paso
`SettingsView` no se renderizaba en ninguna prueba. Ahora su bloque de fondo sí, con cuatro
escenarios — incluido **un fondo guardado por una versión anterior, sin los campos nuevos**, que es
exactamente lo que devuelve `loadData` y lo que la regla 5 del proyecto obliga a soportar.

### Verificación
**882 comprobaciones en verde** (antes 777): 101 nuevas del sistema de fondos y 72 casos de
renderizado real.

---

## Entrega 2 · AR Fase 4 — Anti-repetición, estadísticas y recomendaciones (v1.35.0)

**Cierra el bloque AR (4/4).** El historial deja de ser una lista y pasa a decir algo. Cuarta
pestaña del Armario: **Prendas | Outfits | Calendario | Ideas**.

### Ninguna llamada a la IA, y es a propósito
El apartado 25 de la especificación prohíbe expresamente la IA de moda, y la regla 7 del proyecto
dice que la IA analiza y sugiere pero nunca decide ni se dispara sola. Así que **toda la
inteligencia de esta fase son reglas sobre el historial real**. La consecuencia práctica es la que
importa: cada recomendación llega con sus **motivos escritos**, sacados de los mismos números que
la ordenaron. Si algo no se puede explicar en una línea, no se enseña.

```
✨ Cena Negra
   · hace 20 días que no lo usas
   · todas sus prendas están disponibles
   · es uno de tus favoritos
```

### Sin contadores, otra vez
La Fase 3 quitó los contadores guardados. Esta fase **no los reintroduce por la puerta de atrás**:
los índices que usa se construyen al vuelo, se consultan y se tiran al acabar el render.

### Qué calcula
Estadísticas de outfits y de prendas (con rankings), diversidad del armario, outfits olvidados,
prendas infrautilizadas, prendas que se están repitiendo y **combinaciones repetidas** — estas
últimas detectan el mismo conjunto de ropa aunque esté guardado en dos outfits distintos, que es lo
que pasa cuando duplicas un outfit y le cambias el nombre.

El uso de una prenda **se deriva de sus outfits**, con el ejemplo literal del apartado 4
comprobado: 3 usos en un outfit + 5 en otro = 8, y sigue siendo UNA prenda.

### La diversidad es una fracción, no una puntuación
El apartado 16 avisa: nada de un número arbitrario sin explicación, y si no aporta valor, mejor no
implementarlo. Así que la única métrica que hay es `prendas usadas ÷ prendas disponibles`, una
división que cualquiera puede rehacer a mano, con sus dos números crudos a la vista. **No cuenta
las que están en la lavandería**: una camiseta que ha pasado el mes en el cesto no se ha usado,
pero eso no es falta de diversidad, es que no estaba.

### Nada se prohíbe, todo se dice
Un outfit usado ayer sale marcado, pero se puede usar igual. Un outfit con una prenda en la
lavadora nunca es la primera recomendación —cualquier alternativa completa le gana— pero **sigue
apareciendo, y dice qué prenda concreta le falta**. El contexto (lugar, ocasión, personas,
temporada) suma señales y no descarta a nadie.

### Saber cuándo no se sabe
Por debajo de 5 usos registrados **no se recomienda nada**, y se dice cuántos faltan. Con menos,
"el que hace más tiempo que no usas" es casi siempre "el que registraste primero", y eso no es un
patrón: es el orden de entrada de los datos.

### Un fallo real que encontraron las pruebas
`noDisponiblesDeOutfit` devuelve un **número**, y yo lo estaba tratando como una lista.
`noDisponibles.length` era `undefined`, así que `> 0` era siempre falso y **la penalización por
prendas no disponibles no se aplicaba nunca**: el outfit con una prenda en la lavadora salía como
primera recomendación. No daba error ni al compilar ni en consola. Arreglado en el origen, con una
`prendasNoDisponiblesDeOutfit` que devuelve la lista y un `noDisponiblesDeOutfit` que pasa a ser su
longitud — las dos respuestas salen ahora del mismo cálculo.

### Y dos cosas más, al releer el código antes de cerrar
- **La recomendación se guardaba en el estado**, así que registrar el uso desde la propia tarjeta
  dejaba en pantalla un "hace 20 días" que acababa de dejar de ser verdad.
- **"Más usados" y "menos usados" eran la misma lista al revés** cuando había 5 outfits o menos.

### Verificación
**777 comprobaciones en verde** (antes 661): 108 nuevas del motor de inteligencia —incluida la
prueba crítica del apartado 24, número a número— y 68 casos de renderizado real.

---

## Entrega 2 · AR Fase 3 — Calendario e historial de uso (v1.34.0)

El armario deja de ser un inventario y pasa a tener memoria. **Gestión → Armario** tiene ahora tres
pestañas: **Prendas | Outfits | Calendario**.

### Cada uso es un registro, no una fecha que se pisa
Ponerse el mismo outfit el 1, el 5 y el 12 de agosto son **tres registros independientes**, cada uno
con su fecha, su hora, su lugar, sus personas, su ocasión y sus notas. Sin eso no hay historial: hay
un "último uso" que olvida todo lo anterior.

### Ningún contador guardado
Aquí está el cambio de fondo de esta fase. Las Fases 1 y 2 dejaron un `usos` y un `ultimoUso`
guardados dentro de cada prenda y de cada outfit. **Se han eliminado**, tal y como pide el apartado
17 de la especificación, y ahora todo se deduce de `armario.usos`:

    PRENDA → los outfits que la contienen → los usos de esos outfits

Un contador guardado es una **segunda fuente de verdad**: basta con que un borrado de uso no lo
decremente para que una prenda diga "usada 18 veces" con 17 registros detrás. Derivándolo, ese
descuadre es imposible por construcción. El efecto secundario bonito es que **una prenda tiene
historial aunque nunca se haya registrado directamente**: se deduce de los outfits en los que sale.

Para que ordenar por uso no salga caro, las tres ordenaciones que lo necesitan van contra un índice
(`indiceUsoPrendas` / `indiceUsoOutfits`) construido en una sola pasada y tirado al acabar el
render. Es rendimiento, no modelo de datos: nunca se guarda, así que nunca se desincroniza.

### El calendario
Vista mensual que **reutiliza `celdasMes` del Calendario Universal** — regla 11 del proyecto: ni un
segundo motor de calendario. Lo único propio es qué se pinta dentro de cada celda: la **miniatura de
la prenda** al 55 % detrás del número del día, y una insignia con el número cuando ese día hubo más
de un outfit. Pulsar un día con outfits abre su detalle; pulsar uno vacío abre el formulario con esa
fecha ya puesta. Hay también una **vista de lista** con rango (7 / 30 / 90 / 365 días o todo) y
filtros por outfit, prenda, ocasión, lugar y persona.

### En el Calendario Universal, derivado
Los usos aparecen en el Calendario general como **fuente derivada**, igual que Objetivos, Estudios,
Entrenamiento, Tareas y Relación: se generan en cada render desde `armario.usos` y **no se copian
nunca**. Borrar un uso desde el Armario lo quita del Calendario en el mismo render, sin una línea de
código de limpieza, porque nunca hubo una segunda copia que limpiar. El título sale del outfit
referenciado, así que renombrarlo actualiza también el calendario del mes pasado.

### Borrar un outfit con historial
**Se conserva el historial**, por el mismo motivo por el que la Fase 2 conservaba las prendas dentro
de los outfits: el outfit va a la papelera, o sea que puede volver. Si al borrarlo se borraran sus
usos, restaurarlo devolvería el outfit pero no su historia. Conservándolos, **restaurar lo cura todo
solo**. Mientras no esté, la fila del historial dice *"Outfit eliminado"* en vez de fingir que ese
día no pasó nada.

### Dos fallos reales de TODA la app que destapó esta fase
Los dos en `src/lib/helpers.js`, los dos por usar `toISOString()`, que devuelve siempre UTC:

1. **`todayISO()` devolvía AYER** entre las 00:00 y la 01:00/02:00 en España. Registrar el sueño a
   las 00:30 lo archivaba en el día anterior — y lo mismo un gasto, una comida, un hábito o una
   entrada del diario a esa hora. Lo avisaba el apartado 9 para el registro de outfits; el fallo
   era de todo el proyecto, no solo del armario.
2. **`addDays()` restaba un día entero**: construía la fecha en hora local y la devolvía en UTC.
   `addDays('2026-08-25', 1)` daba `'2026-08-25'`, y `addDays('2026-01-15', 7)` daba el 21 en vez
   del 22. Lo usan la recurrencia del Calendario y las predicciones.

Los dos están arreglados con `toLocaleDateString('sv-SE')`, que es la forma estándar de pedirle al
formateador local un `AAAA-MM-DD` limpio, y los dos tienen prueba propia.

### Sin datos, no se inventa nada
Una prenda o un outfit sin usar dice **"Todavía no hay datos de uso."** — nunca "hace 0 días", nunca
una fecha inventada (apartado 28, literal).

### Verificación
**661 comprobaciones en verde** (antes 545): build de Vite, 297 del armario —incluida la batería
obligatoria del apartado 40 y la prueba crítica del 41, número a número—, 64 casos de renderizado
real y las 9 reglas invariantes.

---

## Entrega 2 · AR Fase 2 — Constructor de Outfits (v1.33.0)

Las prendas dejan de ser elementos sueltos. **Gestión → Armario** tiene ahora dos pestañas:
**Prendas** y **Outfits**.

### La regla que manda: referencias, nunca copias
La especificación lo repite en cuatro apartados distintos, así que se ha respetado al pie de la
letra: un outfit guarda **`prendaIds`**, no objetos de prenda. Cambiarle el nombre, el color o la
foto a una prenda se ve al instante en todos sus outfits, porque no hay ninguna copia que
actualizar. Una prenda usada en tres outfits sigue siendo **una prenda y tres relaciones**.

### Qué pasa al borrar una prenda que está en un outfit
La especificación dejaba elegir entre tres salidas. Se ha elegido **conservar la referencia y
mostrarla como no disponible**, por un motivo concreto:

Desde ME Fase 3, borrar una prenda la manda a la papelera — **se puede restaurar**. Si al borrarla
le quitáramos su id a todos los outfits, restaurarla dejaría los outfits rotos para siempre: el dato
volvería, pero el vínculo no. Conservando la referencia, **restaurar la prenda cura los outfits
solos**, sin una línea de código de reparación.

Mientras tanto el outfit no miente: dice *"1 prenda no disponible"* y su detalle explica que vuelve
sola si la recuperas. Y la confirmación de borrar una prenda avisa antes: *"está en 2 outfits"*.

### Cómo se eligen las prendas
Por **zona del cuerpo** (superior, inferior, calzado, abrigo, accesorios, otros), no por las 14
categorías: es como se piensa uno al vestirse. Es una vista sobre las categorías que ya existen, no
una segunda clasificación que rellenar.

Y **sin límite**: camiseta + camiseta interior + sudadera + pantalón + zapatillas + reloj + cadena es
un outfit perfectamente válido. El buscador de dentro **es el de la Fase 1 tal cual** — la
especificación pide expresamente no crear un segundo sistema.

### "negro" encuentra "Total Black"
El ejemplo literal del apartado 23, funcionando: buscar "negro" encuentra un outfit llamado *Total
Black* **porque contiene una prenda negra**, aunque su nombre no lleve esa palabra. La búsqueda mira
también el nombre, la marca, la categoría y el color de las prendas que lo componen.

### Duplicar sin heredar lo que no toca
Duplicar un outfit crea una entidad independiente con **las mismas prendas**, y modificar la copia no
roza el original. Lo que la especificación subraya dos veces: la copia **empieza con el historial a
cero**. Es un outfit nuevo; no se ha llevado nunca.

### Lo que se ha pulido
Contador de selección; quitar una prenda volviendo a pulsar su tarjeta entera; aviso de *"Outfit
guardado ✓"* que se va solo (nada de `alert()`); editar y duplicar **a un toque desde la tarjeta**;
**eliminar separado de esas dos** y solo dentro del detalle con confirmación, para que no se pulse
sin querer; y el detalle releyéndose de la lista, para que un cambio se vea al instante.

### Lo que NO se ha hecho, a propósito
Ni calendario, ni historial de uso, ni recomendaciones, ni anti-repetición. `usos` y `ultimoUso`
existen y **están a cero**: el apartado 8 del cierre es explícito — *"no inventes datos"*. La Fase 3
los llenará, y `armario.usos` ya está declarado como lista para que cada uso sea **un registro
independiente**, no una sola fecha.

### Un fallo mío, cazado por las pruebas
Al escribir el detalle del outfit dejé un `</div>` de más y el proyecto dejó de compilar.
`scripts/smoke.mjs` lo detectó antes de llegar a ninguna parte.

### Verificación
`bash scripts/verificar.sh` → **545 comprobaciones en verde**, 185 del armario y 60 casos de
renderizado. Entre ellos, los dos casos límite que la especificación subraya: **un outfit con una
prenda borrada** y **un outfit sin ninguna prenda**, que tienen que pintarse sin reventar.

⚠️ **Pendiente de Josué (R1):** el recorrido completo en un iPhone y la persistencia real en
Supabase.

---

## Entrega 2 · AR Fase 1 — Armario digital (v1.32.0)

**El primer módulo genuinamente nuevo de la Entrega 2.** ME y BI ampliaban cosas que ya existían;
esto no existía en ninguna forma. Vive en **Gestión → Armario**.

### La decisión que más pesa: el modelo de datos
El apartado 23 dice que la arquitectura tiene que aguantar tres fases más sin rehacerse. Por eso
cada prenda nace con **los 21 campos**, aunque cuatro estén vacíos: `usos`, `ultimoUso`, `outfits` y
`favorita`.

No es adorno. Las fases 3 y 4 tienen que responder a *"¿cuándo la usé por última vez?"* y *"¿cuánto
lleva sin usarse?"*, y `loadData` **no fusiona con el valor por defecto** (regla 5 del proyecto): un
campo que aparezca en la Fase 3 no lo tendrán las prendas ya guardadas, y arreglarlo entonces exige
una migración manual prenda a prenda. La prueba lo comprueba hoy, campo por campo.

Las tres ordenaciones por uso (*Más usadas*, *Menos usadas*, *Más tiempo sin usar*) **ya están
escritas y probadas**, pero la interfaz no las ofrece mientras no haya ni un uso registrado. Un
"Más usadas" sobre un armario sin usos sería un control decorativo, y eso es la regla 8.

### Añadir una prenda en segundos
El apartado 16 es tajante: *"no quiero que el usuario tenga que rellenar 15 campos cada vez que
añade una camiseta"*. Por defecto solo se ven **nombre, categoría, color y foto opcional**; los ocho
campos restantes están detrás de "Más información".

Y la foto es opcional de verdad: sin ella la tarjeta pinta un degradado del color de la prenda con
su categoría, **del mismo alto que una foto**, para que la rejilla no se desalinee según quién tenga
fotografía y quién no.

### Buscar por lo que uno recuerda, no por el nombre exacto
La especificación lo pide explícitamente: "gris" encuentra prendas grises y "Nike" prendas de Nike.
La búsqueda mira nombre, marca, talla, notas, material, categoría, color, estado y temporada — y
sobre las **etiquetas**, no los ids: Josué escribe "marrón", no "marron".

### Confirmación al eliminar: una excepción con motivo
Desde ME Fase 3, borrar no pide confirmación en ninguna parte de la app, porque la papelera lo hace
reversible. Aquí **sí la pide**, y no es capricho: la papelera guarda el objeto de la prenda, pero
**la fotografía vive en Supabase Storage y no vuelve** — igual que las fotos de Salud y los vídeos
de Calistenia, excluidos de la papelera desde entonces. Borrar una prenda con foto es en parte
irreversible, y eso es justo lo que la regla reserva para la confirmación. El texto lo dice, y
cambia según la prenda tenga foto o no.

### Dos cosas nuevas que hicieron falta
- **`SelectInput`**: el proyecto no tenía ni un `<select>`. Todas las elecciones se hacían con filas
  de botones, que funcionan con 3 o 4 opciones; el Armario tiene 14 categorías y 13 colores, y
  catorce pastillas en fila no caben en un iPhone. Un desplegable nativo abre además la rueda de
  iOS, que se maneja con el pulgar mucho mejor.
- **El bucket `armario`** en `supabase/schema.sql`, con las mismas políticas por carpeta de usuario
  que `progreso` y `entrenamiento-videos`.

### ⚠️ Algo que Josué tiene que hacer
**Ejecutar el bloque nuevo de `supabase/schema.sql` en el SQL Editor de Supabase** (solo ese bloque,
está marcado). Hasta entonces el Armario funciona **entero sin fotos**: la fotografía es opcional
por diseño, y si la subida falla, la prenda **se guarda igual** con un aviso — perder lo escrito por
un fallo de red sería mucho peor.

### Un fallo que destapó la prueba de renderizado
`ArmarioView` es la primera vista del smoke test que toca Storage, y `lib/supabase.js` lee
`import.meta.env` al cargarse — algo que solo existe dentro de Vite. Ahora está stubeado, y de paso
queda comprobado algo que importa por sí mismo: **ninguna vista debe necesitar la red para
pintarse**.

### Verificación
`bash scripts/verificar.sh` → **443 comprobaciones en verde**, 87 de ellas del armario, más 4 casos
de renderizado (vacío, con datos, datos parciales y con el módulo desactivado).

⚠️ **Pendiente de Josué (R1):** subir una foto de verdad y ver la rejilla en un iPhone.

---

## Entrega 2 · BI Fase 4 — Buscar y preguntar dejan de ser dos cosas (v1.31.0)

Cierra el bloque BI (4/4). Josué ya no tiene que decidir si lo suyo es una búsqueda o una pregunta:
escribe, y JosStyle decide qué es más útil enseñarle.

### Tres intenciones, no dos
El apartado 5 pide **navegación**, **pregunta** y **acción**. Hasta ahora solo había un booleano
"¿es pregunta?". La tercera es la que cambia el comportamiento:

| Escribe | Intención | Qué sale primero |
|---|---|---|
| `colores` | navegación | Colores y tema |
| `¿cómo puedo mejorar mi planche?` | pregunta | la IA |
| `¿cómo cambio los colores?` | pregunta | la IA **y** Colores debajo |
| `cambiar colores` | **acción** | **Colores y tema**, la IA debajo |
| `quiero añadir un objetivo` | **acción** | **Crear un objetivo** |

Y no depende del signo `¿`, que es de lo que avisa el apartado 6: "cambiar colores" no lo lleva y es
claramente una acción. Se miran verbos, arranque de frase y longitud.

### Lo que hacía falta para cumplir el apartado 7, y no era obvio
"Cuando exista una función claramente relacionada, debe tener prioridad." El problema: **buscar la
frase entera no encontraba nada**. "quiero añadir un objetivo" no coincide con ninguna entrada,
porque ninguna contiene la palabra "quiero". Sin quitar ese envoltorio, la prioridad de la función
sobre la IA era imposible de cumplir — no había función que priorizar.

`nucleoDeConsulta` quita el relleno y deja "anadir objetivo", que sí encuentra la acción. Pero solo
**si la frase entera no ha dado nada**: aflojar una búsqueda que ya era precisa habría empeorado los
casos normales para arreglar los raros.

### Toda la decisión en un sitio que se puede probar
`resolverConsulta(indice, texto)` devuelve qué enseñar y en qué orden. Vive en el motor, no en el
componente, y por eso **los ocho casos de la prueba final del apartado 20 son ocho llamadas a una
función**, comprobadas sin renderizar nada.

### Un hueco real de navegación, arreglado
Buscar "colores" desde Inicio y pulsar atrás dejaba a Josué en el hub de **Más** — un sitio en el
que no había estado. Ahora vuelve a donde estaba. El rastro se borra en cuanto navega a cualquier
otro sitio, mediante un único efecto sobre `tab`: ponerlo en cada botón habría dejado fuera el que
se añada mañana.

### Errores y carga (apartados 14 y 15)
- "Pensando…" con su rueda, sin bloquear el resto de la app.
- Un mensaje de error con pinta de código o número de estado se sustituye por **"No he podido
  responder ahora mismo"**, con **Reintentar** y el buscador intacto detrás. Nada de
  `500 Internal Server Error` en pantalla.

### Lo que no se ha tocado
Los paneles de IA de cada módulo siguen exactamente donde estaban: el apartado 23 pide
expresamente que el buscador nuevo **no rompa el acceso inferior existente**. Y `api/ask-ai.js` no
se ha modificado — ninguna clave llega al frontend.

### Verificación
`bash scripts/verificar.sh` → **352 comprobaciones en verde**, 129 de ellas del buscador.

⚠️ **Pendiente de Josué (R1):** el recorrido completo en un iPhone real, con el teclado abierto.

---

## Entrega 2 · BI Fase 3 — El motor de búsqueda de verdad (v1.30.0)

La Fase 2 hizo el acceso y un índice que funcionaba. Esta lo convierte en un motor: sinónimos,
plurales, erratas, acciones directas, sugerencias y recientes.

### Lo que ahora encuentra y antes no
| Escribe | Antes | Ahora |
|---|---|---|
| `colo`, `entren`, `dormi` | ya funcionaba | igual |
| `color` (singular de "colores") | nada | Colores y tema |
| `colroes` (errata) | nada | Colores y tema + *"¿Quizá buscas Colores y tema?"* |
| `religion`, `musculo`, `diseno` | nada | Fe, Entrenamiento, Colores — por sinónimo |
| `modo oscuro` | Colores y tema | **Modo oscuro o claro**, con entrada propia |
| `nueva tarea` | Productividad | **abre el formulario de tarea nueva** |

### Tres tipos de destino, no solo pantallas
El apartado 11 pide que el índice no quede limitado a páginas. Ahora hay `pantalla`, `ajuste` (abre
su categoría de Ajustes) y `accion` (abre un formulario). Las cuatro acciones directas son
**exactamente** las que el Dashboard ya tiene en su fila de acciones rápidas, con el mismo `foco`:
no se ha inventado ninguna.

### Sinónimos y palabras clave son cosas distintas
El apartado 3 los separa y el 8 los ordena. Una **palabra clave** es como Josué llamaría a la
función ("dinero" → Economía); un **sinónimo** es un término vecino que debe encontrarla sin
adelantar a la función cuyo nombre es esa palabra. Por eso "concentracion" lleva a Bienestar —lo
tiene como palabra clave— y no a Productividad, que solo lo tiene como sinónimo.

### Dos bugs reales que encontraron las pruebas
1. **El plural atropellaba palabras clave literales.** "pantallas" abría *Pantalla principal* (que
   solo coincide tras quitarle la 's') en vez de Bienestar, que tiene "pantallas" escrito tal cual.
   La causa era estructural: `puntuar` devolvía el primer acierto por campos, así que una
   coincidencia floja en el título ganaba a una fuerte en las palabras clave. Ahora se evalúan
   todos los escalones y se coge el mayor, y el plural tiene su propio escalón, por debajo.
2. **La raíz destrozaba palabras cortas acabadas en 's'**: "tres" → "tre", "mes" → "me". El umbral
   pasó de 3 a 4 letras.

### Damerau, no Levenshtein
Con Levenshtein a secas, "colroes" está a **2** errores de "colores" (dos sustituciones) y con la
tolerancia razonable que pide la especificación no se encontraba. Contando el intercambio de dos
letras seguidas como **un** error, se encuentra. Las transposiciones son con diferencia la errata
más común escribiendo deprisa en un móvil, y es justo el ejemplo que pone el apartado 18.

Las erratas puntúan por debajo de todo lo demás, así que **nunca desplazan a un acierto real**, y
solo se aplican a consultas de una sola palabra: sobre una frase entera la distancia de edición deja
de significar nada y empieza a devolver cosas al azar, que es lo que prohíbe el apartado 7.

### Historial reciente, con cuidado
Cuatro accesos, con botón de limpiar. Dos decisiones deliberadas:
- **Guarda ids de funciones, no el texto escrito.** Una búsqueda puede ser una pregunta personal
  ("por qué me encuentro mal"); un historial de funciones abiertas, no.
- **Vive en `localStorage`, no en Supabase.** El apartado 16 lo pide, y además no es un dato que
  merezca sincronizarse entre dispositivos ni entrar en la copia de seguridad. Se resuelve contra el
  índice actual, así que un reciente cuyo módulo se desactive después desaparece solo.

### Privacidad (apartado 21)
Escribir "colores" **no sale del dispositivo**. La prueba no se fía de que esté bien escrito: lee el
propio archivo del motor y comprueba que no importa `askAI` ni hace `fetch`.

### Verificación
`bash scripts/verificar.sh` → **322 comprobaciones en verde**, 99 de ellas del buscador, incluidas
las seis categorías de pruebas obligatorias del apartado 22.

---

## Entrega 2 · BI Fase 2 — Buscar funciones y abrirlas directamente (v1.29.0)

### El problema, en una frase
Para cambiar un color, Josué tenía que acordarse de que eso vive en **Más → Ajustes → Apariencia →
Colores**. Ahora escribe "colores" y pulsa el resultado.

### Por qué es el mismo modal y no uno nuevo
El buscador que ya existía (Fase 18) busca en los **datos**: *"¿cuántas horas dormí de media?"*. Lo
que pide esta fase es buscar **funciones, pantallas y ajustes**. Son cosas distintas, pero el
apartado 20 es explícito: *"BUSCAR → ENCONTRAR → ABRIR y también PREGUNTAR → IA → RESPUESTA. Todo
desde el mismo acceso"*, y el apartado 16 prohíbe duplicar la IA existente. Así que se amplía el
modal de siempre en vez de poner un segundo buscador al lado.

### El índice no está escrito: se construye
El apartado 17 pide que añadir un módulo sea *"añadir una entrada"*, no tocar la lógica del buscador.
Los 19 módulos **no** están escritos en `indiceBusqueda.js`: se derivan de `MORE_NAV` —el catálogo
que ya usan la navegación, Personalización y Seguridad— más `DESCRIPCIONES_MODULOS`. Un módulo que
una fase futura añada ahí aparece solo en el buscador.

Lo único escrito a mano son las palabras clave, porque no se pueden derivar de nada: "dinero" no
aparece en ninguna parte del código, y es como se busca Economía. Para que eso no se quede atrás,
`comprobar-navegacion.mjs` ahora falla si alguien añade un módulo sin palabras clave — o deja
palabras clave de uno que ya no existe.

### Buscar y preguntar no son excluyentes
El apartado 11 lo dice mejor que un resumen: *"esto es mejor que obligar al usuario a elegir entre
búsqueda o IA desde el principio"*. Escribir `¿cómo cambio los colores?` saca **las dos cosas**: el
botón de preguntar a la IA arriba y el resultado de Apariencia debajo. La pregunta le llega a la IA
ya escrita; no hay que repetirla.

### Añadido / cambiado
- **`src/lib/indiceBusqueda.js`** (nuevo): índice + motor. `construirIndice`, `buscar`,
  `pareceUnaPregunta`, `normalizar`, `PALABRAS_MODULOS` y las 14 funciones de dentro de Ajustes.
  Los pesos del orden por relevancia están lo bastante separados como para que ninguna suma de
  coincidencias débiles adelante a una fuerte — es el ejemplo del propio apartado 8: buscando
  "color", "Colores" gana a cualquier entrada que solo mencione la palabra de pasada.
- **La lupa se muda arriba a la izquierda** (apartado 1) y el panel de sugerencias se va a la
  derecha. **Se intercambian, no se elimina ninguno**: son cosas distintas y la especificación
  prohíbe quitar funcionalidad existente.
- **Pulsar un resultado abre el sitio exacto**, categoría de Ajustes incluida, reutilizando el
  `navegarDesdeHoy` que ya existía. `SettingsView` acepta el mismo `foco` que Sueño, Entreno,
  Objetivos, Estudios, Productividad y Economía ya aceptaban.
- Sin coincidencias no queda una pantalla vacía: se ofrece la IA con lo que ya escribió.
- Campo con foco automático, botón de limpiar, y la lista scrollea dentro de `46vh` para que con el
  teclado abierto en un iPhone el campo siga visible.
- **`scripts/test-buscador.mjs`** (nuevo): 58 comprobaciones, entre ellas las nueve del control de
  calidad del apartado 19.

### Dos cosas que se han decidido no hacer, y por qué
- **No se han inventado Rachas ni Sonidos.** El control de calidad los pide *"si el módulo existe"*,
  y son fases futuras. "racha" lleva a Productividad —que es donde están hoy las rachas de hábitos
  de verdad— y "sonidos" no devuelve nada. Fingirlos habría roto la regla 8.
- **Sin animación de entrada por resultado.** El apartado 13 dice "VELOCIDAD > EFECTOS", y animar
  una lista que cambia con cada tecla la haría parecer más lenta, no más premium.

### Un fallo silencioso corregido de paso
`TextInput` era un componente de función normal, así que **se tragaba la `ref` sin decir nada**: el
foco automático del campo simplemente no habría ocurrido, sin error ni aviso en consola. Ahora usa
`forwardRef`. Es aditivo — ninguno de los ~60 usos anteriores pasa `ref`.

### Seguridad (apartado 18)
El índice es de funciones: **no contiene ni un dato de Josué**. Relación se encuentra como pantalla
—ya aparece en el menú "Más", no es un secreto—, pero abrirla sigue pasando por su PIN: el buscador
navega, no salta protecciones. Y un módulo desactivado en Personalización no se puede encontrar.

### Verificación
`bash scripts/verificar.sh` → **281 comprobaciones en verde**.

⚠️ **Pendiente de Josué (R1):** el comportamiento real con el teclado del iPhone abierto.

---

## Entrega 2 · BI Fase 1 — El desplegable de situación de Inicio (v1.28.0)

### Lo que ya estaba, y por qué no se ha rehecho
La especificación pide un componente colapsable con animación fluida, cerrado por defecto y
compacto. Eso **ya existía** desde v1.21.0: `IndicadorContexto` usa `grid-template-rows` 0fr↔1fr,
arranca cerrado y el chevron rota. Rehacerlo por rehacerlo habría sido gastar una fase en algo que
funciona.

### El hueco real
El apartado 5 pide que al abrirlo aparezcan **las opciones** de Vacaciones, Exámenes y las demás
situaciones. El componente solo dejaba **leer consejos**: para cambiar de situación había que salir
de Inicio, ir a Más → Personalización y buscar el selector. El estado final que dibuja el apartado
14 es justo lo contrario.

Ahora las tres situaciones se activan desde el propio desplegable. **Sin un solo dato nuevo**:
misma clave `personalizacion.modo`, mismo `setModoApp` de `App.jsx` —el que ya hacía el toggle— y
mismos textos de `MODOS_APP`. Desde Inicio y desde Personalización se toca el mismo interruptor,
que es lo que exige la decisión **D2-07** ("integrar, no hacer tres sistemas distintos").

### El fallo silencioso que apareció al hacerlo
El componente entero era un `<button>`. Meter dentro los selectores de situación habría dado
**botones anidados**: HTML inválido que no rompe el render, no da ningún error en consola y que en
iOS hace que el toque del botón interior se lo coma el exterior — un botón que simplemente no
responde, sin pista de por qué.

Ahora la cabecera es el botón y el contenido es su hermano. Y como es un fallo fácil de repetir,
`scripts/smoke-vistas.jsx` lo comprueba en **las 13 vistas × 4 escenarios**, no solo aquí.

### Añadido / cambiado
- **Accesibilidad real** (apartado 10): `aria-expanded` en la cabecera, `aria-controls` apuntando a
  un id que **existe de verdad** (uno colgando es peor que no ponerlo), `role="region"` con nombre y
  `aria-pressed` en cada situación, porque son interruptores y no navegación.
- La animación gana un desplazamiento de 4px además de la opacidad, para que el contenido entre en
  lugar de aparecer.
- Sin situación activa el panel ya no dice "Sin modificaciones especiales", que no explicaba nada:
  dice para qué sirve.
- Personalización menciona que el modo también se cambia desde Inicio, para que no parezcan dos
  ajustes distintos.
- **`scripts/test-inicio.jsx`** (nuevo): 18 comprobaciones — arranca cerrado, `aria-controls`
  resuelve, ningún botón anidado, las tres situaciones presentes, la activa marcada y sus consejos
  intactos.

### Lo que NO se ha tocado
Buscador, lupa, IA, rachas y sonidos: son fases posteriores y el apartado 11 lo prohíbe
expresamente.

### Verificación
`bash scripts/verificar.sh` → **223 comprobaciones en verde**.

⚠️ **Pendiente de Josué (R1):** cómo se ve y se siente en un iPhone de verdad, y el aspecto en tema
claro. El componente solo usa tokens de `COLORS`, así que sigue el tema por construcción, pero eso
es un argumento, no una comprobación.

---

## Entrega 2 · ME Fase 4 — Integración global, auditoría y renombrado a JosStyle (v1.27.0)

Cierra el bloque ME (4/4). La especificación no pide construir nada nuevo aquí: pide **revisar todos
los módulos con las mismas 10 preguntas** y arreglar lo que no las pase. Hacerlo en serio dio ocho
huecos reales.

### El hallazgo: ocho colecciones dejaban CREAR y no BORRAR
La pregunta 3 de la auditoría es *"¿sus elementos creados por el usuario se pueden eliminar?"*.
Siete módulos contestaban que no:

| Módulo | Qué no se podía borrar | Consecuencia real |
|---|---|---|
| Sueño | registros de noche | una noche mal tecleada distorsionaba la media para siempre |
| Economía | movimientos | un gasto duplicado no se podía quitar del balance |
| Salud | medidas | un peso mal puesto rompía la gráfica de evolución |
| Salud | historial médico | — |
| Nutrición | comidas | un escaneo erróneo se quedaba en el total del día |
| Fútbol | partidos | — |
| Estudios | horas de estudio | un "8" en vez de un "0.8" inflaba la semana entera |

Y el octavo lo encontró el script, no la revisión a mano: **los programas de Estudios**. Se podían
crear ("Idiomas", "Selectividad") y no había forma de quitarlos de la barra de pestañas.

### Por qué la auditoría es un script y no un documento
Un documento que diga "revisado, todo correcto" no vale nada dentro de seis fases. Tres de las diez
preguntas de la especificación se pueden comprobar solas, y son justo las que fallaron:

- **`scripts/auditar-modulos.mjs`** (nuevo) responde P3 (todo lo creable es borrable), P5 (ningún
  borrado se salta la papelera), P7/P7b (el catálogo y el código dicen lo mismo, en los dos
  sentidos) y P9 (toda entrada del catálogo se puede nombrar en la papelera).
- Entra en `scripts/verificar.sh`, así que **cada módulo nuevo de las 102 fases restantes pasa por
  ella automáticamente**. Si alguien añade una colección y olvida su borrado, la verificación falla.

### Añadido / cambiado
- **`BotonBorrar`** en `src/components/ui.jsx`: un único control de borrado para toda la app. No
  pide confirmación a propósito — desde ME F3 lo borrado va a la papelera y es recuperable; la
  confirmación se reserva para el borrado definitivo, que sí es irreversible.
- **Ocho handlers nuevos** en `App.jsx`, todos por papelera. Siete son de una línea; el octavo,
  `deletePrograma`, es la **segunda cascada** de la app: se lleva sus asignaturas y, con ellas, sus
  exámenes y sus horas, todo en la **misma** entrada de papelera — restaurar el programa devuelve
  el árbol entero, no un programa vacío.
- **`estudios.programas`** entra en `CATALOGO_PAPELERA` (27 colecciones).
- **Horas de estudio visibles**: hasta ahora se sumaban a un total y no había forma de ver ni
  corregir un registro concreto. Ahora la asignatura desplegada lista las últimas cinco, con su
  borrado.
- **`EstudiosView` sin programas** ya no dice "todavía no has añadido ninguna asignatura a este
  programa" cuando no hay programa ninguno: dice qué hacer.

### El renombrado: el proyecto se llama JosStyle
Josué ha cerrado la contradicción **C-21**, abierta desde el primer análisis: el nombre oficial y
definitivo es **JosStyle**; *JC Fitness*, *JC Lifestyle* y *JC STYLE* quedan como referencias
históricas.

- Renombrado: pantalla de acceso, `<title>`, nombre en la pantalla de inicio de iOS,
  `manifest.json` y el campo `name` de `package.json`. La interfaz, curiosamente, no usaba ninguno
  de los cinco nombres — se presentaba como *"Mi Sistema Personal"*.
- **No** renombrado, y por qué: el proyecto en Vercel y su URL (cambiarlos afecta a cómo entra
  Josué a la app), el `start_url` del manifiesto (desvincularía la PWA instalada de sus datos), las
  citas literales de `especificaciones/` (intocables) y el histórico de este mismo archivo.
- ⚠️ **Efecto que verá Josué:** el icono que ya tiene en la pantalla de inicio del iPhone
  **seguirá con el nombre viejo** hasta que lo borre y lo vuelva a añadir. iOS no renombra accesos
  directos ya creados. No se pierde ningún dato al hacerlo.

### Decisiones de Josué registradas
Sus ocho respuestas quedan en `docs/06_ENTREGA2_ANALISIS.md` §7 como **D2-01 … D2-08**, y resuelven
E2-C-01 (gamificación), E2-C-03 (Amazon), E2-C-05 (contenido educativo), E2-C-06 (parte de Inicio) y
C-21 (nombre). Se añade la **regla 49**: una contradicción nueva entre especificaciones no se
resuelve por cuenta propia — se pregunta, deteniendo la fase afectada y no la sesión.

### Verificación
`bash scripts/verificar.sh` → **205 comprobaciones en verde**: build (2606 módulos), 148 pruebas
unitarias, 5 de auditoría, 52 casos de renderizado y 9 reglas invariantes.

---

## Entrega 2 · ME Fase 3 — Eliminados recientemente (v1.26.0)

### Alcance de esta fase, dicho primero
Una papelera de verdad. Hasta ahora borrar algo lo borraba: existía el deshacer de 10 pasos, pero
es un histórico compartido por toda la app — si borras una tarea y después registras tres cosas
más, ya no puedes recuperarla.

### Por qué es un sistema global y no uno por módulo
La especificación es tajante: *"debe construirse como un sistema global y reutilizable, no como una
solución aislada para los módulos actuales"*. Al revisar los 22 handlers de borrado de `App.jsx`
resultó que **todos seguían exactamente el mismo patrón**:

```js
MODULO.COLECCION.filter((x) => x.id !== id)
```

Así que la papelera se modela sobre esa forma: **módulo + colección + id**. Los 19 handlers de una
línea se han reducido a `eliminarConPapelera('modulo', 'coleccion', id)`. Añadir un módulo futuro
a la papelera es añadir una entrada a `CATALOGO_PAPELERA` — sin tocar el motor ni la interfaz.

### Añadido / cambiado
- **`src/lib/papelera.js`** (nuevo): motor puro. `prepararEliminacion`, `prepararRestauracion`,
  `conArrastrados`, `purgarCaducados`, `describirEntrada`, `tiempoDesde`, `diasRestantes`,
  `ordenarPapelera` + el catálogo de **26 colecciones**.
- **Cada entrada guarda el objeto íntegro**, no una etiqueta de "borrado" (requisito explícito):
  id original, tipo, módulo, colección, fecha de creación, fecha de eliminación, **la posición que
  ocupaba en la lista** y los datos completos. Por eso la recuperación es real: el elemento vuelve
  a su sitio, en su orden y con su id — no se recrea una copia.
- **`src/views/PapeleraView.jsx`** (nuevo) y nueva categoría en Ajustes: lista ordenada por
  cuándo se borró, con tipo, cuánto hace ("hace 2 horas", "ayer", "hace 3 días" — como los
  ejemplos de la especificación) y cuántos días le quedan. Recuperar y eliminar definitivamente
  por elemento, vaciar papelera, y retención configurable.
- **Retención**: 7 / 30 / 90 días o **"hasta que yo lo borre"**. Se aplica al abrir la app y al
  acortar el plazo, y solo escribe si de verdad ha cambiado algo.
- **Borrado en cascada resuelto**: borrar una asignatura se lleva sus exámenes y sus horas. Si la
  papelera guardara solo la asignatura, recuperarla devolvería una asignatura vacía y los exámenes
  se habrían perdido. `conArrastrados` mete en la misma entrada lo que cayó con ella y restaurar
  devuelve las tres cosas (*"recupera sus relaciones cuando sea posible"*).

### Decisiones
- **La papelera entra en el snapshot del deshacer.** Sin eso, deshacer un borrado devolvería el
  elemento a su módulo pero dejaría su entrada en la papelera: un fantasma que al restaurarse
  duplicaría el elemento. Con la papelera dentro, los dos sistemas de recuperación no se pisan.
- **Borrado definitivo y vaciado NO pasan por el deshacer**: meter en el histórico una acción cuyo
  sentido es "esto ya no se puede recuperar" sería contradictorio.
- **Privacidad de Relación.** Es el único módulo protegido de principio a fin, y la papelera se
  abre desde Ajustes sin pedir PIN. Enseñar ahí "Aniversario con María" sería una fuga real. Sus
  entradas se marcan `privado`: bloqueadas se muestran como "Elemento privado" y no se pueden
  restaurar; los datos siguen guardados. Mismo mecanismo (`estaDesbloqueado('area:relacion')`) y
  mismo criterio que ya se aplicó al integrar Relación en el Calendario.
- **Fotos, vídeos y archivos de Biblioteca quedan fuera**, igual que ya estaban fuera del
  deshacer: sus datos viven en Supabase Storage, y mandarlos a la papelera exigiría no borrar el
  archivo, dejando ficheros huérfanos si después se vacía desde otro dispositivo. Documentado como
  límite, no como olvido.
- **Restaurar algo que ya volvió por otra vía no duplica**: la entrada sale igualmente de la
  papelera, para no dejar un fantasma imposible de quitar.

### Comprobado
- **73 pruebas** del motor (`scripts/test-papelera.mjs`): que restaurar devuelve el elemento a su
  posición exacta con todos sus campos y su id original (y que el resultado es **idéntico** al
  estado de partida), el borrado en cascada de ida y vuelta, la retención con fechas corruptas,
  la privacidad de Relación bloqueada y desbloqueada, y los casos límite de restaurar sobre una
  lista que ha encogido o que ya contiene el elemento.
- **52 casos de renderizado**, ahora incluyendo `PapeleraView`.
- Total en verde: 148 comprobaciones + 52 casos.

### Pendiente (documentado, no implementado en esta fase)
- Archivos en Storage (ver Decisiones).
- La auditoría de que **todos** los puntos de borrado de la app pasan por la papelera es
  explícitamente el trabajo de **ME Fase 4** ("integración global + auditoría").
- Sin probar en un iPhone real.


## Entrega 2 · ME Fase 2 — Personalización total (v1.25.0)

### Alcance de esta fase, dicho primero
Cuatro piezas: orden de módulos, Dashboard personalizable, navegación personalizable y perfiles
predefinidos. Más la gestión de dependencias entre módulos.

### Añadido / cambiado
- **`src/tokens.js` → `PERFILES_MODULOS`**: los cuatro perfiles que pide la especificación —
  **Completo**, **Estudiante**, **Fitness** y **Minimalista**. Cada uno declara qué módulos deja
  activos; el resto se desactivan.
- **`src/tokens.js` → `DEPENDENCIAS_MODULOS`**: qué módulos se alimentan de qué otros. Solo se
  modela la dependencia **real de datos**, la que hace que un módulo se quede sin nada que
  mostrar: Estadísticas, Predicciones, Logros y (parcialmente) Calendario.
- **`PerfilesRapidos`**: cuatro tarjetas con confirmación que dice cuántos apartados quedarán
  activos y recuerda que no se borra nada.
- **`MiDashboard`** — "Mi pantalla de inicio": el editor de `dashboardOcultos` que llevaba
  pendiente desde que el Dashboard se amplió a Centro de Control. El modelo y el filtrado ya
  existían; faltaba la interfaz. Solo lista módulos activos: ofrecer un interruptor de "ver en
  Hoy" para algo desactivado sería un control que no hace nada.
- **Aviso de dependencias** dentro de la confirmación de desactivar: si el módulo alimenta a otros
  que están activos, se dice cuáles y que tendrán menos que mostrar. **No se bloquea ni se
  desactiva nada en cascada** — la especificación pide gestionar la dependencia y no dejar la app
  rota, no decidir por el usuario.
- **`src/App.jsx`**: `toggleDashboardModulo` y `aplicarPerfilModulos`. El segundo solo toca
  `ocultos`: el orden, los iconos, el PIN y las métricas favoritas se respetan tal cual — un
  perfil decide QUÉ usas, no cómo lo tienes colocado. Si el perfil desactiva la pestaña abierta,
  se vuelve a "Hoy".

### Decisiones
- **El reordenar se queda con flechas, no con drag & drop.** La especificación pide DnD "cuando
  tenga sentido, especialmente en móvil", pero el apartado 103 de la especificación de Ajustes
  ofrece explícitamente la alternativa: *"interacción directa (drag&drop) **o controles accesibles
  equivalentes**"*. Las flechas ya funcionan, son accesibles por teclado y para lectores de
  pantalla, y no necesitan una librería nueva ni gestos táctiles que compiten con el scroll de la
  página. Documentado como decisión, no como olvido: si Josué prefiere DnD de verdad, es una
  petición concreta y acotada.
- **La navegación principal sigue siendo de 5 pestañas fijas.** La especificación pide "permitir
  que el usuario decida qué módulos aparecen como accesos principales, siempre que sea
  técnicamente viable" — pero la regla de que la barra inferior tiene **exactamente 5 pestañas,
  nunca una sexta** es del propio Josué y se repite en dos prompts distintos. Lo que sí es
  personalizable, y ya lo era, es el contenido de cada hub. Si quiere cambiar eso, es una decisión
  suya que contradice una regla suya: hay que preguntárselo, no resolverlo por él.
- **No se guarda "qué perfil tienes puesto".** En cuanto Josué cambie un solo interruptor esa
  etiqueta sería mentira, y la especificación insiste en que los perfiles no deben bloquear la
  personalización posterior.
- **Las dos listas de ocultación se mantienen separadas**, y la especificación lo respalda
  literalmente: *"Módulo activado ≠ necesariamente visible en Dashboard"*.

### Comprobado
- **28 pruebas** de la lógica de perfiles y dependencias (`scripts/test-personalizacion.mjs`):
  que ningún perfil referencia módulos inexistentes, que ninguno toca "ajustes", que las
  dependencias declaradas existen, que ningún módulo depende de sí mismo, y que el aviso solo
  menciona dependientes que estén activos.
- **4 pruebas nuevas de comportamiento** sobre el HTML: quitar algo de Hoy sin desactivarlo
  funciona, y ambas listas conviven aplicando cada una su efecto.
- Total en verde: 27 + 28 + 20 comprobaciones + 48 casos de renderizado.

### Pendiente (documentado, no implementado en esta fase)
- Drag & drop real para reordenar (ver Decisiones).
- Accesos principales configurables (choca con la regla de las 5 pestañas — decisión de Josué).
- Sin probar en un iPhone real.


## Entrega 2 · ME Fase 1 — Sistema de módulos activables/desactivables (v1.24.0)

### Alcance de esta fase, dicho primero
Primera fase de la Entrega 2. La especificación pide que el usuario decida qué apartados quiere
usar, que desactivar **nunca** borre datos, y que "la interfaz se reconstruya automáticamente según
los módulos activos".

**Análisis primero, como manda la regla de oro de la propia especificación** ("¿esto ya existe en
JC Fitness? → CONECTAR / INTEGRAR / REUTILIZAR / CREAR"): `PersonalizationView` (Fase 19) ya
permitía ocultar módulos con `personalizacion.ocultos`. Así que **no se ha creado un sistema
paralelo**: se ha ampliado el existente. Lo que faltaba de verdad no era el modelo de datos, era
que ocultar **hiciera algo más allá de los hubs**.

### El hueco real que se ha cerrado
`personalizacion.ocultos` solo se consultaba en `HubView`. Un módulo "desactivado" seguía
apareciendo en "Hoy" con su tarjeta, su aviso y su acción rápida. El Dashboard tenía además su
propia lista (`dashboardOcultos`), sin editor. Es decir: dos sistemas de ocultación y ninguno
completo.

Ahora hay una distinción clara entre dos cosas que un usuario quiere poder hacer por separado:
- **`personalizacion.ocultos`** — "no uso este apartado". Afecta a TODA la app.
- **`dashboardOcultos`** — "sí lo uso, pero no quiero verlo en Hoy". Preferencia de pantalla.

### Añadido / cambiado
- **`src/components/ui.jsx`**: nuevo `Switch` — interruptor ON/OFF accesible (`role="switch"`,
  `aria-checked`, navegable por teclado). El apartado 8 de la especificación de Ajustes lo lista
  como componente permitido y el apartado 14 exige que una misma configuración se represente
  siempre igual; hasta ahora cada sitio resolvía el activado/desactivado a su manera.
- **`src/tokens.js`**: `DESCRIPCIONES_MODULOS` — una descripción por módulo, ≤80 caracteres,
  describiendo el efecto y no cómo se usa el control (apartado 11).
- **`src/views/PersonalizationView.jsx`**: nuevo `CentroModulos` — "Personalizar mi sistema",
  agrupado por las cuatro áreas que ya existen en la barra inferior (no se inventa una taxonomía
  nueva). Cada fila: icono, nombre, descripción e interruptor. Contador de activos.
  Confirmación al desactivar que insiste en que **no se borra nada**; ninguna al reactivar.
- **`src/views/PersonalizationView.jsx`**: retirado el botón de ojo de la lista de reordenación —
  tener dos controles distintos para la misma configuración es justo lo que prohíbe el apartado 14.
  Esa lista se queda con lo suyo: orden, icono y PIN. Los desactivados se marcan con una etiqueta.
- **`src/views/DashboardView.jsx`**: `oculto(id)` consulta ahora las dos listas. Se filtran las
  tarjetas de Nivel 1/2/3, los tres avisos automáticos, el acceso a Calendario y Agenda, el
  recordatorio de Relación y las acciones rápidas (que pasan a ser un catálogo filtrable; si no
  queda ninguna, desaparece también el encabezado).
- **`src/lib/puntuacion.js`**: acepta la lista de desactivados. Si Josué ha dicho que no usa Sueño,
  que le baje la nota por no registrarlo sería exactamente lo contrario de lo que pidió.
- **`src/App.jsx` / `src/views/SettingsView.jsx`**: `AREAS_NAV` y `personalizacion.ocultos` se
  reenvían a donde hacen falta.

### Decisiones
- **Ampliar en vez de crear**, siguiendo la regla de la propia especificación. El modelo de datos
  (`personalizacion.ocultos`) no cambia: cualquier cuenta existente sigue funcionando sin migración.
- **Agrupado por las áreas ya existentes** en vez de por las categorías del ejemplo de la
  especificación (Salud/Deporte/Productividad): son las que Josué ya conoce de navegar la app, y
  además el script `comprobar-navegacion.mjs` ya garantiza que ese reparto es completo y sin
  duplicados.
- **"Ajustes" nunca es desactivable** — `moreNavPersonalizables` ya lo excluía. Sin él, Josué no
  tendría forma de volver a activar lo que desactivó.
- **Relación se puede desactivar, pero eso no la desprotege**: desactivar y proteger con PIN son
  cosas distintas. Con Relación desactivada, además, deja de asomar el recordatorio de la pareja
  en la pantalla principal.

### Comprobado
- **16 pruebas de comportamiento** (`scripts/test-modulos.jsx`) sobre el HTML realmente renderizado:
  que lo desactivado desaparece, que lo demás sigue ahí, que desactivarlo todo no rompe nada ni
  deja encabezados huérfanos, que renderizar no muta los datos, y que todas las descripciones
  existen y respetan el límite de 80 caracteres.
- **48 casos de renderizado** (`scripts/smoke.mjs`), ahora con un cuarto escenario: "todo
  desactivado".
- Build limpio, y las nueve reglas invariantes del proyecto en verde.

### Pendiente (documentado, no implementado en esta fase)
- **Buscador universal**: sigue buscando sobre datos, no sobre funciones. Filtrar funciones de
  módulos desactivados corresponde a **BI Fase 3**, que es donde se construye el índice.
- **Menú lateral**: la especificación lo menciona, pero esta app no tiene (navega con 5 pestañas
  y hubs). No aplica.
- Sin probar en un iPhone real.


## Bloque R0 — Correcciones críticas y verificación automática (v1.23.0)

### Alcance de esta fase, dicho primero
Primer turno con **acceso real a npm** en el entorno de desarrollo. Eso cambia una premisa que
llevaba vigente desde la v1.0.1: ya no es cierto que "Claude solo pueda revisar el código a mano".
`npm install` y `npm run build` funcionan, y **el proyecto compila sin errores (2604 módulos)** —
la primera verificación real en 22 incrementos de versión. Sobre esa base se han corregido las tres
incoherencias críticas del bloque R0 y se ha construido una suite de verificación reutilizable.

### Verificación automática (`scripts/`, nuevo)
- **`verificar.sh`** — build + pruebas + nueve reglas invariantes del proyecto, que hasta ahora se
  comprobaban a mano fase a fase: nadie desestructura `COLORS`, ningún hex suelto fuera de
  `tokens.js`, todo overlay `fixed inset-0` con `createPortal`, sin notas internas de desarrollo
  visibles, `relacion` fuera de la exportación, PIN de Relación intacto, exactamente 5 pestañas,
  navegación coherente, y **todo ajuste de Apariencia con efecto CSS real**.
- **`smoke.mjs` + `smoke-vistas.jsx`** — renderizan 11 vistas con `react-dom/server` en tres
  escenarios: vacío, con datos y **datos parciales** (campos que faltan, como los que dejaría una
  versión anterior). 33 casos. Compilar no detecta un `undefined.map()`; esto sí.
- **`test-puntuacion.mjs`** — 22 comprobaciones de la puntuación nueva.
- **`resolver-vite.mjs`** — hook de resolución que permite ejecutar con Node los módulos de `src/`
  tal y como están escritos (imports sin extensión), sin cambiar la convención del proyecto.
- **`comprobar-navegacion.mjs`** — cruza `MORE_NAV`, `AREAS_NAV` y los `case` del switch para
  detectar módulos huérfanos (navegables sin pantalla, o pantallas inalcanzables).

### R0.1 — Modelo de IA obsoleto (`api/ask-ai.js`)
- `model: 'claude-sonnet-4-6'` ya no existe. En cuanto Josué activara `ANTHROPIC_API_KEY`, habrían
  fallado **las 13 secciones con `AIPanel`, el buscador universal, el panel de sugerencias, el
  escaneo de comida por foto y el análisis de vídeo de calistenia** — y el síntoma habría sido un
  genérico "la IA no funciona", sin pista de la causa. Había pasado desapercibido precisamente
  porque la clave nunca se ha activado: la función devuelve `503` antes de llamar a Anthropic.
- El modelo se lee ahora de `ANTHROPIC_MODEL` (por defecto `claude-sonnet-5`), así que cambiarlo
  no exige tocar código ni volver a subir el proyecto: se cambia en el panel de Vercel.
- Un `404` de modelo devuelve un mensaje que dice exactamente qué pasa y dónde arreglarlo.

### R0.2 — Puntuación diaria (`src/lib/puntuacion.js`, nuevo)
- La fórmula anterior vivía suelta en `DashboardView` y sumaba puntos por tener datos *alguna vez*:
  `sueno[último]`, `nivel > 0`, `movimientos.length > 0`. Ninguna miraba la fecha. Resultado: en
  cuanto había un dato de cada, **se quedaba en 100 para siempre** mientras la etiqueta decía
  "Puntuación de hoy". Era un dato falso en la pantalla principal.
- Ahora es el **porcentaje de las áreas que Josué realmente usa que ha registrado hoy**. Un área
  solo entra en el cálculo si ya tiene datos, así que no penaliza por módulos que no utiliza —
  mide constancia real, no cuántos módulos tiene abiertos.
- Ocho áreas: Sueño (acepta el registro de anoche), Entrenamiento, Nutrición, Hábitos (exige
  marcarlos todos), Tareas vencidas, Diario, Estudio y Salud (ventana de 7 días, no diaria).
- Desplegable para ver **de dónde sale cada punto** — misma regla de honestidad que rige los
  paneles de IA. Sin datos todavía, no muestra un 0 desmotivador: lo dice y ya está.
- Sin puntos acumulables, sin niveles, sin monedas: se reinicia sola cada día y no se guarda en
  ningún sitio (reglas 33/34, no sobregamificar).
- Cierra el TODO heredado de la sección 18 del HANDOFF ("revisar si la puntuación diaria debería
  basarse en el día calendario real") y una de las dos piezas que la Fase 20 dejó sin construir.

### R0.3 — Densidad de interfaz (`src/index.css`, `src/App.jsx`)
- Situación de partida: `tokens.js` afirmaba en un comentario que ya funcionaba, `index.css` no
  tenía **ni una sola regla** `data-densidad`, y la propia interfaz le decía a Josué que las tres
  densidades se veían igual. Un comentario del código mintiendo es peor que la función faltante:
  la siguiente sesión se fía de él y da el apartado 91 por cerrado.
- Implementada de verdad con el mismo mecanismo de override global por atributo que ya usaban los
  radios de borde desde la Fase A3. Se ajustan el ritmo vertical entre tarjetas (`space-y-*`) y el
  relleno interior (`p-5`/`p-4`).
- **No se tocan `gap-*` a propósito**: el gap afecta también al eje horizontal y cambiarlo puede
  hacer que una fila de píldoras o una rejilla de 2 columnas se parta distinto según el contenido.
  El objetivo es cambiar la sensación de aire, no arriesgar el layout.
- "Estándar" no lleva override: es exactamente lo que la app ya era.

### Cinco bugs reales encontrados por las pruebas nuevas
Ninguno se habría detectado compilando. Los cinco dejaban pantallas en blanco o mostraban datos
falsos:
1. **`calcularDuracion()`** reventaba con un registro de sueño sin horas y dejaba en blanco
   **cuatro** pantallas a la vez (Hoy, Sueño, Estadísticas y las tarjetas de hub). Ahora devuelve
   `null`, y hay un `formatHoras()` compartido que lo presenta como "— h".
2. **`AvisoSuenoCorto`** mostraba "null h" y **disparaba una notificación real** por un dato
   inexistente: en JavaScript `null < 7` es `true`.
3. **Las dos correlaciones de sueño** contaban un registro incompleto como noche corta, falseando
   el resultado entero.
4. **La media de `SleepView`** se volvía `NaN` con un solo registro incompleto.
5. **`DiaryView`** cargaba la entrada guardada sin fusionarla con el formulario vacío; una entrada
   incompleta hacía reventar el `.trim()` y dejaba el Diario en blanco. Corregido con el patrón
   `{ ...DEFAULT, ...guardado }`, el mismo que ya se aplicó en A2, A3 y en el Dashboard.

### Saneado documental (R0.4 / R0.5 / R0.6)
- **Fase A7 registrada** (ver la entrada de abajo): existía en el código y en ningún changelog.
- **`HANDOFF.md`**: las secciones 3, 5, 9, 10, 11, 13 y 15 describían el estado en v0.21.0/v1.0.0 y
  contradecían los banners de arriba — decían que la Fase 20 estaba pendiente y que la navegación
  era `PRIMARY_NAV` + hoja "Más", eliminada en la Fase N1. Corregidas o marcadas con un aviso que
  remite a `docs/`.
- **`personalizacion.pinExtra`** marcado explícitamente como **vestigial**: ya no se escribe nunca,
  solo se lee una vez durante la migración a `seguridad.protectedAreas`. Se conserva porque
  borrarlo dejaría sin migrar a las cuentas que aún no lo hayan hecho.

### Añadido lo que faltaba en el repositorio
- **`.gitignore`** y **`.env.example`** solo existían dentro del zip, no versionados. Sin el
  primero, `node_modules/` (193 paquetes) y `dist/` eran candidatos a acabar en el repositorio.
- `.env.example` documenta ahora también `ANTHROPIC_MODEL`.

### Pendiente (documentado, no implementado en esta fase)
- Sigue sin probarse en un iPhone real: renderizar con `react-dom/server` detecta errores de
  ejecución, pero no layout, ni gestos, ni Safari.
- La segunda pieza que la Fase 20 dejó sin construir — la **revisión automática semanal/mensual/
  anual** — sigue pendiente (bloque R4.2).

## Fase A7 — Accesibilidad, paletas predefinidas y densidad (registrada retroactivamente)

> **Esta fase se construyó pero nunca se registró.** El código la cita seis veces (`tokens.js`
> líneas 58, 137, 141, 150 y 158; `GestionTemas.jsx` línea 10), pero no existía ninguna entrada en
> este archivo y `HANDOFF.md` declaraba que el bloque Ajustes "se cierra con A1-A6". Se documenta
> ahora para que una auditoría futura de qué apartados de Ajustes están cubiertos no dé un
> resultado equivocado.

### Añadido / cambiado
- **Alto contraste** (apartado 43, Accesibilidad): `apariencia.altoContraste` +
  `CONTRASTE_ALTO_OSCURO`/`CONTRASTE_ALTO_CLARO` en `tokens.js`. Solo ajusta `textMuted` y `border`
  — deliberadamente conservador, para no rehacer la paleta entera.
- **Paletas predefinidas** (apartado 86): las 7 originales de `PALETAS_PREDEFINIDAS`, ampliadas
  después a 10 en la Fase V4 con Monocromático, Neón y Pastel.
- **Densidad de interfaz** (apartado 91): la opción y su modelo de datos. ⚠️ **Nunca llegó a tener
  efecto visual** — se completó en el bloque R0 (v1.23.0), ver arriba.


## Finalización del Calendario + eliminación de notas internas (v1.22.0)

### Alcance de esta fase, dicho primero
Dos frentes pedidos en el mismo turno, uno de limpieza y otro de funcionalidad real. Primero, una auditoría completa de toda la interfaz en busca de texto dirigido a un desarrollador (menciones a "Fase X", "apartados X-X", "queda pendiente", "todavía no está construido"...) que se hubiera colado en pantallas que sí ve Josué — encontrado sobre todo en Ajustes, acumulado fase a fase. Segundo, cerrar el Calendario de verdad: que una fecha importante de Relación (empezando por el caso estrella, un cumpleaños) pueda marcarse "repetir cada año" y aparecer sola, cada año, en el Calendario — sin duplicar el dato de Relación y sin romper la única protección de privacidad de principio a fin que tiene la app.

### Auditoría y limpieza de notas internas (`src/views/SettingsView.jsx`, `src/views/WellbeingView.jsx`)
- Eliminado el componente `ComingSoon` y su único uso (un aviso "Todavía no está construida. Está planificada para..." que se mostraba para cualquier categoría de Ajustes sin `listo: true`) — ya no queda ninguna categoría en ese estado, así que el propio componente ha desaparecido en vez de quedarse sin usar.
- `useCategorias()`: retiradas las categorías "Inteligencia Artificial" y "Funciones experimentales" — la primera es AXION, una iniciativa aparte con su propia especificación de más de 1.000 apartados, sin sitio real en esta fase del Calendario; la segunda nunca llegó a tener contenido concreto que mostrar. "Accesibilidad" pasa de `listo: false` a `listo: true, soloInfo: true` (mismo patrón que Preferencias/Sincronización/Integraciones) con un aviso real, no un "todavía no": el tamaño de texto, reducir movimiento y el alto contraste ya viven en Apariencia desde antes, así que aquí solo se redirige.
- Cinco bloques `InfoOnly` que citaban literalmente "apartados X-X de la especificación" (en Apariencia, Seguridad y Privacidad) eliminados por completo — describían huecos de construcción interna, no información que Josué necesite dentro de la propia app. El resto de `InfoOnly` (qué usa la IA, permisos del dispositivo, idioma/zona horaria, notificaciones, sincronización, integraciones) se han mantenido pero reescrito quitando referencias a fases/apartados y frases de "queda pendiente" — la información honesta sobre limitaciones reales de la app (ej. "no hay Web Push todavía") se conserva, solo se ha quitado el lenguaje de hoja de ruta interna.
- `WellbeingView.jsx`: el aviso bajo el formulario de Tiempo de Uso pasó de "la importación automática... queda pendiente" (suena a una función a medio construir) a explicar el motivo real y permanente — un navegador no puede leer el tiempo de uso del sistema operativo, así que el registro manual no es una limitación temporal de esta fase, es cómo va a funcionar siempre.

### Calendario — fechas recurrentes de Relación (`src/tokens.js`, `src/views/RelationView.jsx`, `src/lib/calendarioIntegracion.js`, `src/App.jsx`)
- **`tokens.js`**: cada fecha de `relacion.fechas` gana dos campos opcionales — `tipo` (`cumpleanos`/`aniversario`/`fecha_importante`/`otro`, con su emoji, nueva constante `TIPOS_FECHA_RELACION`) y `repetir` (booleano). Las fechas ya guardadas antes de esta fase no los tienen y se tratan como `tipo: 'otro'`, `repetir: false` — no se migra nada solo: activar la repetición es una decisión que Josué toma al editar cada fecha.
- **`RelationView.jsx`**: la pestaña Fechas gana un selector de Tipo y un interruptor "Repetir cada año" (mismo lenguaje visual que el interruptor "Todo el día" del editor de eventos del Calendario) en el formulario de alta, y — novedad real de esta fase — edición: cada fecha ya guardada tiene ahora un botón de editar además del de borrar, que reabre el mismo formulario con sus datos, en vez de solo poder borrarla y crearla de cero. La pestaña "Días especiales" (presets como Cumpleaños/Aniversario) también gana el interruptor de repetición, activado por defecto al elegir un preset (son fechas que por naturaleza vuelven cada año), editable antes de confirmar.
- **`calendarioIntegracion.js`**: nueva `eventosDeRelacion(relacion)`, sumada a `eventosDerivados()` junto a Objetivos/Estudios/Entrenamiento/Productividad. Cada fecha con `repetir: true` se convierte en un evento derivado con `recurrencia: { frecuencia: 'anual', hasta: null }` — se reutiliza tal cual el motor de recurrencia que ya tenía el Calendario para sus propios eventos manuales (`expandirRecurrentes`, Fase 3 del Calendario Universal), que ya se aplica indistintamente a eventos propios y derivados, así que no hace falta tocar `CalendarView.jsx` ni `lib/calendario.js` para nada de esto. El título del evento se genera en el momento ("🎂 Cumpleaños de {nombre}" para cumpleaños, emoji+etiqueta para el resto) a partir del nombre ya guardado en `relacion.nombre` — nunca se guarda el nombre por segunda vez.
- **Privacidad**: `App.jsx` solo le pasa los datos reales de `relacion` a `eventosDerivados()` cuando Relación está desbloqueada en la sesión actual (`estaDesbloqueado('area:relacion')`, la misma comprobación que ya protege la propia pestaña) o cuando no hay ningún PIN configurado; si no, pasa `null` y ninguna fecha de Relación llega al Calendario ni al Dashboard — ni siquiera el indicador discreto del día. Esto sustituye la exclusión total que tenía Relación desde la Fase 2 del Calendario Universal por una inclusión condicionada a la misma autorización que ya existía, en vez de inventar un segundo sistema de permisos.
- **`App.jsx`**: nuevo `updateFechaImportante` (mismo patrón `snapshotAndSave` que el resto de módulos de datos), cableado a `RelationView` como `onUpdateFecha`.
- Tocar el evento derivado de un cumpleaños en el Calendario abre su detalle de solo lectura (mismo componente `DetalleEventoDerivado` que ya usan Objetivos/Estudios/Entrenamiento/Productividad, con "relacion" añadido a `NOMBRES_ORIGEN`) con un botón "Abrir en Relación" — como Relación solo modela una persona (la pareja), abrir Relación desde ahí ya es "acceder a la información de esa persona", sin necesidad de una pantalla de perfil nueva.

### Decisiones
- **No se ha construido un sistema de múltiples personas/contactos en Relación.** La especificación describe el caso con el nombre "María" como si Relación pudiera tener varias personas, pero el modelo de datos real (y toda la app hasta ahora) modela una sola relación de pareja (`relacion.nombre`, un único string). Construir un sistema de contactos con altas/bajas de personas sería una ampliación de alcance no pedida explícitamente ("finalizar el Calendario", no "convertir Relación en una agenda de contactos") y con implicaciones de privacidad propias que no se han evaluado. Se ha tratado a la única pareja ya modelada como "la persona" del caso de uso — cumple el mismo recorrido descrito (crear/nombrar, añadir cumpleaños, repetir, ver en Calendario, abrir su info) sin inventar una estructura de datos nueva.
- **Editar o eliminar una fecha recurrente afecta a toda la serie**, igual que ya pasaba con los eventos recurrentes propios del Calendario (Fase 3): como la recurrencia se calcula al vuelo a partir de una única fecha ancla (nunca se guarda una copia por año), cambiar esa fecha o borrar la entrada de Relación cambia o hace desaparecer automáticamente todas las ocurrencias, pasadas y futuras, sin ningún código adicional de limpieza.
- **La arquitectura queda preparada para que otros módulos generen fechas del calendario** (Estudios→exámenes ya lo hace desde la Fase 2; Entrenamiento→sesiones, Economía→pagos, Productividad→tareas y Objetivos→plazos, también) — `eventosDerivados()` ya combina varias fuentes con la misma forma, así que sumar una nueva fuente futura es exactamente el mismo patrón que `eventosDeRelacion`, sin tocar `CalendarView.jsx`.

### Pendiente (documentado, no implementado en esta fase)
- No se ha podido probar en un navegador real el recorrido completo (crear cumpleaños → verlo en el Calendario → editarlo → borrarlo → recargar) — se ha verificado leyendo el código paso a paso contra el motor de recurrencia y las condiciones de privacidad ya existentes, no ejecutando la app.
- No se ha podido verificar con `esbuild` en este entorno (sin acceso al registro de npm, `403`, mismo límite de siempre) — revisado a mano: balance de paréntesis/llaves/corchetes comprobado por script en los seis archivos tocados (OK; una comprobación adicional en `LibraryView.jsx`, sin tocar en esta fase, dio un falso positivo del propio script por un literal de expresión regular con barras escapadas — se ha revisado el archivo entero a mano y está bien formado).

## Ajuste del indicador de contexto + acceso directo a Agenda (v1.21.0)

### Alcance de esta fase, dicho primero
Dos ajustes puntuales sobre el Dashboard ampliado de la fase anterior, pedidos en el mismo turno pero con motivos distintos: (1) el indicador de Viaje/Vacaciones/Exámenes (`ModoBanner`) ocupaba demasiado alto cuando había un modo activo — Josué pidió conservar la función tal cual pero convertirla en un indicador compacto y expandible; (2) un "paréntesis" pidiendo que la Agenda (el toggle Mes/Agenda que ya vive dentro del Calendario desde la Fase 3) tenga también su propio acceso directo de un solo toque desde "Hoy", independiente del acceso a Calendario, sin duplicar navegación.

### Añadido / cambiado
- **`src/views/DashboardView.jsx`**: `ModoBanner` (bloque siempre visible con 2-4 líneas de consejos) sustituido por `IndicadorContexto` — un componente tipo acordeón: cerrado por defecto, icono+etiqueta+flecha en una sola línea (mismo alto que el resto de filas compactas del Dashboard), que se expande in-place al pulsarlo mostrando los consejos del modo activo, con una transición real de altura+opacity (técnica `grid-template-rows` 0fr↔1fr, sin medir nada a mano ni añadir dependencias) y la flecha rotando 180°, mismo patrón que ya usan `SkillCard`/`RutinaCard`/`AsignaturaCard`/`ExamenItem` en el resto de la app. A diferencia del antiguo `ModoBanner` (que desaparecía del todo sin modo activo), `IndicadorContexto` está siempre visible — "Rutina normal" (icono `Home`) es un estado más, no la ausencia del componente. Nuevos iconos por modo: `Plane` (Viaje, ya se usaba), `Sun` (Vacaciones), `GraduationCap` (Exámenes, reutilizado del icono de Estudios).
- **`src/views/DashboardView.jsx`**: `AccesoCalendario` (una sola fila ancha) sustituido por `AccesoCalendarioYAgenda` — dos tarjetas compactas en la misma fila (rejilla de 2 columnas, mismo alto total que antes): "Calendario" (resumen de hoy, sin cambios de fondo) y "Agenda" nueva, con el número de eventos de hoy ("N cosas pendientes hoy" / "Nada pendiente hoy"). Tocar "Agenda" navega directamente a la vista Agenda ya existente dentro de `CalendarView.jsx`, sin pasar primero por la vista Mes.
- **`src/views/CalendarView.jsx`**: acepta `foco`/`onFocoConsumido` (mismo mecanismo de deep-link de la fase anterior) — `foco.vista === 'agenda'` cambia el `ToggleTab` Mes/Agenda que ya existía desde la Fase 3, sin tocar su lógica interna ni duplicarla.
- **`src/App.jsx`**: la llamada a `CalendarView` en `renderContent()` recibe ahora `foco={focoPara('calendario')}`/`onFocoConsumido={consumirFoco}`, igual que las demás vistas de destino. `onAbrirCalendario` (prop que solo hacía `setTab('calendario')`, ya redundante desde que `DashboardView` recibe `onNavegar`) se retira de la llamada a `DashboardView` — la propia tarjeta de Calendario ya usa `onNavegar('calendario')` directamente.

### Decisiones
- **Agenda no es un módulo de datos nuevo ni una pestaña nueva** — sigue siendo exactamente el mismo toggle Mes/Agenda de `CalendarView.jsx` (Fase 3 del Calendario Universal), con los mismos eventos, el mismo motor (`expandirRecurrentes`, tope de 50 eventos/60 días). Lo único nuevo es el punto de entrada: antes hacía falta tocar Calendario y luego el interruptor interno a mano; ahora "Hoy → Agenda" aterriza ya en esa vista de un solo toque, vía el mismo `foco` que usa el resto del Dashboard. Esto cumple a la vez "Dashboard → Agenda debe ser un acceso directo" y "no crear navegación paralela / no duplicar Agenda dentro de Calendario" — no hay dos implementaciones de Agenda, hay dos puertas a la misma.
- **El contenido expandido del indicador de contexto muestra los consejos ya existentes (`MODOS_APP[].tips`), no fechas ni "objetivos adaptados" inventados** — la especificación pedía como ejemplo ilustrativo mostrar fechas de viaje/vacaciones y un recuento de objetivos adaptados, pero el modelo de datos de `MODOS_APP` (tokens.js) nunca ha tenido esos campos, solo `id`/`label`/`tips` de texto fijo. Añadirlos habría exigido una pantalla de captura nueva (fechas, qué objetivos se "adaptan" y cómo) — alcance no pedido explícitamente y contrario a "conserva la funcionalidad actual, modifica su presentación". Se ha preferido mostrar honestamente lo que ya existe.
- **No se ha añadido un botón "Ver detalles"** (previsto en la propia especificación "si en el futuro hay mucha más información") — con 2-3 consejos de texto no hace falta resumir todavía; el propio indicador ya muestra el contenido completo al expandirse. Queda documentado como extensión futura directa si `MODOS_APP` crece.
- **Verificación de los iconos nuevos**: antes de usar `Sun`/`ClipboardList` (no usados en ningún sitio anterior de esta app) se comprobó contra la documentación pública de Lucide que ambos son nombres estables desde versiones muy anteriores a la `0.383.0` que usa este proyecto (sin acceso a `npm`/`node_modules` en este entorno para comprobarlo instalando el paquete de verdad) — evitado a propósito `Palmtree`, que resultó ser un alias antiguo renombrado a `TreePalm` en versiones intermedias de Lucide, para no arriesgar un import roto.

### Pendiente (documentado, no implementado en esta fase)
- No se ha podido verificar con `esbuild` en este entorno (sin acceso al registro de npm, `403`, mismo límite de siempre) — revisado a mano: balance de paréntesis/llaves/corchetes por script en los tres archivos tocados (OK).
- No se ha podido comprobar visualmente la animación de expansión (altura+opacity) en un navegador real — la técnica CSS usada (`grid-template-rows` 0fr↔1fr) es un patrón estándar y ampliamente documentado, pero su aspecto final no se ha podido renderizar en este entorno.

## Ampliación del Dashboard — Centro de Control interactivo (v1.20.0)

### Alcance de esta fase, dicho primero
Josué pidió que "Hoy" deje de ser un simple resumen y se convierta en un Centro de Control: ver de un vistazo el estado de (casi) cualquier área de la app y, sobre todo, poder pulsar cualquier elemento representado ahí para llegar directo a él — incluido, siempre que sea técnicamente posible, el elemento concreto (un objetivo, una habilidad, un examen, una tarea), no solo el módulo. Especificación propia de 23 apartados, con una regla de oro explícita: "no quiero tarjetas bonitas que no hagan nada". **Análisis primero, tal y como pedía el apartado 23** ("no inventes rutas, componentes o funcionalidades que ya existan con otro nombre"): se releyó `App.jsx` entero (navegación por `tab`/`setTab`, sin ningún router de verdad — confirmado, nada que sustituir), `DashboardView.jsx` tal y como quedó tras la fase de compactación anterior, y `resumenesHub.js` — que ya calculaba, módulo por módulo, exactamente el resumen de dos líneas + estado que los hubs de "Más" llevan usando desde la Fase N1, así que gran parte de las tarjetas de Nivel 2 de esta fase lo reutilizan tal cual, sin duplicar ningún cálculo.

### El mecanismo de deep-link, sin router paralelo
`App.jsx` añade un único estado nuevo, `dashboardFoco` (`{ modulo, id/skill/examenId/tareaId/accion, ... }`), y una única función de navegación, `navegarDesdeHoy(modulo, foco)`, que por dentro sigue siendo `setTab(modulo)` — el mismo mecanismo de navegación que ya existía, ampliado con "y opcionalmente, esto es lo que quiero ver dentro". `focoPara(modulo)` filtra ese estado para que cada vista de destino solo reciba el suyo, nunca la forma interna de las demás. Cada vista que sabe interpretarlo (Sueño, Entreno, Objetivos, Estudios, Productividad, Economía) lo consume una única vez — hace scroll hasta el elemento, lo resalta brevemente o abre el formulario correspondiente — y llama a `onFocoConsumido()`, que limpia el estado: volver a esa pestaña después por la navegación normal no vuelve a saltar sola al mismo sitio.

### Añadido / cambiado
- **`src/components/ui.jsx`**: tres primitivas nuevas — `DashboardModuleCard` (tarjeta pulsable con icono, valor destacado, línea secundaria y estado vacío honesto, apartado 12), `MiniAccessCard` (acceso compacto de solo icono+etiqueta para los módulos de Nivel 3) y `QuickActionButton` (píldora con icono en círculo, deliberadamente distinta de una tarjeta para que se note que abre un formulario y no navega a mirar un resumen, apartado 13/14). `Card` acepta ahora un `id` opcional (para el scroll-to-element del deep-link), cambio aditivo que no afecta a ningún uso existente.
- **`src/views/DashboardView.jsx`** reescrita con tres niveles de información nuevos, tal y como pedía el apartado 9, todos en rejillas compactas (2 o 3 columnas, nunca una tarjeta grande por fila, apartado 8):
  - **Nivel 1** (rejilla 2×2): Sueño, Entreno (con la habilidad de calistenia entrenada más recientemente o de mayor progreso — deep-link directo a ella, apartado 6), Objetivos (con el primer objetivo sin cumplir — deep-link a ese objetivo exacto, apartado 4) y Estudios (con el examen más próximo — deep-link a él).
  - **Nivel 2** (rejilla 2×2): Economía y Nutrición (reutilizan `calcularResumenModulo` de `resumenesHub.js`, sin cálculo nuevo), Productividad (con la tarea pendiente más próxima — deep-link a ella) y Salud (peso más reciente + IMC, misma fórmula exacta que ya usa Ajustes → Perfil → Cálculos corporales).
  - **Nivel 3**: fila de 6 mini-accesos de solo icono (Diario, Negocio, Relación, Biblioteca, Fe, Bienestar) — sin resumen de datos a propósito, para que Relación (protegida por PIN) nunca se asome fuera de su propia pantalla.
  - Las métricas favoritas (Fase 19) ahora también son pulsables — cada una navega a su módulo de origen.
  - Nueva fila **"Acciones rápidas"**: Sueño, Gasto, Tarea y Objetivo — cada botón navega y abre directamente el formulario de alta correspondiente (mismo formulario de siempre en cada vista, nunca uno duplicado), separada visualmente de las tarjetas para no mezclar "pulsar para ver" con "pulsar para crear" (apartado 13/14).
- **Deep-link consumido en seis vistas de destino**, cada una con el mínimo cambio necesario, reutilizando siempre su propio estado/UI ya existente:
  - `SleepView.jsx`/`FinanceView.jsx`: `foco.accion` abre el formulario de alta que ya tenían (`showForm`).
  - `ObjectivesView.jsx`: `foco.id` hace scroll y resalta 2,2s el objetivo con un halo del color de acento; `foco.accion === 'nuevo'` hace scroll al campo y lo enfoca.
  - `TrainingView.jsx`: `foco.skill` cambia a la subpestaña Calistenia y la `SkillCard` de esa habilidad se autoexpande y hace scroll — cada tarjeta decide esto sola (mismo criterio que la rejilla 2×2 de la fase anterior), sin levantar el estado de las 7.
  - `EstudiosView.jsx`: `foco.examenId` cambia al programa correcto, despliega la `AsignaturaCard` que contiene ese examen y el propio `ExamenItem` se despliega y hace scroll — tres niveles de componentes anidados coordinados con un único id.
  - `ProductivityView.jsx`: `foco.sub` cambia de subpestaña; dentro de Tareas, `foco.tareaId` resalta la tarea y `foco.accion === 'nueva'` enfoca el campo de alta.
- **`tokens.js`**: `DEFAULT_PERSONALIZACION` gana `dashboardOcultos: []` — arquitectura preparada para un futuro editor en Ajustes que decida qué módulos mostrar en el Dashboard (apartado 10/11: "la arquitectura debe quedar preparada... no significa que haya que implementar obligatoriamente un editor completo en esta fase"). `DashboardView.jsx` ya filtra por esta lista con una única función (`oculto(id)`) — activar el editor en el futuro es solo construir la UI que la rellene, sin tocar el resto del Dashboard.

### Decisiones
- **No se ha inventado ningún dato que no exista**: la Economía de la app no tiene un "objetivo de ahorro" como estructura propia (solo saldo/hucha/movimientos) — el apartado 6 lo menciona como ejemplo, pero crear esa función sería alcance nuevo no pedido explícitamente; la tarjeta de Economía enlaza al módulo, no a un objetivo que no existe. Mismo criterio con Nutrición: la app evita deliberadamente objetivos calóricos estrictos desde la Fase 21 ("aconseja, no decide") — la tarjeta muestra los totales de hoy, nunca un "% de un objetivo" inventado.
- **El deep-link resalta y hace scroll, no abre una pantalla de detalle nueva**: ninguno de los módulos (Objetivos, Productividad) tenía una vista de "un solo elemento" antes de esta fase, y crearlas habría sido una reconstrucción, no una ampliación (apartado 23: "no quiero una reconstrucción completa"). Entreno y Estudios sí tienen un patrón de acordeón ya existente (`SkillCard`, `AsignaturaCard`/`ExamenItem`) — ahí el deep-link lo abre directamente, que es más fiel todavía al espíritu del apartado 6.
- **PIN y deep-link conviven sin caso especial**: si un módulo de destino está protegido y el `PinGate` todavía no está desbloqueado, el componiente de deep-link ni siquiera se monta (`PinGate` solo renderiza a sus hijos cuando `desbloqueado` es true) — el foco pendiente simplemente espera y se aplica en cuanto Josué mete el PIN, sin ningún código extra para este caso.
- **La corrección de compatibilidad de `personalizacion`, hecha a la vez**: `App.jsx` cargaba `personalizacion` sin fusionarla con su valor por defecto (a diferencia de notificaciones/historialColor/temaPersonalizado, que sí lo hacen) — un registro guardado antes de esta fase se habría quedado con `dashboardOcultos` en `undefined`. Corregido con el mismo patrón `{ ...DEFAULT_PERSONALIZACION, ...pers }` que ya usan los demás.
- **"Hoy" ahora puede necesitar algo de scroll** — dicho con honestidad, porque la fase anterior (Optimización de navegación y scroll) pedía justo lo contrario en las pantallas principales. Este pedido nuevo es explícito y describe su propia jerarquía de 3 niveles reconociendo que "más posibilidades" implica más contenido; el propio apartado 20 lo anticipa ("si hay demasiados módulos, prioriza, permite personalización, usa una sección Más") — se ha mantenido cada tarjeta lo más compacta posible (rejillas, mini-accesos de un renglón) para minimizar ese scroll, y `dashboardOcultos` deja la puerta abierta a que Josué recorte el Dashboard a lo que de verdad usa en cuanto exista el editor.

### Pendiente (documentado, no implementado en esta fase)
- **Editor real de qué módulos mostrar en el Dashboard** (apartado 10): el modelo de datos (`dashboardOcultos`) y el filtrado ya existen; falta la UI en Ajustes que lo rellene — mismo patrón exacto que "Pantalla principal" (Fase 19), se podría añadir como una categoría más sin tocar `DashboardView.jsx`.
- **No se ha podido comprobar en un iPhone real** ni renderizando la app en este entorno — todo lo hecho es lectura y edición de código. La densidad de las nuevas rejillas (2×2, 2×3, fila de acciones con scroll horizontal) se ha dimensionado a ojo siguiendo el mismo lenguaje visual ya usado en `ListCard`/`Card` desde fases anteriores, pero su aspecto real en una pantalla pequeña no se ha podido verificar visualmente.
- **Acciones rápidas limitadas a Sueño/Gasto/Tarea/Objetivo** — las cuatro con un formulario de alta ya existente, de un solo paso, sin ambigüedad sobre qué crear (a diferencia de, por ejemplo, "+ Entreno", que exigiría elegir antes una habilidad concreta de las 7 o un partido de fútbol) — ampliar esta fila a más módulos es una extensión directa del mismo patrón.
- No se ha podido verificar con `esbuild` en este entorno (sin acceso al registro de npm, `403`, mismo límite de siempre) — revisado a mano: balance de paréntesis/llaves/corchetes comprobado por script en los diez archivos tocados (OK), y cada prop nueva (`foco`, `onFocoConsumido`, `onNavegar`, `resumenes`, `dashboardOcultos`, etc.) cruzada uno a uno contra su punto de origen en `App.jsx` y su consumo en cada vista.

## Optimización de navegación y scroll — móvil (v1.19.0)

### Alcance de esta fase, dicho primero
Ajuste de UX/UI centrado en densidad y scroll, sin tocar el diseño visual, las animaciones ni la navegación existente, tal y como pedía explícitamente la especificación. Antes de cambiar nada se analizó el código real de las pantallas principales (Hoy/Sueño/Entreno/Economía), el selector de color y el resto de Ajustes, y la estructura de "Más" (HubView.jsx) — el hallazgo más importante fue un bug real de CSS, no solo una cuestión de gusto de maquetación (ver más abajo).

### El hallazgo: por qué el selector de color aparecía "abajo del todo"
`ColorPicker.jsx` y `TemaBuilder.jsx` ya estaban construidos como paneles flotantes (`position: fixed; inset: 0`, bottom-sheet) desde fases anteriores — en teoría ya eran "contextuales". El problema real es una trampa clásica de CSS: `.module-enter` (la animación de entrada de cada pantalla, `index.css`, apartado N1/N2) usa `animation-fill-mode: both`, que deja aplicado el `transform` del último fotograma (`scale(1) translateX(0)`) **para siempre** después de que la animación termina. Cualquier `transform` distinto de `none` — aunque sea "visualmente igual a nada" — convierte a ese `<div>` en el "containing block" de sus descendientes `position: fixed`. Como Ajustes (y el Calendario, y el escáner de código de barras de Nutrición) se renderizan dentro de `.module-enter`, cualquier modal `fixed inset-0` anidado ahí dejaba de anclarse al viewport real y pasaba a anclarse al tamaño de ESE contenedor — que en una pantalla larga de Ajustes es mucho más alto que la pantalla visible. Resultado: el selector "aparecía" técnicamente en el sitio correcto según su propio CSS, pero ese sitio estaba muy por debajo del contenido visible.

### Añadido / cambiado
- **Corrección de raíz (afecta a los 10 overlays `fixed inset-0` de toda la app, no solo al color):** `ColorPicker.jsx`, `TemaBuilder.jsx`, `BarcodeScanner.jsx`, los tres modales de `CalendarView.jsx` (editor de evento, detalle de solo lectura, buscador) y los cuatro modales de `components/ui.jsx` (`VerificacionPinModal`, `CrearPinModal`, `RecuperarPinModal`, `UniversalSearchModal`) ahora se montan con `createPortal(..., document.body)` de React — se sacan del árbol de `.module-enter` y se anclan siempre al viewport real, apareciendo superpuestos de inmediato junto al botón que los abre, nunca "al final de la página". Comentario explicativo añadido junto a `.module-enter` en `index.css` para que nadie reintroduzca este bug con un overlay nuevo en el futuro.
- `src/components/ui.jsx`: nuevos `ListCard`/`ListRow` — sustituyen al patrón repetido de "una `Card` suelta por cada fila de una lista" (registros de sueño, movimientos de economía, partidos, PRs), que sumaba bastante alto por el borde+padding+margen de cada tarjeta individual. Una única `Card` con las filas separadas por un borde fino interior: mismo contenido, mismo orden, bastante menos alto.
- `src/views/DashboardView.jsx`: el grupo de avisos condicionales (modo viaje, acceso al calendario, recordatorio de Relación, sueño corto, racha en riesgo, examen sin horas) pasa a un espaciado más apretado (`space-y-2`) con tarjetas de padding más compacto — mismo contenido, menos aire entre ellas cuando coinciden varias a la vez. Las métricas favoritas y las dos estadísticas fijas (sueño/saldo) se fusionan en una única rejilla de 2 columnas en vez de dos rejillas separadas.
- `src/views/SleepView.jsx`, `src/views/FinanceView.jsx`: las listas de registros recientes/movimientos pasan a `ListCard`/`ListRow`. En Economía, la tarjeta "Hucha" pasa a ser una fila dentro de la misma tarjeta de "Cuenta principal" en vez de una tarjeta aparte.
- `src/views/TrainingView.jsx`: las 7 habilidades de calistenia (Handstand/Front Lever/Back Lever/Planche/Human Flag/Muscle Up/L-Sit) pasan de una columna apilada a una rejilla de 2 columnas mientras están colegidas; la que se toca ocupa el ancho completo (`gridColumn: '1 / -1'`) para tener sitio de sobra para sus 4 subpestañas — mismo contenido y mismas acciones, mucho menos alto cuando ninguna está abierta. Partidos de fútbol y PRs también pasan a `ListCard`/`ListRow`.

### Decisiones
- **La causa real era un bug de CSS (containing block por `transform`), no una cuestión de diseño** — se ha corregido con `createPortal`, la solución estándar de React para este problema exacto, sin tocar la animación (`.module-enter`) que la causaba: el objetivo era arreglar el síntoma sin perder la animación de entrada que ya funcionaba bien.
- **"Más" (HubView.jsx) se ha dejado tal cual, sin comprimir**: la propia especificación distingue explícitamente un NIVEL 2 ("Más puede utilizar una estructura algo más amplia") de un NIVEL 1 (pantallas principales, donde sí hay que evitar scroll) — las tarjetas grandes de los hubs de área ya encajan en esa excepción explícita.
- **Ajustes sigue siendo una pantalla con scroll, tal y como pedía la propia especificación** (NIVEL 3) — el cambio ahí no ha sido "quitar el scroll", sino asegurar que los controles que se abren dentro (el color, sobre todo) aparezcan pegados a donde se pulsan en vez de al final del documento.
- **`ListCard`/`ListRow` son composición sobre `Card`, no un sistema visual nuevo**: mismo color de fondo, mismo borde, mismo radio — solo cambia cómo se agrupan varias filas, para no romper "conservar el estilo premium" pedido explícitamente.
- **Nada de contenido ni de funciones eliminado**: cada aviso, cada botón, cada campo de formulario sigue existiendo — el cambio es siempre de agrupación/densidad (tarjetas fusionadas, listas consolidadas, rejillas en vez de columnas), nunca de recorte de información, tal y como se pedía explícitamente ("si hay demasiados elementos, reorganiza, no simplifiques hasta hacerlo incómodo").

### Pendiente (documentado, no implementado en esta fase)
- No se ha podido comprobar en un iPhone real ni en ningún dispositivo real — todo el trabajo de esta fase es revisión y edición de código, sin poder renderizar la app en este entorno. El hallazgo del bug de `transform`/`containing block` es un mecanismo de CSS bien documentado y verificable leyendo la especificación, pero su efecto visual exacto (cuánto "más abajo" aparecía el selector antes del arreglo) no se ha podido medir en pantalla.
- Compactación más agresiva de otras vistas no mencionadas explícitamente en la especificación (Estudios, Negocio, Productividad, Objetivos, Diario, Biblioteca, Fe, Bienestar, Estadísticas, Predicciones, Logros) — fuera del alcance pedido ("Hoy/Sueño/Entreno/Economía y cualquier otra sección principal equivalente"); si Josué quiere el mismo tratamiento ahí, es una extensión directa del mismo patrón (`ListCard`/`ListRow`, rejillas en vez de columnas) ya aplicado aquí.
- La lista de vídeos de Entrenamiento (`VideosTab`) se ha dejado con tarjetas individuales (no `ListCard`) porque cada entrada tiene contenido más rico (checkbox de comparar, botones de analizar/borrar, feedback de la IA) que no se compacta limpiamente en una fila simple sin perder claridad — documentado aquí en vez de forzarlo.
- No se ha podido verificar con `esbuild` en este entorno (sin acceso al registro de npm, `403`, mismo límite de siempre) — revisado a mano: balance de paréntesis/llaves/corchetes comprobado por script en los nueve archivos tocados (OK), y cada uso de `createPortal`/`ListCard`/`ListRow` cruzado uno a uno contra su import y su export real.

## Seguridad Centralizada — PIN configurable por áreas y funciones, hasheado, con recuperación por correo (v1.18.0)

### Alcance de esta fase, dicho primero
Sustitución completa del sistema de PIN por uno centralizado, configurable y escalable, siguiendo la especificación de seguridad recibida punto por punto (14 apartados + recuperación de PIN añadida después). Se ha analizado primero cómo funcionaba el PIN existente (comparación en texto plano en `PinGate`/`PinSetter`, `personalizacion.pinExtra` como lista de zonas extra desconectada de `seguridad`, `'relacion'` protegida siempre por un caso especial fijo, `BloqueoAutomaticoGate` para el bloqueo automático de toda la app) antes de tocar nada, y se ha migrado sin pérdida de datos: quien ya tenía un PIN sigue teniéndolo, y quien ya tenía secciones protegidas las conserva.

### Añadido / cambiado
- `src/lib/pin.js` (nuevo): `crearPinHash(pin)`/`verificarPin(intento, pinHash, pinSalt)` — hash SHA-256 + salt aleatorio de 16 bytes por PIN, con la Web Crypto API nativa del navegador (`crypto.subtle`). El PIN ya no se guarda ni se compara nunca en texto plano.
- `src/tokens.js`: `DEFAULT_SEGURIDAD` gana `pinHash`/`pinSalt` (sustituyen a `ajustes.pin` en claro), `protectedAreas`/`protectedActions` (listas centralizadas de zonas y funciones protegidas), `sessionTimeoutMin` (sesión de desbloqueo temporal) y `migradoAreas`/`migradoAcciones` (banderas internas de la migración de una sola vez). Nuevo `ACCIONES_PROTEGIBLES` (catálogo de protección de función: `fotos_privadas`, `exportar_datos`, `eliminar_datos`) y `OPCIONES_SESION_PIN` (1/5/15/30 min o "pedir siempre").
- `src/lib/supabase.js`: `onAuthEvent(callback)` (suscripción aparte de `onAuthChange`, expone también el propio evento — se usa para detectar `PASSWORD_RECOVERY`) y `sendPasswordReset(email, redirectTo)` (envuelve `supabase.auth.resetPasswordForEmail`).
- `src/components/ui.jsx`: `PinSetter` (comparación en claro) eliminado; nuevos `EntradaPin` (input numérico único, reutilizado por las tres pantallas que piden un PIN), `PinGate` (ahora controlado: recibe `pinHash`/`pinSalt`/`desbloqueado`/`onDesbloquear`/`onOlvidoPin` en vez de un `pin` en claro y un `unlocked` local), `VerificacionPinModal` (modal de "confirma tu PIN" reutilizado por cualquier acción sensible), `CrearPinModal` (crear/cambiar PIN en dos pasos: nuevo → confirmar) y `RecuperarPinModal` ("¿No recuerdas tu PIN?").
- `src/App.jsx`: es ahora el único sitio que decide y guarda el estado de protección (apartado 8/9 de la especificación):
  - Migración de carga: si existía `ajustes.pin` en claro, se hashea una sola vez y se descarta (`pin: null` a partir de ahí, para siempre); si existían secciones en `personalizacion.pinExtra`, se vuelcan una sola vez en `seguridad.protectedAreas` (banderas `migradoAreas`/`migradoAcciones` evitan que un futuro `pinExtra` obsoleto "resucite" algo que Josué ya desprotegió a mano); `fotos_privadas` se activa sola en `protectedActions` porque `HealthView` ya protegía esa pestaña siempre, sin opción, antes de esta fase.
  - `pedirVerificacionPin(motivo, onExito)`: único punto por el que pasan cambiar el PIN, desactivarlo, o quitar protección a una sección/función — pide el PIN actual antes de ejecutar `onExito`; añadir protección nunca lo pide.
  - `toggleAreaProtegida`/`toggleAccionProtegida`: único sitio que toca `protectedAreas`/`protectedActions`, usado tanto por la nueva lista de Seguridad como por el candado ya existente de Personalización.
  - `desbloqueosPin` (mapa en memoria `clave → timestamp`, nunca en Supabase): sesión temporal de desbloqueo (apartado 6) — `registrarDesbloqueo`/`estaDesbloqueado`, con `seguridad.sessionTimeoutMin` configurable; se limpia entero en cuanto salta el bloqueo automático ya existente (apartado 7: integrado con `BloqueoAutomaticoGate`, no duplicado) y se pierde solo al recargar la app (no vive en Supabase).
  - `AREAS_PROTEGIBLES` = `MORE_NAV` (catálogo ya existente de todos los módulos) + `'hoy'` — cualquier módulo futuro que se añada a `MORE_NAV` aparece solo en la lista de "Protección mediante PIN", sin tocar este archivo (apartado 1).
  - Recuperación de PIN: `enviarRecuperacionPin`/`guardarPinTrasFlujo`, más un `useEffect` que escucha `onAuthEvent` para detectar `PASSWORD_RECOVERY` y abrir `CrearPinModal` en modo `'recuperacion'`.
- `src/views/SettingsView.jsx` (categoría Seguridad, reescrita): tarjeta de PIN (estado, crear/cambiar/desactivar — los dos últimos abren el flujo de verificación centralizado), tarjeta **"Protección mediante PIN"** (una fila por cada entrada de `areasProtegibles`, con interruptor — 'Relación' sigue fija, sin poder quitarla), tarjeta **"Protección de funciones"** (una fila por `ACCIONES_PROTEGIBLES`), tarjeta **"Sesión de desbloqueo"** (`OPCIONES_SESION_PIN`), biometría y bloqueo automático sin cambios de comportamiento (solo comprobando `seguridad.pinHash` en vez de un `pin` en claro). "Exportar datos" y "Eliminar datos por categoría" pasan por verificación de PIN si `protectedActions` las tiene activadas (wrappers en `App.jsx`).
- `src/views/HealthView.jsx`: "Ver fotos privadas" pasa de protección fija a protección de función real (`protegidoFotos`), primer caso de verdad de "protección por función, no solo por pantalla" (apartado 2).
- `src/views/PersonalizationView.jsx`: el candado por módulo (`FilaModulo`) lee y escribe ahora `seguridad.protectedAreas` (prop `protectedAreas`) en vez de `personalizacion.pinExtra` — mismo control visual de siempre, pero conectado al único sistema centralizado.

### Decisiones
- **Un único sistema, no una capa nueva por encima de la vieja**: no existen ya dos formas de proteger una sección (`personalizacion.pinExtra` y `seguridad`) — la vieja se migra y se abandona; el candado de Personalización y la lista de Seguridad llaman literalmente a las mismas dos funciones de `App.jsx`.
- **Hashing con SHA-256 + salt, no bcrypt/argon2/scrypt**: sin acceso a npm en este entorno no hay forma de instalar una librería de hash lento pensada para contraseñas. SHA-256 simple es rápido, así que esta mejora no es resistente a fuerza bruta si alguien consiguiera una copia directa de la fila de Supabase — pero ya no es texto plano legible a simple vista, que es la mejora real y honesta que se podía dar aquí sin backend propio. El salt por usuario sí evita tablas precalculadas entre cuentas. Documentado también en los comentarios de `src/lib/pin.js`.
- **Reducir protección siempre pide el PIN actual; añadirla nunca lo pide**: leído literalmente del apartado 3 ("especialmente cuando la modificación reduzca la protección") — subir la seguridad de una sección no es una acción de riesgo que necesite fricción.
- **La sección de Seguridad no tiene un candado de entrada propio distinto del resto de Ajustes**: `SettingsView.jsx` es una única pantalla con categorías internas (Perfil/Apariencia/Seguridad/Datos/...), no rutas independientes — proteger "Ajustes" como área (ya disponible en la lista) protege también la entrada a Seguridad. Lo que sí es un mínimo obligatorio, independiente de eso, son las tres acciones críticas del apartado 3 (cambiar PIN, desactivarlo, reducir protección), que siempre piden el PIN actual pase lo que pase con la protección de área — es la garantía real que pedía el apartado 4, no un candado de pantalla adicional.
- **Protección de función parcialmente cableada, arquitectura lista para el resto**: el apartado 2 no exige implementar toda la granularidad ahora, solo que el sistema esté preparado. `protectedActions` + `ACCIONES_PROTEGIBLES` son genéricos: añadir una acción nueva del catálogo (ver Pendiente) es añadir una entrada al array y un `if (protegido) pedirVerificacionPin(...)` en el punto exacto donde ya ocurre esa acción — sin rediseñar nada. Se han cableado de verdad las tres más baratas y con más sentido inmediato: `fotos_privadas` (migrada del comportamiento fijo anterior, sin regresión), `exportar_datos` y `eliminar_datos`.
- **Sesión de desbloqueo en memoria, nunca en Supabase**: así "cerrar/reabrir la app" (comprobación 8) la reinicia sola, sin lógica extra — persistirla habría exigido además una fecha de expiración server-side para que tuviera sentido de verdad como medida de seguridad, y hoy no hay servidor propio más allá del proxy de IA.
- **Recuperación de PIN vía `resetPasswordForEmail` de Supabase, nunca solo con el correo escrito**: el enlace solo llega a quien tiene acceso real a esa bandeja de entrada; hasta que Supabase no dispara el evento `PASSWORD_RECOVERY` (al abrir ese enlace desde el propio dispositivo) no se deja crear un PIN nuevo. En ningún momento se pide ni se guarda la contraseña de la cuenta de correo — ni siquiera se toca la contraseña de la cuenta de Supabase, el enlace de recuperación se usa puramente como verificación de identidad.
- **Migración de una sola vez, con banderas explícitas** (`migradoAreas`/`migradoAcciones`): sin ellas, cada carga volvería a fusionar `personalizacion.pinExtra` (que ya no se escribe, pero puede seguir teniendo datos antiguos) contra `protectedAreas`, "resucitando" secciones que Josué hubiera desprotegido a mano después de la migración — un bug real de haberlo hecho sin la bandera.

### Comprobaciones (verificadas a mano, revisando el código — ver Pendiente)
1. PIN activado + Economía protegida → entrar en Economía → pide PIN. ✓ (`necesitaPin` en `App.jsx`: `!!seguridad.pinHash && areaProtegida && !estaDesbloqueado(...)`)
2. PIN activado + Economía NO protegida → entrar en Economía → no pide PIN. ✓ (`areaProtegida` es `false` si no está en `protectedAreas`)
3. Cambiar el PIN → pide PIN actual. ✓ (`iniciarCambioPin` → `pedirVerificacionPin`)
4. Desactivar el PIN → pide PIN actual. ✓ (`iniciarDesactivarPin` → `pedirVerificacionPin`)
5. Quitar la protección de una sección → pide PIN actual. ✓ (`toggleAreaProtegida`/`toggleAccionProtegida`, rama "ya estaba protegida")
6. PIN incorrecto → no accede. ✓ (`verificarPin` devuelve `false`, no se llama a `onDesbloquear`/`onSuccess`)
7. PIN correcto → accede. ✓
8. Cerrar/reabrir la app → la protección sigue activa. ✓ (`protectedAreas`/`protectedActions`/`pinHash` viven en Supabase; `desbloqueosPin` vive solo en memoria, así que además vuelve a pedir el PIN de las sesiones temporales que hubiera abiertas)
9. Si ya existía un PIN, sigue funcionando. ✓ (migración: se hashea el mismo valor que Josué ya conocía)
10. No se puede saltar la protección por navegación/URL/estado interno. ✓ dentro de los límites de una SPA sin backend propio: no hay enrutado por URL en la app (`tab` es estado de React, no hay `react-router` ni lectura de `location`), y `PinGate` envuelve el único punto de la app donde se renderiza el contenido de una pestaña (`renderTab`) — no existe una segunda vía de render. Límite honesto, ya documentado en `src/lib/biometria.js` para el sistema anterior: alguien con acceso a las herramientas de desarrollador del propio navegador podría, en teoría, manipular el estado de React directamente — el mismo límite que tenía el PIN en claro y la biometría local, inherente a no tener servidor de autorización propio.

### Pendiente (documentado, no implementado en esta fase)
- Granularidad completa del catálogo de protección de función del apartado 2 (modificar datos sensibles, restaurar copia de seguridad — no existe todavía como función real —, cambiar configuraciones de seguridad más allá de lo ya obligatorio, acceder a información financiera como acción aparte del área Economía/Negocio, acceder a contenido privado como acción aparte de las áreas ya protegibles). El modelo de datos y el patrón de cableado ya están listos; solo falta añadir entradas al catálogo y el `if` correspondiente en cada punto real.
- "Seguridad" como sub-zona de "Ajustes" con candado propio, independiente del resto de categorías de Ajustes — no implementado porque `SettingsView.jsx` es una única pantalla con categorías internas, no rutas separadas (ver Decisiones); las tres acciones críticas siguen protegidas siempre, con o sin esto.
- Auditoría de eventos de seguridad, lista de dispositivos autorizados, sesiones activas en otros dispositivos — necesitan permisos de administrador de Supabase gestionados desde un servidor, mismo límite ya documentado en fases anteriores de esta categoría.
- No se ha podido verificar con `esbuild` en este entorno (sin acceso al registro de npm, `403`, mismo límite de siempre) — revisado a mano: balance de paréntesis/llaves/corchetes comprobado por script en los ocho archivos tocados (OK), imports cruzados uno a uno contra las firmas reales exportadas por `components/ui.jsx`, `lib/pin.js`, `lib/supabase.js` y `tokens.js`, y las diez comprobaciones obligatorias de la especificación trazadas a mano sobre el código (ver más arriba). Pendiente que la siguiente IA o Josué en ejecución real confirmen sobre todo dos cosas que no se pueden probar sin ejecutar la app de verdad: que el enlace de recuperación de Supabase, tal y como está configurado el proyecto (`redirectTo`, plantilla de correo), efectivamente devuelve al usuario a la app con el evento `PASSWORD_RECOVERY` disparándose; y que la migración de un PIN antiguo en claro se ve reflejada correctamente en Supabase (campo `pin` a `null`, `seguridad.pinHash`/`pinSalt` rellenos) la primera vez que un usuario con PIN previo abre esta versión.

## Fase 3 del Calendario Universal, primera pasada — Recurrencia, Agenda, filtros y búsqueda (v1.17.0)

### Alcance de esta pasada, dicho primero
Fase 3 del prompt del Calendario es una lista abierta ("incluirá potencialmente...", sin criterio de finalización como sí tenía la Fase 1). En vez de intentarlo todo de golpe, esta pasada se centra en el bloque más pedido y más útil sin datos: **recurrencia real, vista Agenda, filtros por tipo y búsqueda**. Quedan fuera de esta pasada, documentado sin rodeos: estadísticas temporales del calendario, automatizaciones/"eventos inteligentes" (sin especificación concreta, mismo criterio de cautela que con AXION — no prometer IA sin saber qué haría de verdad), integración más profunda con "Hoy" (el acceso discreto ya existente se deja tal cual, por no volverlo invasivo), vista de día independiente (la Agenda ya cubre ese caso de uso) y personalización avanzada del propio calendario.

### Añadido / cambiado
- `src/tokens.js`: `FRECUENCIAS_RECURRENCIA` (diaria/semanal/mensual/anual).
- `src/lib/calendario.js`: `expandirRecurrentes(eventos, desdeISO, hastaISO)` — genera las ocurrencias VIRTUALES de un evento recurrente dentro de una ventana, sin guardar ni duplicar nada (mismo espíritu que los eventos derivados de la Fase 2: se recalcula siempre, acotado a la ventana que pide quien llama). Atajo de aritmética exacta para diaria/semanal cuando el ancla del evento queda muy por detrás de la ventana pedida, para no agotar el tope de seguridad de 500 pasos con eventos antiguos vistos mucho después.
- `src/views/CalendarView.jsx`: reescrita para Fase 3 —
  - **Recurrencia**: nuevo campo "Repetir" en el editor (No se repite/Cada día/semana/mes/año) + "Repetir hasta" opcional. Tocar cualquier ocurrencia de un evento recurrente (incluida una generada, no solo el día ancla) abre/edita siempre el evento REAL completo — no hay edición de una ocurrencia suelta en esta pasada, avisado en el propio editor ("cambia toda la serie").
  - **Vista Agenda**: alternativa a la cuadrícula mensual (toggle Mes/Agenda) — lista cronológica agrupada por día, próximos 60 días, tope de 50 eventos renderizados con aviso si se trunca.
  - **Filtros por tipo**: fila de chips (uno por cada uno de los 8 tipos, coloreado con su token semántico) para mostrar/ocultar categorías — afecta a la cuadrícula, el panel de día, "Próximamente", la Agenda y la búsqueda por igual.
  - **Búsqueda**: modal con texto libre sobre título/notas, ventana de -60/+180 días, resultados tocables que saltan directo al evento.
  - `FilaEvento` (nuevo componente compartido): mismo aspecto para el panel de día y la Agenda, con icono de candado (solo lectura) y de repetición cuando corresponde.

### Decisiones
- **Recurrencia sin intervalo personalizado ni excepciones**: "cada 2 semanas" o "saltar este día concreto sin romper la serie" quedan fuera — la primera pasada cubre el caso de uso mayoritario (diaria/semanal/mensual/anual, con o sin fecha de fin) sin la complejidad de un motor de reglas tipo iCalendar.
- **Nunca se materializan ocurrencias en Supabase**: siguen viviendo como una única fila con una regla — coherente con el mismo principio ya aplicado a los eventos derivados de otros módulos (Fase 2) y con el criterio general del proyecto de no duplicar datos.
- **Automatizaciones/"eventos inteligentes" explícitamente no abordados**: el prompt los menciona sin definir qué deberían hacer — construir algo ahí sin una especificación real sería inventar alcance, lo mismo que ya se evitó con AXION.

### Pendiente (documentado, no implementado en esta fase)
- Intervalo personalizado y excepciones de recurrencia ("cada 2 semanas", saltar un día concreto).
- Estadísticas temporales del calendario, automatizaciones/eventos inteligentes, integración más profunda con "Hoy", personalización avanzada del calendario — siguen abiertas dentro de la Fase 3, sin fecha.
- Fechas importantes de Relación, con PIN — sigue sin abordar (ver Fase 2).
- No se ha podido verificar con `esbuild` en este entorno (sin acceso al registro de npm, `403`) — revisado a mano: balance de paréntesis/llaves/corchetes comprobado por script en los tres archivos tocados (OK), y la lógica de `expandirRecurrentes` verificada a mano con casos de prueba (evento diario/semanal con ancla antigua, evento mensual/anual, evento sin recurrencia) trazando el bucle sobre papel. Pendiente que la siguiente IA o Josué en ejecución real confirmen que editar/eliminar una serie recurrente se comporta como se espera, y que la vista Agenda no se sienta pesada con datos reales en un iPhone.

## Fase 2 del Calendario Universal — Calendario inteligente e integración (v1.16.0)

### Añadido / cambiado
- `src/lib/calendarioIntegracion.js` (nuevo): `eventosDerivados({ objetivos, estudios, calistenia, futbol, productividad })` — calcula, en cada render, eventos de **solo lectura** a partir de otros módulos, sin guardar ni duplicar nada:
  - **Objetivos**: los no cumplidos con plazo estimable (`prediccionObjetivo`, Fase 17) → tipo `objetivo`, fecha = plazo estimado (dicho explícitamente en las notas del evento, nunca presentado como una fecha exacta que Josué haya escrito).
  - **Estudios**: exámenes (fecha real) → tipo `estudio`.
  - **Entrenamiento**: sesiones de calistenia por habilidad + partidos de fútbol (ambos con fecha real ya registrada) → tipo `entrenamiento`.
  - **Productividad**: tareas pendientes con fecha límite → tipo `recordatorio` (el dato de ese módulo más cercano en espíritu a "recordatorio con fecha propia" — ver Decisiones).
  - `NOMBRES_ORIGEN`: nombre legible de cada módulo de origen, para el botón "Abrir en…" del detalle de un evento derivado.
- `src/views/CalendarView.jsx`: ahora fusiona `calendario.eventos` (propios, editables) con la nueva prop `derivados` (solo lectura) — el motor de `calendario.js` (celdas, eventos del día, resumen, futuros) trabaja igual sobre la lista combinada, sin ningún cambio, porque nunca distinguió origen. Los eventos derivados muestran un icono de candado y, al tocarlos, abren `DetalleEventoDerivado` (nuevo componente) en vez del editor — solo lectura, con botón "Abrir en {módulo}" que navega al módulo de origen real. Nuevo panel **"Próximamente"**: hasta 5 días con algo programado en las próximas ~2 semanas ("Hoy", "Mañana", día de la semana…), cada fila tocable para saltar directo a ese día.
- `src/App.jsx`: `derivadosCalendario` calculado una vez por render (mismo criterio barato que `resumenesTodos`/`metricasCalculadas`), pasado a `CalendarView` (`derivados`) y a `DashboardView` (`derivadosCalendario`); `onAbrirModulo={setTab}` conecta el botón "Abrir en…" del detalle de solo lectura con la navegación real de la app.
- `src/views/DashboardView.jsx`: `AccesoCalendario` fusiona ahora `calendario.eventos` + `derivadosCalendario` antes de calcular el resumen de hoy — un examen o partido de hoy aparece en el acceso discreto de "Hoy" igual que un evento creado a mano.
- `src/lib/resumenesHub.js`: el caso `'calendario'` fusiona `eventosDerivados(s)` con los eventos propios antes de calcular el resumen de la tarjeta del hub "Vida".

### Decisiones
- **Sin duplicar datos, por construcción**: los eventos derivados se calculan de nuevo en cada render a partir del estado real de cada módulo — nunca se copian a `calendario.eventos`. Esto resuelve gratis dos puntos del prompt: "evitar duplicados" (no existe una segunda copia que pueda desincronizarse) y "si modificas algo desde su módulo, se actualiza el calendario" (se recalcula solo, sin código de sincronización).
- **⚠️ Fechas importantes de Relación — excluidas a propósito, por privacidad, no implementado igual que el resto:** el prompt del Calendario pide explícitamente integrar "fechas importantes", pero Relación es el único módulo protegido por PIN de principio a fin en toda la app (ver `HANDOFF.md`, `currentState`/`exportData` en `App.jsx`, que ya la excluían por el mismo motivo). El Calendario, tal y como está construido, **no pide PIN para abrirse** — traer esas fechas aquí habría sido una regresión de privacidad real (cualquiera que abriera el calendario vería el nombre de la pareja y sus fechas sin PIN). Se ha dejado fuera. Si Josué quiere verlas igualmente, la vía honesta es una fase futura que proteja específicamente esas entradas con el mismo `PinGate` — no mezclarlas sin más.
- **Hábitos y Rutinas — no integrados, documentado sin rodeos:** también pedidos explícitamente por el prompt, pero ninguno de los dos tiene una fecha ni periodicidad propia en el modelo de datos real (un hábito es `historial: {fecha: true}`, marcas de cuándo SE HIZO, no de cuándo TOCA; una rutina no tiene fecha en absoluto). Integrarlos de verdad exige un motor de recurrencia real (repetir cada día/semana/mes), que es trabajo explícito de Fase 3 ("eventos recurrentes avanzados") — inventarles una fecha ahora habría sido simular algo que no existe. En su lugar se han integrado las **Tareas** de Productividad (sí tienen `fechaLimite` real), el dato de ese módulo más cercano en espíritu a lo que pedía el prompt.
- **Recordatorios**: no son un módulo aparte en la app — ya estaban cubiertos desde la Fase 1 (Josué los crea directamente en el calendario, tipo "Recordatorio").
- **Eventos de solo lectura, nunca editables desde el calendario**: el dato real vive en su módulo de origen; el calendario solo lo muestra y enlaza de vuelta ("Abrir en {módulo}"), nunca permite editar/eliminar ahí — evita una segunda fuente de verdad para el mismo dato.

### Pendiente (documentado, no implementado en esta fase)
- Fase 3 — experiencia premium: vista agenda/día, filtros, búsqueda, eventos recurrentes reales (incluidos Hábitos/Rutinas, ver Decisiones), estadísticas temporales, integración profunda con "Hoy", automatizaciones.
- Fechas importantes de Relación, con PIN — no abordado, ver Decisiones.
- No se ha podido verificar con `esbuild` en este entorno (sin acceso al registro de npm, `403`) — revisado a mano: balance de paréntesis/llaves/corchetes comprobado por script en los ocho archivos tocados (OK), imports cruzados uno a uno contra las firmas reales de `predicciones.js`, `components/ui.jsx` y `lib/helpers.js`, y los ids de los eventos derivados (`origen:origenId`) verificados a mano para que no colisionen con los `uid()` aleatorios de los eventos propios. Pendiente que la siguiente IA o Josué en ejecución real confirmen que "Abrir en {módulo}" navega bien desde dentro del calendario, y que el panel "Próximamente" no se sienta sobrecargado en un iPhone real.

## Fase 1 del Calendario Universal — Motor y calendario base (v1.15.0)

### Añadido / cambiado
- `src/tokens.js`: `DEFAULT_CALENDARIO` (`{ eventos: [] }`), `TIPOS_EVENTO_CALENDARIO` (8 tipos: objetivo/hábito/rutina/estudio/entrenamiento/fecha importante/recordatorio/personal, cada uno con un `colorToken` en vez de un hex fijo) y `colorDeTipoEvento(tipoId, accent)`, que resuelve el color en cada render contra `COLORS`/el acento activo — nunca un color guardado por evento, para que un evento "Entrenamiento" siga siendo dorado/warning aunque Josué cambie de tema o de acento después de crearlo.
- `src/lib/calendario.js` (nuevo): motor puro de fechas, mismo espíritu que `colorEngine.js`/`predicciones.js` — `diasDelMes`/`primerDiaSemanaMes`/`celdasMes` (cuadrícula mensual con años bisiestos resueltos por `Date` nativo, semana empezando en lunes), `eventosDelDia`, `tiposDelDia` (para los indicadores de punto de la cuadrícula, máximo 3 por día), `resumenDelDia` (resumen contextual tipo "3 eventos · 2 hábitos · 1 objetivo") y `eventosFuturos` (preparado para la Fase 2 — "Próximamente" —, escrito pero sin usar todavía en ninguna vista).
- `src/views/CalendarView.jsx` (nuevo): vista principal del calendario — cabecera con mes/año y navegación (mes anterior/siguiente/volver a hoy), cuadrícula mensual con el día actual y el seleccionado distinguidos por forma+color a la vez (nunca solo color, por accesibilidad) y puntos de color por tipo de evento presente, panel de día seleccionado con resumen contextual y lista de eventos (icono por tipo, hora o "Todo el día", ubicación si la tiene), editor modal único para crear y editar (título/tipo/fecha/interruptor "todo el día"/hora inicio-fin/notas/ubicación) con eliminar — mismo patrón visual que el buscador universal de la Fase 18.
- `src/App.jsx`: nuevo estado `calendario` (clave de Supabase propia, cargada con merge contra `DEFAULT_CALENDARIO` — mismo motivo que `temasGuardados`, por si la clave no existe todavía para un usuario ya registrado). `addEvento`/`updateEvento`/`deleteEvento` pasan por `snapshotAndSave`, igual que Objetivos/Diario — incluido en el snapshot y en `undo()`, en `RESET_MODULOS` (Ajustes → Privacidad) y en `currentState` (buscador universal, panel de sugerencias de IA, exportación). Nuevo módulo `calendario` en `MORE_NAV` y primero en `AREAS_NAV.area-vida` (junto a Estudios/Productividad/Objetivos/Diario/Biblioteca) — sin tocar la barra inferior de 5 pestañas, tal y como exige el propio prompt del Calendario ("nunca añadir una sexta pestaña").
- `src/views/DashboardView.jsx`: `AccesoCalendario`, acceso secundario discreto de una sola línea desde "Hoy" con el resumen de eventos de hoy (o una invitación breve si no hay nada) — abre el calendario vía `onAbrirCalendario` (`setTab('calendario')` en App.jsx), sin duplicar lógica de fechas propia.
- `src/lib/resumenesHub.js`: nuevo caso `'calendario'` para la tarjeta del hub "Vida" — resumen de hoy (`resumenDelDia`) y cuántos eventos hay en los próximos 7 días (`eventosFuturos`).
- `src/lib/exportData.js`: nueva sección "Calendario" en la exportación CSV/Excel, solo eventos con `origen: 'calendario'` — para no duplicar en el futuro lo que ya exporte cada módulo de origen cuando la Fase 2 conecte otros módulos.
- `src/index.css`: dos animaciones discretas nuevas (`calendarMonthIn` al cambiar de mes, `calendarSheetIn` al abrir el editor) reutilizando `--ease-premium` ya existente (Fase N1/N2) — ninguna curva de movimiento nueva, y respetan "Reducir movimiento"/"Desactivadas" automáticamente gracias a las reglas globales ya existentes en el archivo.

### Decisiones
- **Arquitectura preparada para Fase 2/3, sin implementarlas todavía** (regla explícita del prompt del Calendario: "en esta entrega solo debes implementar la Fase 1"). Cada evento lleva `origen`/`origenId` (hoy siempre `'calendario'`) y campos reservados sin lógica (`recurrencia`, `estado`) para que una fase futura pueda inyectar eventos de solo lectura desde Objetivos/Hábitos/Rutinas/Estudios/Entrenamiento/Fechas importantes sin duplicar el dato ni rehacer este modelo.
- **Sin sistema de color paralelo**: los 8 tipos de evento reutilizan los roles ya existentes del Theme Engine (`positive`/`warning`/`negative`/`info`/`secondary`/`tertiary`/acento/`textMuted`) — cero hex hardcodeado en `CalendarView.jsx` ni en `tokens.js`.
- **Sin almacenamiento paralelo**: reutiliza la misma tabla genérica `app_data` de Supabase (clave `'calendario'`) que ya usa el resto de la app — no hizo falta tocar `supabase/schema.sql`.
- **Celdas vacías en vez de días de otro mes**: el hueco antes del día 1 se deja en blanco (sin número, no interactivo) en vez de mostrar días de otro mes sin poder navegar a ellos — más simple y sin ambigüedad para esta fase.

### Pendiente (documentado, no implementado en esta fase)
- Fase 2 — Calendario Universal: integración real con Objetivos/Hábitos/Rutinas/Entrenamiento/Estudios/Recordatorios/Fechas importantes, "Próximamente", evitar duplicados, poder abrir el elemento original desde el calendario.
- Fase 3 — experiencia premium: vista agenda/día, filtros, búsqueda, eventos recurrentes reales, estadísticas temporales, integración profunda con "Hoy".
- No se ha podido verificar con `esbuild` en este entorno (sin acceso al registro de npm, `403` — mismo límite documentado en casi todas las fases anteriores) — revisado a mano: balance de paréntesis/llaves/corchetes comprobado por script en los siete archivos tocados (OK), e imports cruzados uno a uno contra las firmas reales de `components/ui.jsx`, `tokens.js` y `lib/helpers.js`. Pendiente que la siguiente IA o Josué en ejecución real confirmen que el calendario abre bien desde el hub "Vida", que crear/editar/eliminar un evento persiste correctamente, y que la cuadrícula se ve bien en un iPhone real (indicadores de punto y tamaño de celdas dimensionados a ojo, sin poder renderizar).

## Fase 4 del Sistema de Personalización Visual Extrema — Presets + gestión de temas (v1.14.0)

### Añadido / cambiado
- `src/tokens.js`: `PALETAS_PREDEFINIDAS` (Fase A7) gana un campo `temaPersonalizado` por entrada (`null` = totalmente automático, igual que se comportaban desde siempre) y tres presets nuevos con overrides reales — **Monocromático** (secundario/terciario grises, no derivados por rotación de tono), **Neón** (fondo/superficie casi negros para que el acento resalte) y **Pastel** (tema claro, fondo casi blanco con un toque de color). `clasico` (el azul metálico original) gana `esOficial: true`. Nuevos `DEFAULT_TEMAS_GUARDADOS` (`[]`) y `MAX_TEMAS_GUARDADOS` (12) para los temas propios de Josué. `DEFAULT_APARIENCIA` gana `modoColorAvanzado` (`false` por defecto).
- `src/App.jsx`: nuevo estado `temasGuardados`, clave de Supabase propia (`'temasGuardados'`), guardado directo sin deshacer. Nueva función `aplicarConjuntoTema({ tema, accent, temaPersonalizado })` — construye el payload de `'ajustes'` con los valores nuevos explícitos en vez de encadenar `updateAccent`+`updateApariencia` (ver Decisiones). `restablecerTemaOficial`, `guardarTemaComoNuevo`, `renombrarTemaGuardado`, `duplicarTemaGuardado`, `eliminarTemaGuardado`, `importarTemaGuardado` (todas con el límite de `MAX_TEMAS_GUARDADOS`, devuelven `false` sin borrar nada si ya está lleno).
- `src/components/GestionTemas.jsx` (nuevo): galería de temas predefinidos (tocar y aplicar, siempre visible), interruptor "Modo avanzado de color", y — solo con el modo avanzado activado — gestión completa de temas propios: guardar el estado actual con nombre, renombrar (tocar el nombre), duplicar, eliminar (con confirmación inline), exportar a `.json`, importar desde `.json` (con validación de formato antes de aceptar), y restablecer el tema oficial en un toque.
- `src/views/SettingsView.jsx`: `<GestionTemas />` integrado en Apariencia, justo debajo de "Color de acento". La tarjeta "Constructor de temas" (Fase 3) ahora solo se muestra si `apariencia.modoColorAvanzado` está activo. Actualizada la nota de "pendiente" de esta categoría: "paletas de color predefinidas completas" ya no está pendiente.

### Decisiones
- **`aplicarConjuntoTema` nunca encadena `updateAccent` + `updateApariencia`.** Ambas guardan el paquete `'ajustes'` completo leyendo el resto de campos del closure de React (patrón ya establecido desde la Fase A3/A5) — llamarlas dos veces seguidas en la misma función no vería el `setState` de la primera todavía (React no re-renderiza a mitad de una función), así que la segunda pisaría a la primera con un accent desactualizado. `aplicarConjuntoTema` construye el payload a mano con los valores nuevos explícitos, así que ese problema no puede pasar — es la única función de todo el sistema de color que cambia tema+accent+temaPersonalizado a la vez.
- **Comparación de "preset activo" deliberadamente aproximada** (`accent === p.accent && apariencia.tema === p.tema`, sin comparar `temaPersonalizado` campo a campo) — mismo criterio que ya usaba la galería de 12 acentos desde la Fase 1: sirve para resaltar visualmente "esto es lo que tienes ahora", no para una igualdad estricta que nadie necesita.
- **Los presets nuevos (Monocromático/Neón/Pastel) traen overrides reales, no solo un acento distinto** — un preset que solo cambiara el acento sería indistinguible en espíritu de tocar un swatch de la galería ya existente; el objetivo del apartado 10 del contexto maestro ("presets adicionales") es ofrecer estilos realmente distintos entre sí.
- **Duplicar/guardar/importar respetan el límite de `MAX_TEMAS_GUARDADOS` (12) rechazando la operación, nunca borrando el más antiguo en silencio** — a diferencia de `historialColor` (recientes/favoritos, Fase 2), donde perder el más antiguo es intrascendente, un tema guardado tiene nombre y significado para Josué; borrar uno sin avisar sería una pérdida de datos real.
- **Importar un tema lo añade a la lista, nunca lo aplica directamente** — mismo criterio que "Importar apariencia" (Fase A3): Josué decide activarlo después de verlo en la lista, en vez de que un archivo aplique cambios visuales de golpe sin confirmación.
- **El modo avanzado vive en `apariencia.modoColorAvanzado`, controla dos tarjetas a la vez** (gestión de temas propios dentro de `GestionTemas.jsx`, y la visibilidad completa de la tarjeta "Constructor de temas" en `SettingsView.jsx`) — un único interruptor, un único lugar de verdad, en vez de que cada tarjeta tenga su propio "modo avanzado" independiente y puedan quedar desincronizadas.
- **Colores de los tres presets nuevos elegidos a mano, no generados por una fórmula** — igual que el resto de `ACCENTS`/`PALETAS_PREDEFINIDAS` ya existentes, son curación manual para que cada preset tenga personalidad propia, no una interpolación matemática que podría dar resultados grises o poco atractivos.

### Verificado en este entorno
- Balance de paréntesis/llaves/corchetes por script en los siete archivos tocados (`tokens.js`, `App.jsx`, `SettingsView.jsx`, `GestionTemas.jsx`, `TemaBuilder.jsx`, `ColorPicker.jsx`, `ui.jsx`) — todos OK.
- **Verificación real con Node** de las 10 paletas predefinidas (7 ya existentes desde la Fase A7 + las 3 nuevas) a través de `aplicarTema()` completo: todas dan campos base/secundario/terciario con hex válido y contraste texto/fondo ≥4.5:1 y textMuted/fondo ≥3:1; confirmado que hay exactamente un preset `esOficial` y que es `'clasico'`; confirmado que los overrides explícitos de Monocromático/Neón/Pastel (fondo, superficie, secundario, terciario) se aplican tal cual, no se sobrescriben. Simulada la lógica de límite de `MAX_TEMAS_GUARDADOS` de forma aislada: bloquea exactamente en el tope, sin descartar nada existente.
- Re-ejecutados también los tests de la Fase 3 (contraste en casos límite, overrides manuales, rotación automática, estados) contra el `tokens.js` actualizado — siguen pasando sin cambios, confirmando que añadir Fase 4 no rompió nada de la Fase 3.
- **Pendiente de confirmación real**: exportar/importar un tema (descarga/subida de archivo `.json` real) solo se puede probar de verdad en el navegador — el código sigue el mismo patrón ya usado y confirmado en "Exportar/Importar apariencia" (Fase A3), pero conviene que Josué lo pruebe una vez.

## Fase 3 del Sistema de Personalización Visual Extrema — Constructor de temas (v1.13.0)

### Añadido / cambiado
- `src/lib/colorEngine.js`: nueva función `rotateHue(hex, degrees)` — rotación de tono en HSV, usada para derivar Secundario (+35°) y Terciario (−35°) del Principal por esquema análogo cuando Josué no los fija a mano.
- `src/tokens.js`: `DEFAULT_TEMA_PERSONALIZADO` (`{ secundario, terciario, fondo, superficie, texto, bordes, estados: { positive, warning, negative, info } }`, todo `null` = automático). `aplicarTema()` gana un cuarto parámetro, `temaPersonalizado`: deriva Secundario/Terciario (auto o a mano, con su propia escala de 11 pasos y su propio texto legible encima, igual que el acento desde la Fase 1), aplica overrides de Fondo/Superficie/Texto/Bordes, aplica overrides de Estados si los hay, y — como última operación, siempre — recalcula `text`/`textMuted` con `ensureContrast` contra el `bg` efectivo, haya o no personalización.
- `src/components/TemaBuilder.jsx` (nuevo): bottom-sheet con una fila por rol (Secundario/Terciario/Fondo/Superficie/Texto/Bordes), cada una con un swatch que abre el `ColorPicker` de la Fase 2 (reutilizado tal cual, sin reescribirlo) y una etiqueta "Auto"/botón "Automático" según esté o no personalizado; tira de vista previa de las 3 escalas generadas (Principal/Secundario/Terciario); sección "Estados avanzados" colapsada por defecto con aviso, para editar Éxito/Aviso/Error/Información sin que estén a la vista por accidente.
- `src/App.jsx`: nuevo estado `temaPersonalizado`, clave de Supabase propia (`'temaPersonalizado'`), guardado directo sin deshacer (mismo criterio que `historialColor`/`personalizacion`). Nueva función `updateTemaPersonalizado` y nueva prop `onPreviewTemaPersonalizado={setTemaPersonalizado}` pasadas a `SettingsView` — mismo patrón preview/commit que `onPreviewAccent`/`onUpdateAccent` desde la Fase 2.
- `src/views/SettingsView.jsx`: nueva tarjeta "Constructor de temas" en Apariencia, justo debajo de "Color de acento", que abre `TemaBuilder`.

### Decisiones
- **Los Estados (éxito/aviso/error/información) se mantienen fijos por defecto**, pero ahora son personalizables desde una sección aparte y colapsada con aviso explícito — resuelve la tensión entre el apartado 8 del contexto maestro (pide que sean personalizables) y la decisión de la Fase 1 (mantenerlos fijos por consistencia de UX, para que un error siempre se reconozca igual). Ninguna de las dos peticiones se ignora: existen y funcionan, pero no están a la vista por accidente.
- **Secundario/Terciario se derivan por rotación de tono (±35°, esquema análogo), no por otro método** (complementario, triádico...) — un esquema análogo da resultados armoniosos casi siempre sin importar el Principal elegido, que es justo lo que pide el apartado 9 del contexto maestro ("generar automáticamente una paleta completa y coherente a partir de un solo color").
- **La red de seguridad de contraste vive enteramente en `aplicarTema()`**, no en `TemaBuilder.jsx` — así ningún componente de UI nuevo (ni uno futuro) tiene que acordarse de comprobar contraste por su cuenta; es una propiedad del motor, no de cada pantalla que lo usa.
- **`TemaBuilder` reutiliza el `ColorPicker` de la Fase 2 sin tocarlo** — cada fila abre el mismo editor completo (espectro, HEX/RGB/HSL, recientes/favoritos) en vez de construir un selector más simple por rol; cumple lo que ya anticipaba el CHANGELOG de la Fase 2 ("la Fase 3 reutilizará este mismo `ColorPicker`... sin tener que reescribirlo").
- **Los swatches de cada fila leen `COLORS.<campo>` directamente** (no recalculan nada por su cuenta) — como `aplicarTema()` ya corre antes de cada render y dejó `COLORS` con el valor efectivo de cada rol (automático o personalizado), el componente de UI no necesita duplicar esa lógica ni arriesgarse a desincronizarse de lo que ve el resto de la app.

### Verificado en este entorno
- Balance de paréntesis/llaves/corchetes por script en los archivos tocados (`colorEngine.js`, `tokens.js`, `App.jsx`, `SettingsView.jsx`, `TemaBuilder.jsx`, `ColorPicker.jsx`) — todos OK.
- **Verificación real con Node** de `aplicarTema()` completo (no solo `colorEngine.js` suelto, esta vez también `tokens.js`): los 12 acentos de `ACCENTS` siguen dando Secundario/Terciario válidos con escalas completas y contraste texto/fondo ≥4.5:1 en tema oscuro; caso límite Fondo+Texto casi negro (`#050505`/`#0A0A0A`, tema oscuro) y caso límite opuesto Fondo+Texto casi blanco (`#FAFAFA`/`#F5F5F5`, tema claro) — ambos recuperados por `ensureContrast` a un contraste válido; overrides manuales de Secundario/Terciario respetados exactamente tal cual se fijaron (no se re-rotan); Secundario/Terciario automáticos confirmados distintos entre sí y del Principal en los 3 acentos probados; override de un Estado (`positive`) respetado, y confirmado que vuelve a su valor fijo de siempre al quitar el override; `altoContraste` (Fase A7) sigue funcionando en conjunto con `temaPersonalizado` sin conflicto.
- **Pendiente de confirmación real**: la interacción táctil de abrir el `ColorPicker` anidado dentro de `TemaBuilder` (dos hojas inferiores superpuestas) solo se puede probar de verdad en un móvil — el cierre al tocar fuera está pensado para que cerrar el `ColorPicker` no cierre también el `TemaBuilder` de detrás (mismo mecanismo `stopPropagation` que ya usa el resto de la app en modales anidados), pero conviene que Josué lo confirme en su iPhone.

## Fase 2 del Sistema de Personalización Visual Extrema — Editor de color avanzado (v1.12.0)

### Añadido / cambiado
- `src/lib/colorEngine.js`: nuevas conversiones HSV (`rgbToHsv`, `hsvToRgb`, `hexToHsv`, `hsvToHex`) — el espacio que usa el área 2D del selector (eje X = saturación, eje Y = brillo, con el tono aparte en un slider), más intuitivo aquí que HSL porque en HSL el 100% de luminosidad siempre da blanco puro sea cual sea la saturación. HSL de la Fase 1 se mantiene, sigue siendo válido para los campos numéricos.
- `src/components/ColorPicker.jsx` (nuevo): el editor de color en sí. Espectro 2D arrastrable (saturación × brillo, con degradado en tiempo real según el tono activo), slider de tono de 360°, campos HEX/RGB/HSL editables a mano, color actual vs. anterior con un toque para revertir, favoritos (estrella) y recientes (swatches), copiar/pegar vía `navigator.clipboard`, y cuentagotas real vía la `EyeDropper` API del navegador — el botón solo aparece si `window.EyeDropper` existe (no está disponible en Safari/iOS, así que en el propio móvil de Josué no se ve, en vez de mostrar un botón roto).
- `src/tokens.js`: `DEFAULT_HISTORIAL_COLOR` (`{ recientes: [], favoritos: [] }`), `MAX_COLORES_RECIENTES` (12) y `MAX_COLORES_FAVORITOS` (24).
- `src/App.jsx`: nuevo estado `historialColor`, clave de Supabase propia (`'historialColor'`), guardado directo sin deshacer (mismo criterio que `notificaciones`/`personalizacion`). Nuevas funciones `registrarColorReciente`/`toggleFavoritoColor`. Nueva prop `onPreviewAccent={setAccent}` pasada a `SettingsView` — ver Decisiones sobre por qué existe aparte de `onUpdateAccent`.
- `src/views/SettingsView.jsx`: la tarjeta "Color de acento" gana un 13º swatch (gradiente cónico arcoíris) que abre el `ColorPicker` — ya no limitado a los 12 acentos fijos, cualquier color es válido para el acento desde hoy mismo.

### Decisiones
- **Vista previa en tiempo real ≠ guardado en cada paso, a propósito.** El `ColorPicker` llama a `onPreview(hex)` en cada píxel de arrastre o cada tecla (retematiza toda la app al instante, solo `setAccent` en memoria) y reserva `onCommit(hex)` — el que de verdad escribe en Supabase y registra en recientes — para los momentos discretos: soltar el arrastre, salir de un campo, tocar un swatch, cerrar el editor. Sin esta separación, arrastrar el dedo por el cuadrado de color habría disparado decenas de escrituras a Supabase por segundo — el apartado 14 de la especificación pide "tiempo real" en la aplicación visual, no necesariamente en cada escritura de red.
- **Se integró ya en "Color de acento"** (el único rol personalizable que existe hoy) en vez de dejar el componente construido pero sin usar — cumple el criterio de "cada fase deja preparada la base para la siguiente, pero también hace algo útil ya". La Fase 3 (constructor de temas) reutilizará este mismo `ColorPicker` para cada rol nuevo que se añada (primario/secundario/fondo/superficie...), sin tener que reescribirlo.
- **Cuentagotas con detección de función, nunca simulado**: `'EyeDropper' in window` decide si el botón aparece. Es un ejemplo más del mismo criterio de todo el proyecto (biometría, notificaciones, Web Push...): nunca mostrar un control que no vaya a funcionar de verdad en el dispositivo real de Josué.
- **HSV para el área 2D, HSL para los campos numéricos** — no se ha unificado en un solo modelo a propósito: cada uno es mejor para lo que hace (HSV para "pintar" visualmente sin zonas muertas, HSL porque sigue siendo el modelo que la mayoría reconoce al teclear un valor a mano).
- Iconos usados en el componente (`X`, `Star`) elegidos porque ya están confirmados funcionando en esta build exacta de `lucide-react` (usados en otros archivos ya entregados) — se evitó a propósito cualquier icono de `lucide-react` no verificado en este entorno (sin acceso a npm para comprobar el paquete instalado), usando texto plano ("Copiar"/"Pegar"/"Cuentagotas") donde no había un icono ya confirmado.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`.** Verificación manual: balance de paréntesis/llaves/corchetes por script en los cinco archivos tocados (`colorEngine.js`, `tokens.js`, `ColorPicker.jsx`, `App.jsx`, `SettingsView.jsx`) — todos OK.
- **Verificación real con Node** de las conversiones HSV nuevas: round-trip HEX→HSV→HEX exacto en 12 colores de prueba; simulado el efecto de mover el tono/saturación/brillo por separado (como hará el arrastre real del selector) y confirmado que cada eje cambia de forma independiente sin arrastrar a los otros dos; probado el caso límite de un acento casi negro (`#1A1A1A`) con `buildRolesFromAccent`, que sigue dando `textOnAccent` con contraste 16:1 (excelente).
- Cruzadas las props que pasa `SettingsView.jsx` al `<ColorPicker />` contra su firma real (`initialHex, accent, onPreview, onCommit, onClose, recientes, favoritos, onToggleFavorito`) — coinciden una a una.
- **Pendiente de confirmación real**: el arrastre táctil del cuadrado y el slider de tono (con `touchmove`/`preventDefault` para que no haga scroll de la página mientras se arrastra) solo se puede probar de verdad en un móvil — es el mismo patrón de listeners en `window` que usan la mayoría de selectores de color web, pero conviene que Josué lo pruebe en su iPhone antes de darlo por bueno del todo.

## Fase 1 del Sistema de Personalización Visual Extrema — Motor universal de color (v1.11.0)

### Añadido / cambiado
- `src/lib/colorEngine.js` (nuevo): el motor en sí. Conversión entre HEX/RGB/HSL y OKLCH (fórmulas de Björn Ottosson, las mismas que usa CSS Color 4, escritas a mano porque este entorno no tiene acceso al registro de npm para instalar una librería de color). Contraste WCAG (`relativeLuminance`, `contrastRatio`) y ajuste automático (`ensureContrast`, `bestReadableText`) que empuja un color hacia negro/blanco en pasos de luminosidad OKLCH hasta alcanzar 4.5:1 (AA) contra un fondo dado. Generación de escalas perceptualmente uniformes de 11 pasos (`generateScale`, pasos 50-950) a partir de un solo color. `buildRolesFromAccent` ensambla todo lo anterior en los roles derivados del acento: escala de marca, texto legible sobre el acento, bordes/texto secundarios y terciarios, 5 estados de interacción (hover/active/focus/selected/disabled) y 4 efectos (glow/gradiente/sombra/highlight).
- `src/tokens.js`: `COLORS`/`COLORS_OSCURO`/`COLORS_CLARO` ganan dos roles de "Estados" nuevos, `warning` e `info` (curados por tema, igual que `positive`/`negative` — no derivados del acento, a propósito, ver Decisiones). `aplicarTema` gana un tercer parámetro (`accentHex`): además de aplicar la paleta del tema, ahora calcula y añade los roles derivados del acento sobre el mismo objeto `COLORS` singleton que ya leen por referencia ~20 vistas desde la Fase A3 — ningún archivo de vista necesita cambiar de import para heredar los tokens nuevos.
- `src/App.jsx`: el punto de llamada pasa a `aplicarTema(temaResuelto, apariencia.altoContraste, accent)`. El contenedor raíz gana variables CSS (`--color-bg`, `--color-surface`, `--color-border`, `--color-text`, `--color-text-muted`, además de la ya existente `--accent`) para que `index.css` también pueda consumir tokens en CSS puro, no solo dentro de `style={{}}` en JSX.
- **Migrados a tokens ~20 colores que estaban escritos directamente en componentes** (auditoría completa por `grep` de todo `src/`, ver Decisiones): el `#080A0D` repetido en `App.jsx`, `Auth.jsx`, `ui.jsx` (×3), `EstudiosView.jsx`, `HealthView.jsx`, `LibraryView.jsx` (×2), `NutritionView.jsx` (×2), `PersonalizationView.jsx` (×4), `ProductivityView.jsx`, `RelationView.jsx`, `SettingsView.jsx` (×2), `TrainingView.jsx` y `WellbeingView.jsx` pasa a `COLORS.textOnAccent` (calculado por el motor, no un valor fijo). El `#C9A24B` de los avisos de `HealthView.jsx`/`TrainingView.jsx` pasa a `COLORS.warning`. El track del `<input type="range">` en `index.css` pasa de `#222834` fijo a `var(--color-border, #222834)`.
- `src/views/PredictionsView.jsx`: `COLOR_RIESGO` (mapa fijo calculado una sola vez al cargar el módulo) pasa a `colorRiesgo()`, una función que lee `COLORS` en cada llamada — bug real corregido de paso (ver Decisiones).

### Decisiones
- **`#080A0D` era el hallazgo más importante de la auditoría, no solo una limpieza cosmética.** Era el color de texto fijo sobre CUALQUIER botón de acento en toda la app — funcionaba bien con los acentos por defecto (todos claros/medios), pero si Josué elegía un acento oscuro (Grafito, Morado…) el texto casi negro sobre un fondo casi igual de oscuro habría sido prácticamente ilegible. Verificado con Node ejecutando el motor real contra los 12 acentos de `ACCENTS`, en tema oscuro y en tema claro: los 24 casos dan `COLORS.textOnAccent` con contraste ≥4.5:1 (AA) — antes de este cambio, ninguno de los 12 estaba realmente garantizado.
- **`warning`/`info` se quedan fijos por tema, no derivados del acento** — mismo criterio ya establecido para `positive`/`negative`: un color de "Estados" que cambiara con la personalización del usuario sería una regresión de usabilidad (un aviso "amarillo" que un día es verde según el acento activo confundiría más de lo que ayudaría). La especificación maestra lo agrupa como rol semántico propio, no como parte de "Marca" — se ha respetado esa distinción.
- **Alcance deliberado de "todos los componentes deben consumir tokens" para esta fase**: se migraron los colores hardcodeados que YA EXISTÍAN (~20 encontrados por auditoría), no se reescribió cada vista entera "por si acaso" — el resto de la app ya consumía `COLORS.x`/`accent` correctamente desde la Fase A3. Se dejó explícitamente sin tocar un caso que parecía una violación pero no lo es: el icono de borrar foto en `HealthView.jsx` (`color: '#EDEFF2'`) va sobre un scrim oscuro fijo (`rgba(10,12,16,0.7)`) pensado para ser legible encima de cualquier foto, independientemente del tema activo — convertirlo a `COLORS.text` lo habría roto en tema claro (texto casi negro sobre scrim oscuro). Documentado aquí en vez de "arreglado" a ciegas.
- **`COLOR_RIESGO` en `PredictionsView.jsx` tenía un bug de reactividad real**, no relacionado con hardcodear colores pero descubierto en el mismo repaso: al ser un objeto calculado una sola vez al cargar el módulo (copiando el valor de `COLORS.positive`/`COLORS.negative` en ese instante), se quedaba "congelado" si Josué cambiaba de tema después — nunca se había notado porque nadie lo había probado cambiando de tema en mitad de sesión. Corregido convirtiéndolo en función.
- **Gamut mapping simplificado a clamping directo** en `oklchToHex` (no hay un algoritmo de mapeo de gama perceptual completo) — decisión de alcance explícita: en tonos muy saturados en los extremos de una escala puede perderse algo de croma respecto al ideal matemático, pero nunca produce un color inválido. Documentado en el propio archivo.
- **No se ha tocado ninguna UI todavía** (ni selector visual, ni constructor de temas, ni presets) — eso es, por petición explícita de Josué, el contenido de las Fases 2, 3 y 4, que no empiezan hasta que las pida una a una.

### Verificado en este entorno
- **Verificación real con Node.js, más allá del balance de paréntesis habitual** (novedad de esta fase: al ser funciones puras sin JSX, sí se pueden ejecutar de verdad en este sandbox, aunque `esbuild`/Vite sigan sin estar disponibles): round-trip HEX→OKLCH→HEX y HEX→HSL→HEX exacto en 7 colores de prueba (incluye varios acentos reales); los 12 acentos de `ACCENTS` probados en tema oscuro y claro dan siempre `textOnAccent` con contraste WCAG ≥4.5:1; `relativeLuminance`/`contrastRatio` verificados contra el valor de referencia conocido (blanco/negro = 21:1 exacto).
- Balance de paréntesis/llaves/corchetes por script en los 17 archivos tocados — todos OK. Un falso positivo detectado y confirmado como tal en `LibraryView.jsx` (línea sin tocar en esta fase): el verificador no entiende literales de expresión regular y confunde `\/\/ ` dentro de `/^https?:\/\//i` con un comentario de línea — se verificó a mano que el paréntesis está correctamente balanceado.
- Auditoría completa por `grep` de `#[0-9A-Fa-f]{6}` en todo `src/`: de 64 coincidencias iniciales, 37 eran legítimas (definiciones de `ACCENTS`/`PALETAS_PREDEFINIDAS`/los propios tokens en `tokens.js`), ~20 eran violaciones reales (ya migradas) y 1 se dejó intacta con justificación documentada.
- **Pendiente de confirmación real**: el "tacto" perceptual de las escalas generadas (si los 11 pasos se ven realmente uniformes en una pantalla real, no solo en los números) solo se puede juzgar de verdad en la Fase 2, cuando exista un selector visual para probarlas con distintos colores.

## Fase N4 — Pulido visual final (v1.10.0) — cierra el bloque de navegación (N1-N4)

### Añadido / cambiado
- `src/lib/resumenesHub.js`: cada resumen gana un campo `estado` (`'activo'` | `'vacio'` | `'info'`) — el "indicador de estado" que pedía la especificación original de las tarjetas (icono, nombre, resumen, indicador de estado) y que no se había construido en N1. `'activo'` cuando el módulo tiene datos reales que enseñar hoy/recientes, `'vacio'` cuando todavía no hay nada, `'info'` para los módulos de solo lectura/configuración (Estadísticas, Predicciones, Logros, Ajustes) que no tienen un "vacío" real que señalar. Ningún estado inventa una urgencia que no existe — es descriptivo, no una alarma.
- `src/views/HubView.jsx`: las tarjetas pasan de superficie sólida a "cristal" — fondo translúcido + `backdrop-filter: blur(18px)` (con el prefijo `-webkit-` necesario para Safari/iOS) + un brillo diagonal casi imperceptible, borde semitransparente. Nuevo punto de estado junto al nombre del módulo (color de acento si `'activo'`, apagado si `'vacio'`, ausente si `'info'`). Jerarquía tipográfica más marcada: la primera línea de resumen pasa a usar el color de texto principal (antes iba en `textMuted`, igual que la segunda línea — ahora se distingue mejor cuál es el dato y cuál el contexto). El encabezado "Área" pasa a mayúsculas con tracking amplio (estilo "eyebrow"), separado del título por más aire. Círculo del icono gana borde propio con el color de acento.
- `src/index.css`: nueva regla para `.hub-card-icon` — el círculo del icono gana su propio pellizco de escala (encima del de la tarjeta) durante el gesto de pulsación/expansión de la Fase N3, para sentirse como una pieza con peso propio. Nuevas reglas `.nav-tab-icon`/`.nav-tab-label` (transición de color suave al cambiar de pestaña activa en la barra inferior) y `.back-bar` gana una transición de fondo, para acompañar su nuevo estilo de píldora.
- `src/App.jsx`: la barra "← {Área}" pasa de texto suelto a una píldora con fondo tenue (coherente con el lenguaje "glass" del resto de la pantalla). Los iconos/etiquetas de la barra inferior ganan las clases `nav-tab-icon`/`nav-tab-label` para la transición de color suave.

### Decisiones
- **Con esta fase se cierra el bloque completo de navegación por áreas (N1 a N4)** — misma lógica que cuando A6 cerró el bloque Ajustes: documentado aquí y en HANDOFF.md, sin usar versión mayor (sigue el mismo patrón de incrementos menores `1.x.0` que todas las fases anteriores).
- El indicador de estado usa solo dos señales honestas (`'activo'`/`'vacio'`) en vez de un semáforo de 3+ colores con significados que esta app no puede respaldar con datos reales (ej. "en riesgo", "urgente") — mismo criterio de "nunca simular algo que no existe" de toda la Entrega 1.
- El efecto de cristal (`backdrop-filter`) es puramente estético: como las tarjetas no tienen contenido visual detrás salvo el fondo plano de la app, el "desenfoque" en sí apenas se nota, pero la transparencia + el brillo diagonal sí dan la sensación de superficie de vidrio pedida en la especificación original ("mucho glass/blur"). No se ha podido comprobar el rendimiento real de `backdrop-filter` en Safari/iOS con varias tarjetas a la vez (puede ser más costoso ahí que en Chrome de escritorio) — a vigilar si Josué nota lag al abrir un hub.
- No se tocó nada de estructura (N1), timing de transición de pantalla (N2) ni la secuencia de pulsación de tarjeta (N3) — cambio acotado a superficie visual y al indicador de estado que faltaba.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`.** Verificación manual: balance de paréntesis/llaves/corchetes por script en los cuatro archivos tocados (`App.jsx`, `HubView.jsx`, `index.css`, `resumenesHub.js`) — todos OK.
- Cruzados los 18 `case` de `resumenesHub.js` uno a uno: todos devuelven ahora `estado` (ninguno se quedó con solo `linea1`/`linea2`), y el `default` también lo incluye para no romper `HubView.jsx` si algún día aparece un id sin caso propio.
- **Pendiente de confirmación real:** el "tacto" del cristal/blur y el punto de estado solo se pueden juzgar de verdad viéndolos en un móvil, no en el código.

## Fase N3 — Microinteracciones de tarjeta (v1.9.0)

### Añadido / cambiado
- `src/views/HubView.jsx`: al pulsar una tarjeta ya no se navega al instante. Nuevo estado local `expandingId` + `handleAbrir(id)`: marca esa tarjeta como "expandiendo", dispara su animación (`.hub-card-expanding`) y solo tras `EXPAND_MS` (190ms) llama a `onOpenModulo(id)` (la navegación real). Mientras una tarjeta expande, el resto del hub queda deshabilitado (`disabled`) y retrocede levemente (`.hub-card-receding`, opacidad y escala reducidas) para que quede claro dónde está el foco. `useEffect` de limpieza que cancela el `setTimeout` pendiente si el hub se desmonta a medio gesto (ej. Josué toca otra pestaña de la barra inferior mientras la tarjeta sigue expandiendo) — evita que la navegación retrasada aterrice sobre una pantalla distinta a la que se pulsó.
- `src/index.css`: `.hub-card` gana un estado `:active` puramente CSS (sin esperar a JS) — al tocarla se encoge un poco, se aclara (`brightness`) y gana sombra, para la respuesta táctil inmediata. Nueva animación `hubCardExpand` (`.hub-card-expanding`): continúa desde ese mismo estado hacia una escala ligeramente mayor (1.03), más brillo y una sombra más profunda, con `z-index` propio para que se "eleve" por delante de las demás tarjetas. Nueva clase `.hub-card-receding` para las tarjetas no pulsadas mientras una está expandiendo.

### Decisiones
- **Secuencia exacta pedida por Josué:** escala hacia abajo al presionar → brillo/sombra → "elevación" → breve expansión → solo entonces la pantalla nueva desliza (la propia `.module-enter` de N1/N2 ya se encarga de esa parte, sin tocarla en esta fase).
- `EXPAND_MS` (190ms) elegido para que se note el gesto sin sentirse lento — coincide con la duración de la animación `hubCardExpand` en CSS, ambos números deben moverse juntos si se ajustan en el futuro.
- El retraso de navegación es un `setTimeout` fijo, no ligado al ajuste "Reducir movimiento"/"Animaciones desactivadas" de Apariencia (Fase A3) — con esos ajustes activados, la parte visual se neutraliza igual que el resto de la app (la regla global ya fuerza `animation-duration`/`transition-duration` a 0.01ms), pero la espera de 190ms antes de navegar se mantiene. Se documenta como un matiz menor conocido, no un fallo: 190ms es lo bastante corto para no notarse como un retraso real.
- No se tocó nada de N1/N2 (estructura, datos de las tarjetas, transición de pantalla) — cambio acotado a la interacción de pulsación.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`.** Verificación manual: balance de paréntesis/llaves/corchetes por script en los dos archivos tocados (`HubView.jsx`, `index.css`) — OK. Import de `useState`/`useRef`/`useEffect` añadido correctamente a la cabecera de `HubView.jsx`.
- Revisado a propósito el orden de los Hooks (con el error real de la Fase A3 todavía como referencia): `useState`/`useRef`/`useEffect` están todos al principio del componente, antes de cualquier `return`/cálculo condicional — no hay ningún `return` temprano en `HubView.jsx`, así que no aplica el riesgo de ese bug aquí, pero se revisó igualmente.
- Confirmado que `animationDelay` del estilo en línea (usado para el retraso de 80ms de la cascada de entrada) se pone a `0ms` en la tarjeta que expande, para que no herede sin querer el retraso de la animación de entrada y la expansión arranque al instante.
- **Pendiente de confirmación real:** que 190ms se sienta bien en un dedo real sobre una pantalla táctil — es un número de partida razonable, pero solo se puede ajustar con certeza probándolo en el móvil de Josué.

## Fase N2 — Pulido de transiciones de pantalla (v1.8.0)

### Añadido / cambiado
- `src/index.css`: nueva variable `--ease-premium: cubic-bezier(0.32, 0.72, 0, 1)` (curva de "deceleración enfática" tipo iOS), usada ahora por las cuatro animaciones del sistema de navegación para que se sientan consistentes entre sí. `hubCardIn` gana un ligero escalado (0.97→1) además del desplazamiento vertical, y pasa de 340ms a 420ms. `moduleSlideIn` gana el mismo escalado (0.98→1) y pasa de 260ms a 340ms. Dos animaciones nuevas: `hubHeaderIn` (el título del área, ej. "Salud", entra con un fundido corto justo antes que las tarjetas) y `backBarIn` (la barra "← {Área}" entra con su propio fundido lateral, más corto y rápido que el contenido de debajo, para sentirse como una capa fija en vez de arrastrar con el resto).
- `src/views/HubView.jsx`: el encabezado del hub (`<div>` con "Área" + nombre) gana `className="hub-header"` y `key={area.id}` — el `key` fuerza que el fundido se repita cada vez que se entra a un área distinta, no solo la primera vez que se monta el componente.
- `src/App.jsx`: el botón "← {Área}" gana `className="back-bar ..."` — su propia animación se combina con la del contenedor `module-enter` que lo envuelve (son transforms independientes de padre e hijo, se suman sin conflicto), dando un efecto de capas en vez de un solo bloque moviéndose entero.

### Decisiones
- **No se tocó el stagger de 80ms entre tarjetas** (lo pidió Josué explícitamente en la especificación original) — solo se refinó la curva y duración de cada tarjeta individual, no el ritmo entre ellas.
- **No se tocaron las microinteracciones de pulsación de tarjeta** (`active:scale-[0.98]` ya existente desde N1) — eso es explícitamente el alcance de la Fase N3 (escala + brillo + sombra + elevación + expansión antes de navegar), no de esta fase.
- Curva `cubic-bezier(0.32, 0.72, 0, 1)` elegida por ser la misma familia de curva de "deceleración enfática" que usan las transiciones de pantalla nativas de iOS — encaja con la referencia visual que dio Josué (Apple, Cal AI, Symmetry) sin necesitar ninguna librería de animación nueva (seguimos sin acceso al registro de npm en este entorno).
- Nada de esto cambia comportamiento ni datos — es puramente visual, cero riesgo de romper algo funcional.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`.** Verificación manual: balance de paréntesis/llaves/corchetes por script en los tres archivos tocados (`App.jsx`, `HubView.jsx`, `index.css`) — todos OK.
- Confirmado que las nuevas animaciones siguen dentro de las reglas `html[data-animaciones='desactivadas']`/`html[data-reducir-movimiento='true']` ya existentes (aplican a `*`, sin excepción), por lo que "Reducir movimiento" las sigue neutralizando igual que a las de la Fase N1.
- **Pendiente de confirmación real:** que la curva y duraciones elegidas se sientan bien en un móvil real (a diferencia del código, el "tacto" de una animación solo se puede juzgar viéndola correr de verdad).

## Fase N1 — Nueva navegación por áreas (v1.7.0)

### Añadido / cambiado
- `src/App.jsx`: la barra inferior de 4 accesos rápidos + "Más" (hoja plana con todos los módulos en lista) se sustituye por 5 pestañas fijas: 🏠 Inicio, ❤️ Salud, 📚 Vida, 💼 Gestión, ☰ Más. Nuevo array `AREAS_NAV` (4 áreas, cada una con su lista de ids de módulo) junto al ya existente `MORE_NAV` (catálogo plano, ahora con 18 entradas — se le añaden `sueno`, `nutricion` y `entreno`, antes exentos por vivir fijos en la barra vieja). Tocar Inicio va directo al panel "Hoy" como siempre; tocar cualquiera de las otras 4 pestañas abre primero un "hub" de esa área — nunca se entra directo a un módulo. `renderContent()` intercepta los tabs `area-*` antes del switch de siempre y delega en `HubView`; todos los `case` de módulo del switch quedan intactos, sin tocar ni una vista existente.
- `src/views/HubView.jsx` (nuevo): pantalla de hub — tarjetas grandes (no botones pequeños), una por módulo del área, con icono, nombre, resumen real de 2 líneas y flecha. Respeta el orden/ocultos/iconos personalizados de Josué (Fase 19) filtrando la lista fija de cada área con ese mismo modelo de datos, sin cambiarlo. "Ajustes" sigue fijo al final dentro del hub "Más", fuera de la personalización, mismo motivo de siempre (que nunca desaparezca la forma de deshacer un cambio).
- `src/lib/resumenesHub.js` (nuevo): calcula el resumen de 2 líneas de cada tarjeta a partir de datos reales ya guardados (último peso, horas de sueño, kcal de hoy, racha de hábitos, saldo, etc.) — nunca una cifra inventada; si un módulo no tiene datos todavía, la tarjeta lo dice abiertamente ("Sin registros todavía, toca para añadir el primero").
- `src/App.jsx`: al entrar a un módulo desde un hub aparece una barra "← {Área}" arriba (vuelve al hub, no al Inicio) y la vista entra con un deslizamiento horizontal suave (`module-enter` en `index.css`). Las tarjetas de un hub entran en cascada, con 80ms de retraso entre una y la siguiente (`hub-card` en `index.css`).
- `src/index.css`: nuevas animaciones `hubCardIn` (entrada en cascada de tarjetas) y `moduleSlideIn` (entrada de módulo) — ambas respetan automáticamente "Reducir movimiento"/"Animaciones desactivadas" de la Fase A3, que ya fuerza `animation-duration: 0.01ms` sobre cualquier animación de toda la app.
- Limpieza: se retira el estado `showMore`/`setShowMore` y la hoja modal "Más secciones" (ya no existe una lista plana — la sustituye el hub por área), y la variable `moreNavVisible`/`ajustesNavItem` que solo esa hoja usaba.

### Decisiones
- **Fase 1 de 4 (N1-N4), tal y como se acordó antes de escribir código.** Esta entrega es la N1: estructura de navegación + datos reales + animación de entrada mínima pero presente. Pendientes para fases futuras (N2-N4, solo si Josué pide continuar): refinar el timing de la cascada y el deslizamiento, microinteracciones de pulsación de tarjeta (escala + brillo + sombra + "elevación" antes de la transición), y pulido visual de cristal/blur/tipografía.
- **Ningún módulo cambia de contenido ni de ruta interna** — la reestructuración es solo de "cómo se llega", nunca de "qué se ve dentro". Esto reduce el riesgo de romper algo en 20+ vistas ya construidas.
- **La tarjeta 🤖 IA que Josué listó dentro de "Más" no está incluida todavía** en `AREAS_NAV.area-mas.modulos`: no existe hoy un módulo `ia` real en la app (AXION sigue pendiente de la conversación de diseño aparte). Se deja fuera en vez de simular una tarjeta que no lleva a ningún sitio real — se retoma en cuanto se diseñe AXION.
- Versión saltada de 1.6.0 a 1.7.0 (incremento menor, mismo criterio que las fases A1-A6) — es un cambio grande de UX pero no rompe datos ni rutas de Supabase.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`.** Verificación manual: balance de paréntesis/llaves/corchetes por script en los cuatro archivos tocados (`App.jsx`, `HubView.jsx`, `resumenesHub.js`, `index.css`) — todos OK.
- Cruce manual de las 18 entradas de `MORE_NAV` contra las 4 áreas de `AREAS_NAV`: los 18 ids aparecen exactamente una vez cada uno (ninguno duplicado, ninguno huérfano).
- Props de `<HubView />` cruzadas contra su firma (`area, modulos, personalizacion, resumenes, accent, onOpenModulo`) — coinciden.
- Grep final sin resultados para `PRIMARY_NAV` y `showMore` en todo `src/App.jsx`, confirmando que no queda ninguna referencia rota a la navegación anterior.
- **Pendiente de confirmación real:** que la sensación de "entrar" en el módulo (deslizamiento + barra de volver) se sienta natural en un móvil real y no solo en la vista de escritorio.

## Fase A6 — Privacidad (v1.6.0) — cierra el bloque Ajustes (A1-A6)

### Añadido / cambiado
- `src/App.jsx`: `RESET_MODULOS` (mapa de 14 módulos: sueño, calistenia, fútbol, economía, salud, nutrición, estudios, negocio, productividad, objetivos, diario, biblioteca, relación, fe, bienestar — con su label, valor por defecto y setter) y `borrarDatosModulo(id)`, que resetea ese módulo tanto en estado local como en Supabase. Perfil queda fuera (ya tiene su propio restablecimiento desde la Fase A2) y los tres módulos con archivos en Storage (saludFotos, calisteniaVideos, bibliotecaArchivos) quedan fuera a propósito (borrar solo el registro dejaría archivos huérfanos).
- `src/views/SettingsView.jsx`: categoría "Privacidad" pasa de "no construida" a 4 bloques — Panel de transparencia (PIN/biometría/bloqueo automático/notificaciones/sincronización/integraciones de un vistazo), nota sobre qué usa la IA, nota sobre permisos de dispositivo (no aplican — la app no usa cámara/micro/ubicación), y Eliminar datos por categoría (14 filas con confirmación inline por módulo, mismo patrón `confirmandoX` indexado por id).

### Decisiones
- Confirmado por `grep` en todo `src/` que no hay ni un solo `getUserMedia`/`mediaDevices`/`navigator.geolocation` — las fotos/vídeos usan el selector de archivos nativo del sistema (`<input type="file">`), no la cámara en vivo. Por eso el panel de permisos de dispositivo (apartados 178-184 de la especificación) se documenta como "no aplica" en vez de simular toggles de permisos que no existen de verdad.
- Eliminación de cuenta completa (apartado 197) queda fuera: borrar el login (no solo los datos) requiere una función serverless con permisos de administrador de Supabase que no existe en este proyecto. Se documenta como pendiente real, sin promesas.
- El panel de transparencia reutiliza datos ya presentes como props en `SettingsView` (accent, pin, seguridad, notificaciones) — no se guarda ningún dato nuevo, es puramente una vista agregada de lo que ya existe.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`.** Verificación manual: balance de paréntesis/llaves/corchetes por script (OK). Los ids usados en `modulosBorrables` (`SettingsView.jsx`) cruzados uno a uno contra las claves reales `loadData`/`saveData` de `App.jsx` para confirmar que cada botón "Borrar" apunta a la clave de Supabase correcta.
- **Con esta fase se cierra el bloque completo Ajustes (Fases A1 a A6)** de la Entrega 1 de la especificación extendida. Lo único que queda de esa entrega es el bloque AXION (apartados 203-1300), pendiente de una conversación de diseño con Josué antes de escribir ningún código (ver sección 0bis y sección 16 de HANDOFF.md).

## Fase A5 — Seguridad avanzada (v1.5.0)

### Añadido / cambiado
- `src/lib/biometria.js` (nuevo): `biometriaSoportada()`, `registrarBiometria(userId, nombre)` y `verificarBiometria(credencialId)` — WebAuthn (`navigator.credentials`) del navegador, sin servidor de verificación (documentado como límite honesto en el propio archivo: mismo nivel de confianza que el PIN, no una autenticación remota).
- `src/tokens.js`: `DEFAULT_SEGURIDAD` (`bloqueoAutomatico`, `biometriaActiva`, `biometriaCredencialId`) y `OPCIONES_BLOQUEO_AUTOMATICO` (Inmediatamente/30s/1min/5min/15min/Nunca, con su duración en ms).
- `src/App.jsx`: nuevo estado `seguridad` (vive dentro de la clave `ajustes`, junto a accent/pin/apariencia — las cuatro funciones de guardado mandan siempre el paquete completo). Nuevo `bloqueado` + temporizador de inactividad (`mousedown`/`keydown`/`touchstart`/`scroll` lo reinician) que bloquea toda la app, no solo una sección; caso especial para "Inmediatamente" que además bloquea al pasar a segundo plano (`visibilitychange`). Nuevo componente `BloqueoAutomaticoGate` (pantalla completa, desbloqueo por biometría si está activada + PIN siempre como respaldo). `updatePin` desactiva la biometría sola si Josué borra el PIN (apartado 145: PIN = respaldo obligatorio).
- `src/views/SettingsView.jsx`: categoría "Seguridad" gana tarjeta Biometría (activar/desactivar, con los tres estados: sin PIN / no soportado / activa / inactiva) y tarjeta Bloqueo automático (`OpcionesFila` sobre `OPCIONES_BLOQUEO_AUTOMATICO`).

### Decisiones
- Biometría como "gesto de desbloqueo rápido local" en vez de intentar simular una autenticación remota real sin tener backend para ello — decisión explícita para no sobre-prometer seguridad que esta arquitectura no puede dar.
- Bloqueo automático por defecto en "Nunca" — no se activa solo, Josué decide si lo quiere y con qué margen.
- `useEffect` de bloqueo automático colocados explícitamente antes de los `return` condicionales de `App.jsx`, con el error de orden de Hooks de la Fase A3 todavía fresco — se revisó a propósito antes de dar la fase por cerrada.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`.** Verificación manual: balance de paréntesis/llaves/corchetes por script en los tres archivos tocados (`tokens.js`, `App.jsx`, `SettingsView.jsx`, más el nuevo `biometria.js`) — todos OK.
- **Pendiente de confirmación real:** que WebAuthn funcione en iOS Safari como PWA instalada (soporte variable según versión), y que el bloqueo automático no resulte intrusivo en el uso diario real.

## Fase A4 — Notificaciones reales (v1.4.0)

### Añadido / cambiado
- `src/lib/notificaciones.js` (nuevo): `permisoNotificaciones()` / `pedirPermisoNotificaciones()` (Notification API nativa del navegador) y `notificarSiCorresponde(notificaciones, categoria, clave, titulo, cuerpo)` — comprueba interruptor global, categoría, permiso concedido y horario de descanso (soporta franjas que cruzan medianoche) antes de mostrar nada; evita repetir el mismo aviso el mismo día con una marca en `localStorage` (a propósito no en Supabase — detalle de dispositivo, no dato a sincronizar).
- `src/tokens.js`: `DEFAULT_NOTIFICACIONES` (`activadas`, `categorias` — 10 booleanos, `horarioDescansoActivo/Inicio/Fin`) y `CATEGORIAS_NOTIFICACION` (lista de labels para las 10 categorías: Salud, Sueño, Entrenamiento, Nutrición, Economía, Estudios, Productividad, IA, Objetivos, Sistema).
- `src/App.jsx`: nuevo estado `notificaciones`, nueva clave de Supabase `'notificaciones'` (guardada directa vía `updateNotificaciones`, sin `snapshotAndSave`/deshacer, mismo criterio que `personalizacion`), merge con `DEFAULT_NOTIFICACIONES` al cargar (incluyendo `categorias` anidado). Prop `notificaciones` pasada a `DashboardView` y a `SettingsView`.
- `src/views/DashboardView.jsx`: los tres avisos automáticos de la Fase 20 (`AvisoSuenoCorto`, `AvisoRachaEnRiesgo`, `AvisoExamenSinHoras`) ganan un `useEffect` que llama a `notificarSiCorresponde` con la categoría correspondiente (`sueno`, `productividad`, `estudios`) — primer caso de uso real del sistema de notificaciones.
- `src/views/SettingsView.jsx`: categoría "Notificaciones" pasa de "no construida" a 5 tarjetas — Permiso del sistema (estado en vivo + botón para pedirlo), Activación global, Categorías (10 interruptores), Horario de descanso (franja horaria), Acciones (exportar/importar/restablecer JSON, mismo patrón que Perfil/Apariencia).

### Decisiones
- **Sin Web Push de verdad, a propósito y dicho claro:** implementar notificaciones con la app cerrada del todo exige Service Worker con listener `push`, tabla de suscripciones en Supabase y otra función serverless en Vercel que las dispare — se documenta como pendiente real en vez de simularlo o prometerlo. Lo construido (Notification API mientras la app está abierta) es honesto y útil, no una simulación.
- `notificaciones` vive en su propia clave de Supabase, no dentro de `ajustes` — evita agrandar más el objeto que `updateAccent`/`updatePin`/`updateApariencia` ya tienen que reenviar completo en cada guardado.
- Los tres avisos del Dashboard son el "banco de pruebas" elegido para demostrar que el mecanismo funciona de extremo a extremo, en vez de dejar la categoría de Notificaciones construida pero sin ningún disparador real conectado.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`** (sigue sin acceso al registro de npm). Verificación manual: balance de paréntesis/llaves/corchetes por script en los cuatro archivos tocados (`tokens.js`, `App.jsx`, `DashboardView.jsx`, `SettingsView.jsx`, más el nuevo `notificaciones.js`) — todos OK.
- **Cuidado explícito con el orden de los Hooks** (tras el error real detectado y corregido en la Fase A3): los `useEffect` nuevos de `AvisoSuenoCorto`/`AvisoRachaEnRiesgo`/`AvisoExamenSinHoras` se escribieron desde el principio antes de los `return` condicionales de cada componente, recalculando las condiciones de forma segura ante datos ausentes (`ultimoSueno`/`productividad`/`estudios` nulos) para no romper las reglas de Hooks de React.
- **Pendiente de confirmación real:** que el permiso de notificaciones se pueda pedir y conceder de verdad en iOS Safari como PWA instalada (el soporte de Notification API en iOS es limitado y depende de la versión del sistema — puede que Josué no vea el botón funcionar igual que en un navegador de escritorio), y que una notificación llegue de verdad al cumplirse alguna de las tres condiciones de los avisos del Dashboard.

## Fase A3 — Apariencia avanzada (v1.3.0)

### Añadido / cambiado
- `src/tokens.js`: `COLORS` sigue siendo el mismo objeto singleton que ya usan por referencia (nunca desestructurado) unas 20 vistas — se añaden `COLORS_OSCURO` (copia de los valores originales) y `COLORS_CLARO` (paleta nueva: fondo `#F3F4F7`, superficie blanca, texto `#161A21`, etc.) y una función `aplicarTema(nombreResuelto)` que hace `Object.assign(COLORS, ...)` para mutar la paleta activa en el sitio. También `DEFAULT_APARIENCIA` (`tema`, `tamanoTexto`, `densidad`, `radioBorde`, `animaciones`, `reducirMovimiento`) y las listas `TEMAS_DISPONIBLES`, `TAMANOS_TEXTO` (con `px` por opción), `DENSIDADES_INTERFAZ`, `RADIOS_BORDE`, `NIVELES_ANIMACION`.
- `src/App.jsx`: nuevo estado `apariencia` (+ `temaSistemaOscuro` para resolver "automático" contra `window.matchMedia('(prefers-color-scheme: dark)')`, con listener en vivo). `temaResuelto` se calcula y se aplica llamando a `aplicarTema()` de forma **síncrona en el cuerpo del componente**, antes de los `return` condicionales de sesión/carga — así los hijos ya leen el tema correcto en la misma pasada de render, sin esperar a un efecto. Un segundo `useEffect` traduce `apariencia` a atributos reales del DOM: `document.documentElement.style.fontSize` (tamaño de texto — como Tailwind usa `rem`, escala toda la app sola) y `data-radio`/`data-animaciones`/`data-reducir-movimiento` en `<html>`, leídos por CSS en `index.css`. `ajustes` (clave de Supabase) gana el campo `apariencia`; `updateAccent`/`updatePin`/`updateApariencia` mandan siempre el paquete completo (`accent` + `pin` + `apariencia`) porque `saveData` sobrescribe el valor entero, no lo fusiona.
- `src/index.css`: reglas nuevas gateadas por `html[data-radio=...]` que sobrescriben `.rounded-3xl/.rounded-2xl/.rounded-xl/.rounded-lg` con `!important` para Recto/Suave (Redondeado = valores por defecto ya usados, sin override) — nunca toca `.rounded-full`. Reglas gateadas por `html[data-animaciones='desactivadas']`/`html[data-reducir-movimiento='true']` que matan `transition`/`animation` en toda la app, mismo mecanismo que el `@media (prefers-reduced-motion: reduce)` que ya existía.
- `src/views/SettingsView.jsx`: categoría "Apariencia" pasa de 1 tarjeta (solo acento) a 7 — Tema (ToggleTab de pastilla nuevo, `OpcionesFila`), Color de acento (sin cambios), Tamaño de texto, Densidad de interfaz, Bordes, Animaciones (nivel + interruptor "Reducir movimiento" aparte) y Acciones (exportar/importar/restablecer apariencia en JSON, mismo patrón `confirmandoX` que Perfil en la Fase A2). Categoría "Preferencias generales" pasa de "no construida" a informativa (`InfoOnly`): aclara que idioma/zona horaria/país/unidades ya viven en Perfil desde la Fase A2.
- Componente nuevo reutilizable en el propio archivo: `OpcionesFila({ opciones, valor, onChange, accent })` — fila de pastillas de selección única, mismo estilo visual que `DeportesChips` pero exclusivo en vez de múltiple.

### Decisiones
- **Tema real, no solo guardado:** era la pieza que Josué confirmó explícitamente, así que se priorizó que funcionara de verdad (mutación en sitio de `COLORS` + aplicación síncrona) en vez de dejarlo como preferencia decorativa.
- **Densidad de interfaz se guarda pero no tiene efecto visual todavía:** aplicarla de verdad exigiría revisar el espaciado (`p-*`, `gap-*`, `space-y-*`) de las ~20 vistas una por una — demasiado riesgo de romper algo visualmente para esta pasada. Se avisa explícitamente en la propia UI, mismo criterio que "Sistema de unidades" en la Fase A2 (nunca simular una función que no existe de verdad).
- **Animaciones:** de los 4 niveles del apartado 95, solo "Desactivadas" (y el interruptor aparte "Reducir movimiento") tienen efecto real hoy, porque la app tiene muy pocas animaciones propias que graduar entre Completa/Reducida/Mínima. Anotado igual de honesto en la UI.
- **Radios de borde:** override CSS global por atributo en vez de tocar cada `className` de cada vista — más barato y sin riesgo de regresión, a costa de ser un mecanismo "de fuerza bruta" (por eso se limita a las clases de radio, nunca toca tamaño/color/espaciado, y excluye `.rounded-full` a propósito).
- Paletas de color predefinidas (apartado 86), transparencias/materiales (93), estilos de icono alternativos (100-101), fondos con degradado/textura (102) quedan fuera de esta fase — personalización decorativa de bajo valor frente al resto, documentada como pendiente futura en la propia categoría.
- Personalización de widgets del Dashboard (103-106) no se duplica: ya está cubierta por "Pantalla principal" / `PersonalizationView.jsx` desde la Fase 19/20.

### Corrección de compatibilidad hacia atrás
- `updateAccent`/`updatePin` en `App.jsx` guardaban `ajustes` como `{ accent, pin }`, sin `apariencia`. Como `saveData` hace upsert del valor entero de la clave (sobrescribe, no fusiona los campos), cambiar el acento o el PIN después de haber tocado Apariencia habría borrado silenciosamente la apariencia ya guardada. Corregido: las tres funciones (`updateAccent`, `updatePin`, `updateApariencia`) mandan siempre el paquete `{ accent, pin, apariencia }` completo.
- `loadData(uidUser, 'ajustes', ...)` con fallback ampliado a `{ accent, pin, apariencia: DEFAULT_APARIENCIA }`, y `setApariencia({ ...DEFAULT_APARIENCIA, ...(a.apariencia || {}) })` al cargar — mismo patrón de merge que ya se usó para `DEFAULT_PERFIL` en la Fase A2, para que un registro `ajustes` guardado antes de esta fase no cargue con `apariencia` en `undefined`.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`** (sigue sin acceso al registro de npm). Verificación manual: balance de paréntesis/llaves/corchetes por script en `tokens.js`, `App.jsx` y `SettingsView.jsx` (los tres OK). Confirmado por `grep` que ningún archivo de `src/` hace `const { ... } = COLORS` — condición necesaria para que la mutación en sitio de `COLORS` se refleje en todas las vistas sin tocarlas.
- **Corrección de un error real detectado en este mismo turno, antes de entregar:** los dos `useEffect` nuevos de `App.jsx` se habían escrito primero después de los `return` condicionales de sesión/carga — eso rompe el orden de los Hooks de React (error "Rendered more hooks than during the previous render" al pasar de la pantalla de carga a la app cargada). Detectado al revisar el propio código antes de darlo por terminado y movido antes de los `return`, junto con la llamada a `aplicarTema()`.
- **Pendiente de confirmación real:** que el cambio de tema se vea correctamente en Vercel, que "Automático" seguido del sistema operativo funcione de verdad en iOS Safari (PWA instalada, no solo Chrome de escritorio), y que el contraste del tema claro sea cómodo en pantalla real — los colores de `COLORS_CLARO` se eligieron a ojo, sin poder renderizar nada en este entorno.

## Fase A2 — Perfil expandido (v1.2.0)

### Añadido / cambiado
- `src/tokens.js`: `DEFAULT_PERFIL` ampliado con `apellidos`, `nombreMostrado`, `sexo`, `pronombres`, `manoDominante`, `pesoObjetivo`, `objetivoPrincipal`, `deportesPracticados` (array), `nivelDeportivo`, `aniosExperiencia`, `lesiones` (array de `{ id, zona, estado, fecha, notas }`), `nivelEducativo`, `estudiosActuales`, `profesion`, `idioma`, `zonaHorariaAutomatica`/`zonaHorariaManual`, `pais`, `region`, `sistemaUnidades` — todos los campos anteriores intactos. Nuevas listas de opciones: `SEXOS_PERFIL`, `MANOS_DOMINANTES`, `OBJETIVOS_PRINCIPALES`, `DEPORTES_DISPONIBLES`, `NIVELES_DEPORTIVOS`, `ANIOS_EXPERIENCIA_OPCIONES`, `ESTADOS_LESION`, `NIVELES_EDUCATIVOS`, `IDIOMAS_DISPONIBLES` (solo español por ahora), `SISTEMAS_UNIDADES` (solo se guarda la preferencia, sin conversión real todavía).
- `src/views/SettingsView.jsx`: categoría "Perfil" reescrita, pasa de 1 tarjeta mínima a 7: **Datos básicos** (nombre, apellidos, nombre mostrado, fecha de nacimiento editable, sexo, pronombres), **Información física** (altura, peso, peso objetivo, mano dominante, nivel de actividad), **Información deportiva** (objetivo principal, `DeportesChips` — selector múltiple de pastillas sobre `DEPORTES_DISPONIBLES`, nivel deportivo, años de experiencia, `LesionesEditor` — alta/baja de lesiones con zona/estado/fecha/notas), **Información académica** (nivel educativo, estudios actuales, profesión), **Información general** (idioma, zona horaria automática/manual, país, región, sistema de unidades), **Cálculos corporales** (sin cambios) y **Acciones** (exportar perfil a JSON, importar desde JSON con confirmación inline antes de sobrescribir, restablecer perfil completo con confirmación inline).
- Dos componentes nuevos en el propio `SettingsView.jsx`: `DeportesChips({ value, onChange, accent })` y `LesionesEditor({ value, onChange, accent })`.
- `src/App.jsx`: el efecto que carga el perfil guardado cambia de `setPerfil(p)` a `setPerfil({ ...DEFAULT_PERFIL, ...p })`.

### Decisiones
- El patrón de confirmación inline para importar/restablecer reutiliza el mismo `confirmandoX` + caja `COLORS.surface2` ya establecido en `PersonalizationView.jsx` (`confirmandoOcultar`), no uno nuevo.
- Importar perfil hace `{ ...DEFAULT_PERFIL, ...pendingImport }`: un JSON incompleto no deja campos en `undefined`.
- Zona horaria y sistema de unidades solo se guardan como preferencia en esta fase — no hay lógica de conversión de unidades ni de horario en el resto de la app todavía; queda anotado en la propia UI para no sugerir algo que no está activo.

### Corrección de compatibilidad hacia atrás
- `App.jsx` cargaba el perfil con `setPerfil(p)` directo. Como `loadData()` no fusiona con el valor por defecto, el perfil real de Josué (guardado antes de esta fase) habría cargado con todos los campos nuevos en `undefined` — rompiendo por ejemplo `.includes()` sobre `deportesPracticados`. Corregido a `setPerfil({ ...DEFAULT_PERFIL, ...p })`, mismo patrón que ya se usó para Calistenia en la Fase 5.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`** (sigue sin acceso al registro de npm en este entorno). Verificación manual: balance de paréntesis/llaves/corchetes comprobado con script sobre `SettingsView.jsx` completo (OK, 617 líneas). Cruzado uno a uno contra el código real: `GhostBtn` acepta prop `icon` y la renderiza (`components/ui.jsx`), `COLORS.negative` existe en `tokens.js`, `TextInput` pasa `{...rest}` (acepta `disabled`, `type`, etc. sin problema), `Field`/`Select` sin cambios de firma.
- **Pendiente de confirmación real:** que el perfil de Josué ya guardado en Supabase sigue cargando bien con los campos nuevos, que exportar/importar/restablecer perfil funcionan de verdad, y que `DeportesChips`/`LesionesEditor` se ven y funcionan correctamente en pantalla.

## Fase A1 — Ajustes: arquitectura general (v1.1.0)

### Añadido / cambiado
- `src/views/SettingsView.jsx` reescrito por completo: pasa de ser una única pantalla larga a un centro de categorías (cabecera + buscador de categorías, tarjetas con icono/título/descripción/flecha, pantalla propia por categoría con botón atrás), siguiendo el orden fijo del apartado 4 de `ESPECIFICACION_AJUSTES_ENTREGA1.md`: Perfil, Apariencia, Pantalla principal, Preferencias generales, Notificaciones, IA, Seguridad, Privacidad, Datos, Sincronización, Integraciones, Accesibilidad, Funciones experimentales, Información.
- Categorías con contenido real (todo el contenido anterior reubicado, nada eliminado): **Perfil** (nombre/altura/peso/actividad + cálculos corporales, igual que antes), **Apariencia** (selector de color de acento, igual que antes), **Pantalla principal** (envuelve `PersonalizationView.jsx` sin tocarla, ahora como categoría en vez de estar siempre apilada), **Seguridad** (PIN + nota sobre biometría pendiente + botón de cerrar sesión, movido aquí), **Datos** (exportar CSV/Excel + deshacer).
- **Sincronización** e **Integraciones**: tarjeta informativa honesta en vez de un "próximamente" vacío — explican el estado real (sincronización automática con Supabase ya activa; sin integraciones todavía).
- Resto de categorías (Preferencias generales, Notificaciones, IA, Privacidad, Accesibilidad, Funciones experimentales): aviso de "todavía no construida" con la fase donde está planificada — nunca un control decorativo que no hace nada.
- `src/App.jsx`: el `case 'ajustes'` ya no renderiza `<SettingsView/>` + `<PersonalizationView/>` apiladas — `SettingsView` recibe también las props de personalización y las reenvía a su categoría interna "Pantalla principal". Import de `PersonalizationView` en `App.jsx` reducido a solo el named export `ICONOS_PERSONALIZABLES_MAP`, que es lo único que sigue usando directamente.
- Versión mostrada en la nueva categoría "Información" leída de verdad de `package.json` (import JSON nativo de Vite), no hardcodeada.

### Decisiones
- El buscador de esta fase filtra tarjetas de categoría (nombre + descripción), no ajustes individuales dentro de cada categoría — eso tiene sentido cuando haya más categorías con contenido real (A2 en adelante).
- Ninguna categoría sin construir muestra controles: mismo criterio que el resto de la app (nunca simular una función que no existe).
- Modo claro/oscuro (Fase A3) y biometría (Fase A5) quedan anotadas explícitamente como confirmadas por Josué dentro de sus categorías correspondientes, para que la siguiente IA no vuelva a preguntarlo.

### Verificado en este entorno
- **No se ha podido ejecutar `esbuild`** (sin acceso al registro de npm en este entorno, igual que en el turno anterior). Verificación manual: balance de paréntesis/llaves/corchetes comprobado con un script, y las firmas de props de `PersonalizationView` (`export default function PersonalizationView({ modulos, personalizacion, onMove, onToggleOculto, onSetIcono, onTogglePinExtra, onToggleFavorita, onMoveFavorita, modo, onSetModo, accent })`) y de `hexToRgba` (`src/lib/helpers.js`) verificadas contra el código real antes de usarlas en `SettingsView.jsx`.
- **Pendiente de confirmación real:** que las 5 categorías con contenido (Perfil, Apariencia, Pantalla principal, Seguridad, Datos) abren y funcionan igual que antes, que el PIN sigue creándose/protegiendo, y que Pantalla principal sigue reordenando/ocultando módulos correctamente.

## Decisiones de Josué sobre la Entrega 1 (documentación, sin código)

### Confirmado por Josué
- **Modo claro y modo oscuro, ambos disponibles** (Fase A3) — hasta ahora la app era "solo modo oscuro" (Fase 1). Implica crear un set de tokens de color para el tema claro además del oscuro ya existente en `tokens.js`.
- **Biometría sí** (Fase A5) — Face ID/Touch ID/huella como método adicional de desbloqueo, con el PIN como respaldo obligatorio. Deroga la regla antigua "No implementar biometría — solo PIN" (HANDOFF sección 17, actualizada).

### Actualizado en HANDOFF.md
- Sección 0bis (plan de fases), sección 2 (filosofía), sección 17 (reglas) e instrucciones finales — las tres menciones de "solo modo oscuro" y "no biometría" quedan corregidas para que ninguna IA futura las bloquee por error.

### Sin cambios de código todavía
- Estas son decisiones de alcance, no implementación — las Fases A3 y A5 siguen sin construirse.

## Corrección de contexto — Josué no usa Replit, despliega vía Vercel (documentación, sin código)

### Corregido
- `HANDOFF.md`: eliminadas/corregidas todas las referencias a "Replit" como entorno de trabajo de Josué (banner inicial, secciones 9, 11, 12, 16, 18 e instrucciones finales). Josué ha confirmado que no usa Replit — trabaja desde el iPhone y despliega vía **Vercel**. El antiguo "problema abierto de exponer el puerto en Replit" nunca fue real para su flujo y queda marcado como obsoleto, para que ninguna IA futura vuelva a intentar depurarlo.
- Se deja explícito que no se conoce el detalle exacto de cómo Josué edita/sube código desde el iPhone hacia Vercel (repositorio Git con auto-deploy, dashboard de Vercel u otro mecanismo) — no asumirlo, preguntarlo si hace falta para depurar un problema de despliegue real.

### Sin cambios de código
- Solo documentación. Ningún archivo de `src/`, `api/`, `supabase/` ni `package.json` tocado en este turno.

## Alcance nuevo (post-Prompt Maestro) — Especificación extendida "Ajustes / AXION", Entrega 1 (documentación, sin código)

### Añadido
- `ESPECIFICACION_AJUSTES_ENTREGA1.md` (nuevo, en la raíz del proyecto): transcripción de la especificación funcional que Josué pegó en el chat ("SISTEMA OPERATIVO PERSONAL — ESPECIFICACIÓN FUNCIONAL — MÓDULO AJUSTES — ENTREGA 1"), 1300 apartados. Apartados 1–202 (arquitectura de Ajustes, Perfil, Apariencia, Notificaciones, Seguridad, Privacidad) transcritos íntegros. Apartados 203–1300 (bloque "AXION", el motor de IA descrito por esta especificación) resumidos por bloques temáticos por su extensión (~1100 apartados) — el detalle literal vive en el propio chat si hace falta releerlo.
- `HANDOFF.md` sección **"0bis. Especificación extendida (post-v1.0)"**: plan de fases propuesto (Fase A1–A6 para el bloque Ajustes, realista con la arquitectura actual) y análisis de viabilidad del bloque AXION (arquitectura de IA de nivel empresarial — multiagente, bus de eventos, multi-proveedor, presupuestos, observabilidad — que excede con mucho la arquitectura real del proyecto, una PWA con una sola función serverless proxy a un único proveedor de IA). Se documenta como visión a largo plazo, no como fase inmediata; se propone un "AXION Lite" pragmático como alternativa realista.
- Conflicto detectado y documentado: la especificación pide biometría (Face ID/Touch ID/huella) como método de desbloqueo; la regla vigente del proyecto (HANDOFF sección 17) prohíbe explícitamente implementar biometría. Pendiente de que Josué aclare cuál prevalece antes de tocar Seguridad avanzada.

### Decisiones
- No se ha escrito ni modificado ningún archivo de código en este turno — es puramente intake y planificación de una especificación nueva, muy por encima en volumen de cualquier fase anterior.
- Se resume (no se transcribe íntegro) el bloque AXION por pura extensión práctica, no por decisión de recortar contenido — está señalado explícitamente en el propio archivo para que ninguna IA futura lo confunda con la especificación completa.
- Se etiqueta todo como "Entrega 1" porque el propio documento de Josué se autotitula así — se esperan más entregas de esta misma memoria de ~1200 apartados para otros módulos.

### Pendiente
- Confirmar con Josué el conflicto de biometría antes de construir Fase A5.
- Confirmar con Josué si abrir modo claro/automático (Fase A3) contradice o sustituye la decisión de "solo modo oscuro" de la Fase 1.
- Confirmar con Josué si quiere el subconjunto "AXION Lite" propuesto o construir la especificación AXION literal (con la advertencia honesta de complejidad ya documentada).
- Recibir la Entrega 2 (y siguientes) de la memoria de ~1200 apartados.

## Alcance nuevo (post-Prompt Maestro) — Iconos PWA (v1.0.1)

### Añadido
- `public/icon-192.png` y `public/icon-512.png`: iconos de la PWA que `public/manifest.json` referenciaba desde la Fase 2 pero que no existían todavía (pendiente de la sección 18 del HANDOFF).
- Diseño: tres anillos concéntricos al estilo "anillos de actividad" (Apple Fitness/Symmetry — coherente con la referencia de diseño premium del proyecto, sección 2 del HANDOFF), usando los tres primeros colores de `ACCENTS` (`src/tokens.js`): azul metálico `#5C7E9A`, dorado `#C9A24B`, verde salvia `#5E8C6A`, sobre fondo oscuro `#0A0C10` con degradado sutil hacia `#12151B`, esquinas redondeadas. Generados con Pillow a 4x y reescalados con antialiasing (script puntual, no forma parte del proyecto Vite).

### Decisiones
- No es una fase del Prompt Maestro (ya cerrado en v1.0.0) — se trata como alcance nuevo/tarea práctica pendiente, tal como indica la sección 16 del HANDOFF.
- Colores tomados directamente de `ACCENTS`/`COLORS` en `tokens.js`, sin introducir ningún color fuera del sistema de tokens ya establecido.
- Sin dependencias npm nuevas — los iconos se generaron fuera del proyecto (Python/Pillow) y se copiaron ya terminados a `public/`.

### Verificado en este entorno
- Los dos PNG se generaron y se revisaron visualmente a tamaño real (192 y 512 px).
- **No se pudo ejecutar el chequeo habitual de `esbuild`**: este entorno concreto no tiene acceso al registro de npm (`403 Forbidden` al intentar instalarlo), a diferencia de turnos anteriores. No se ha tocado ningún archivo `.js`/`.jsx`, solo se añadieron los dos PNG y se actualizó `manifest.json`... (sin cambios reales, ya apuntaba a las rutas correctas) y `package.json` (versión). Riesgo de regresión mínimo, pero queda registrado para la siguiente IA.

### Pendiente
- Que Josué instale la PWA de verdad en su iPhone y confirme si el diseño del icono le convence, o si prefiere otro (es una elección de la IA, no algo que él especificara).
- Todo lo demás de la sección 9/18 del HANDOFF (Vercel, ejecución real de las Fases 8-21, importaciones, exportación a PDF) sigue pendiente.

## Fase 21 (cierre) — Pulido final y QA: repaso visual/contraste real, módulo por módulo (v1.0.0 — Prompt Maestro completo)

### Revisado
- Repaso de contraste y coherencia visual leyendo el JSX de las 20 vistas (`src/views/*.jsx`) una por una, comparando contra el patrón de `components/ui.jsx` (`Card`, `SectionTitle`, escalas `text-xs`/`text-sm`/`text-lg font-bold`, iconos junto a cabeceras de `Card` a `size={16}`): tamaños de texto (`grep` de todas las clases `text-*` en las 20 vistas), colores fuera de `COLORS`/`accent` (ninguno encontrado — ya se había revisado por `grep` en la primera pasada de esta misma fase), texto atenuado (`COLORS.textMuted`) sobre fondo de acento (ninguno encontrado — bajo contraste no aplica en ningún sitio), y consistencia de las cabeceras de sección.
- Sin hallazgos de gravedad. Dos inconsistencias menores corregidas (ver "Corregido").

### Corregido
- `SettingsView.jsx`: la cabecera "Personalización" duplicaba a mano el marcado exacto de `SectionTitle` (mismas clases, mismo `fontFamily` inline) en vez de usar el componente compartido — ahora usa `<SectionTitle>`, igual que las otras 17 vistas que ya lo hacían.
- `TrainingView.jsx`: el icono `Trophy` de la cabecera de cada habilidad usaba `size={15}` en vez del `size={16}` que usan el resto de iconos junto a cabeceras `text-sm font-semibold` en toda la app.

### Cierre de fase
- Con este repaso visual/contraste quedan cerradas las tres partes de la Fase 21 (código de exportación/sincronización, tono de los 13 `AIPanel`, y este repaso visual) — **el Prompt Maestro completo de las 21 fases (sección 0 del HANDOFF) queda terminado**. `package.json` → **v1.0.0**.
- Límite honesto de este repaso: sigue siendo una lectura de código, no una app renderizada de verdad (Claude no puede ejecutarla en este entorno) — cubre clases de Tailwind, colores y componentes compartidos, no cosas que solo se ven en pantalla real (p. ej. saltos de línea en dispositivos concretos, o si un `grid-cols-2` se desalinea con contenido real muy largo). Cualquier detalle así que Josué note al usar la app de verdad merece su propio arreglo puntual, no una reapertura de la Fase 21.

---

## Fase 2 — Backend real, migración fuera de Artifacts, exportación, historial y PIN preparado

### Añadido
- Migración completa de un único archivo Artifact a un proyecto Vite real con estructura de carpetas (`src/lib`, `src/components`, `src/views`, `src/tokens.js`).
- Autenticación real con Supabase: registro, inicio de sesión, cierre de sesión (`src/components/Auth.jsx`, `src/lib/supabase.js`).
- Persistencia real en base de datos: tabla `app_data` en Supabase con seguridad por fila (RLS) — cada usuario solo accede a sus propios datos (`supabase/schema.sql`).
- Proxy seguro de IA: función serverless `api/ask-ai.js` que guarda `ANTHROPIC_API_KEY` solo en el servidor; el cliente (`src/lib/ai.js`) ya no llama a Anthropic directamente.
- Manejo elegante de "IA no configurada": si falta la clave, el resto de la app sigue funcionando y el panel de IA muestra un aviso claro en vez de fallar.
- Exportación de datos a CSV y Excel desde Ajustes (`src/lib/exportData.js`).
- Historial de cambios (últimos 10 pasos) y botón "Deshacer último cambio" en Ajustes.
- Mecanismo de PIN preparado: crear/cambiar PIN desde Ajustes, listo para proteger el futuro módulo de Relación.
- `manifest.json` para que la PWA sea instalable desde Safari.
- `SETUP.md`: guía paso a paso para poner en marcha Supabase, ejecutar el proyecto en local, y desplegarlo en Vercel.

### Corregido
- Colores de ingresos/gastos (verde/rojo en Economía), antes sueltos en el código, ahora centralizados como `COLORS.positive` / `COLORS.negative` en `src/tokens.js`.
- El prompt `AI_SYSTEM` ahora exige explícitamente que la IA cite en qué dato concreto basa cada afirmación (antes solo pedía tono y brevedad).

### Sin cambios (heredado de la Fase 1)
Todo el diseño visual, la paleta de colores y el comportamiento de Dashboard, Sueño, Entrenamiento y Economía se mantienen exactamente igual — solo han cambiado de sitio dentro de la nueva estructura de carpetas.

### Pendiente para cerrar esta fase de verdad
- Decisión sobre activar `ANTHROPIC_API_KEY` en producción (tiene coste real — ver `SETUP.md`).
- Verificación de que `npm install` / `npm run dev` funcionan sin errores: este código no ha podido compilarse ni ejecutarse en el entorno donde se escribió (sin acceso a red), así que es un primer borrador cuidado pero no probado todavía.
- Importación de datos (CSV del banco), detección de duplicados, y exportación a PDF quedan para más adelante.

## Fase 2 (continuación) — credenciales de Supabase recibidas

### Añadido
- `.env` real del proyecto, con `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY` ya rellenos con los valores que dio Josué.
- `.gitignore` para que `.env` nunca se suba por error a un repositorio.

### Corregido
- La URL de Supabase que pasó Josué tenía un error de dominio (`...supabase.com`) — corregida a `https://gbletrhhdppuiwrpoppf.supabase.co`, que es el dominio real de todos los proyectos de Supabase.

### Confirmado
- La clave que dio Josué (`sb_publishable_...`) es el nuevo formato "publishable" de Supabase: el reemplazo actual de la antigua `anon key`, pensado para ir en código de cliente — no es un dato secreto.

### Pendiente
- Confirmar que `supabase/schema.sql` se ejecutó en el proyecto real de Supabase de Josué.
- Confirmar que `npm run dev` conecta sin errores — sigue sin poder probarse en un entorno con acceso a red real.

## Fase 2 (cierre) — verificada funcionando de verdad

### Confirmado por Josué, en su propio dispositivo (iPhone, sin ordenador, vía Replit)
- `supabase/schema.sql` ejecutado correctamente — tabla `app_data` confirmada con `select * from app_data` (0 filas, sin error).
- `npm install` y `npm run dev` funcionan sin errores en un entorno real (Replit).
- La app arrancó, se abrió en el navegador y quedó operativa — Fase 2 cerrada y verificada, no solo escrita.

### Pendiente (no bloqueante, sigue abierto)
- Despliegue en Vercel todavía no confirmado.
- Decisión sobre `ANTHROPIC_API_KEY` en producción todavía no tomada.
- Iconos PWA (`icon-192.png`, `icon-512.png`) todavía no generados.

## Fase 3 — Salud

### Añadido
- Nuevo módulo **Salud** (`src/views/HealthView.jsx`), con tres pestañas:
  - **Medidas**: peso, grasa corporal, frecuencia cardíaca y tensión (sistólica/diastólica), con notas libres. Gráfico de evolución del peso (recharts) cuando hay al menos dos registros con peso. Aviso in-app si han pasado 7 días o más desde el último registro (o si todavía no hay ninguno) — el "recordatorio" que pedía el Prompt Maestro, ya que las notificaciones push no son fiables en una PWA de iPhone.
  - **Historial médico**: eventos puntuales de tipo Lesión, Enfermedad, Medicamento, Síntoma, Vacuna, Análisis médico u Otro (`TIPOS_HISTORIAL_MEDICO` en `src/tokens.js`), cada uno con fecha y descripción libre.
  - **Fotos de progreso**: subida de fotos reales a un bucket privado de Supabase Storage (`progreso`), con nota opcional por foto, miniaturas y borrado. Protegidas por el mismo PIN que se dejó preparado en la Fase 2 (componente nuevo `PinGate` en `src/components/ui.jsx`, reutilizable después para el módulo de Relación).
- `src/lib/supabase.js`: `uploadProgressPhoto`, `getSignedPhotoUrl` (URL firmada de 1 hora, el bucket es privado) y `deleteProgressPhoto`.
- `supabase/schema.sql`: bloque nuevo al final que crea el bucket `progreso` y sus políticas de Storage (cada usuario solo lee/escribe/borra dentro de su propia carpeta `user_id/...`). Pensado para ejecutarse como bloque independiente sin repetir lo ya ejecutado en la Fase 2.
- `SETUP.md`: nuevo paso 5 explicando cómo ejecutar ese bloque y comprobar que el bucket se creó.
- Cálculos corporales (IMC/BMR/TDEE), que ya vivían en Ajustes desde la Fase 1, se mantienen sin tocar — Salud registra la **evolución** de medidas en el tiempo, Ajustes sigue mostrando el cálculo orientativo a partir del perfil actual.
- IMC/BMR/TDEE y el nuevo módulo de Salud siguen sin dar objetivos calóricos ni de peso estrictos — el prompt de IA de este módulo lo prohíbe explícitamente y lo recuerda en pantalla.
- Salud (medidas + historial médico, sin fotos) se integró en: el sistema de deshacer/historial de cambios ya existente, y la exportación a CSV/Excel (`src/lib/exportData.js`).

### Decisiones de esta fase
- Las fotos de progreso quedan **fuera** del sistema de "deshacer": implican un archivo real subido a Storage, y deshacer no debía dejar archivos huérfanos sin ninguna referencia en la base de datos.
- Las fotos tampoco se incluyen en la exportación CSV/Excel (son binarios, no datos tabulares) — se gestionan y se borran directamente desde la pestaña Fotos.
- El bucket de Storage es privado (no público): las fotos nunca tienen una URL fija accesible por cualquiera: se sirven con URLs firmadas de una hora, generadas en el momento.

### Verificado en este entorno (sin red real, igual que en la Fase 2)
- Todos los archivos tocados o creados pasan un chequeo de sintaxis con `esbuild`.
- Un bundle completo de la app (con las dependencias de `npm` marcadas como externas) resuelve sin errores todos los imports/exports entre archivos locales nuevos y existentes.
- **Sigue sin poder ejecutarse `npm run dev` de verdad en este entorno** (sin acceso a red) — como en la Fase 2, la primera prueba real la hace Josué.

### Pendiente para cerrar esta fase de verdad
- Que Josué ejecute el bloque nuevo de `supabase/schema.sql` (bucket `progreso`) y confirme que aparece en Storage.
- Que pruebe subir y borrar una foto de progreso real desde su iPhone.
- Que confirme que el PIN (si no lo ha creado todavía) se puede crear desde Ajustes y que protege correctamente la pestaña Fotos.

## Fase 4 — Nutrición

### Añadido
- Nuevo módulo **Nutrición** (`src/views/NutritionView.jsx`), con tres pestañas:
  - **Comidas**: registro manual de nombre, calorías, proteínas, carbohidratos, grasas y fibra, con totales del día en la parte superior.
  - **Agua**: contador diario en mililitros, con botones +/- de un vaso (250 ml).
  - **Favoritos**: cualquier comida se puede guardar como plantilla (`onAddFavorito`) y registrarse de nuevo con un toque desde esta pestaña (`onRegistrarFavorito`).
- **Escaneo de código de barras** (`src/components/BarcodeScanner.jsx`, nuevo): abre la cámara trasera con `@zxing/library` (nueva dependencia) y decodifica en directo — elegido en vez de la `BarcodeDetector` nativa del navegador porque Safari/iOS no la soporta.
- **Open Food Facts** (`src/lib/openFoodFacts.js`, nuevo): consulta gratuita y sin clave por código de barras; devuelve nombre, marca y macros por 100 g. El formulario recalcula automáticamente los valores según los gramos que el usuario indique que ha comido de verdad.
- **Escaneo de comida por foto**: `api/ask-ai.js` ahora acepta una imagen opcional en el body (base64) y la reenvía a Anthropic como bloque de imagen; `src/lib/ai.js` añade `askAIWithImage()`. La IA devuelve solo un JSON (nombre + macros aproximados) que rellena el formulario — el usuario siempre revisa y ajusta antes de guardar, nunca se guarda automático.
- Nutrición (comidas + agua) integrada en el sistema de deshacer/historial y en la exportación CSV/Excel (`src/lib/exportData.js`).
- Panel de IA "Analizar mi nutrición", con la misma instrucción explícita que Salud: nunca objetivos calóricos estrictos, foco en hábitos y constancia.
- **Navegación reestructurada**: con Salud y Nutrición ya son 7 secciones, se dividió la barra inferior en 4 accesos rápidos (Hoy, Sueño, Entreno, Nutrición) + un botón "Más" que abre Salud/Economía/Ajustes en una hoja inferior. Pensado para que las próximas 9 fases con módulo nuevo no vuelvan a apretar la barra.
- `SETUP.md`: nuevo paso sobre permisos de cámara en Safari (necesarios para el escaneo de código de barras y de foto).

### Decisiones de esta fase
- El escaneo por foto **nunca guarda automáticamente** — solo rellena el formulario para revisión manual, igual de importante aquí que en Salud: es una estimación de la IA, no una medición.
- Se reutilizó el mismo endpoint `api/ask-ai.js` para texto e imagen (con un parámetro `image` opcional) en vez de crear un segundo endpoint — un único sitio donde vive la clave de Anthropic es más fácil de mantener seguro.

### Verificado en este entorno (sin red real, igual que en fases anteriores)
- **Nuevo esta fase:** además del chequeo de sintaxis archivo a archivo, se verificó con `esbuild` un **bundle completo** de la app entera (`src/main.jsx` como entrada, dependencias de `npm` como `external`) — confirma que absolutamente todos los imports/exports entre los 18 archivos del proyecto resuelven correctamente y no hay errores de sintaxis en ninguno, incluida la función serverless ampliada.
- `package.json` y `manifest.json` comprobados como JSON válido tras las ediciones.
- **Sigue sin poder ejecutarse `npm run dev` de verdad en este entorno** (sin acceso a red) — la primera prueba real la hace Josué, como en todas las fases anteriores.

### Pendiente para cerrar esta fase de verdad
- Que Josué pruebe de verdad: registrar una comida manual, escanear un código de barras real, hacer una foto de un plato real, ajustar agua, guardar y volver a registrar un favorito.
- Decisión sobre `ANTHROPIC_API_KEY` en producción (ahora también necesaria para el escaneo de foto, no solo para los paneles de texto).

### Confirmado por Josué
- Probado en real (Replit, iPhone): funciona correctamente.

## Fase 5 — Calistenia a fondo

### Añadido
- **Cada habilidad de calistenia (Handstand, Front Lever, Back Lever, Planche, Human Flag, Muscle Up, L-Sit) ahora es una tarjeta desplegable** en `TrainingView.jsx`, con el slider de nivel de siempre arriba y, al desplegarla, cuatro pestañas nuevas:
  - **Progresión**: lista de pasos tipo checklist. Se pueden añadir a mano, marcar como hechos, borrar, o generarlos con IA (botón "Generar progresión con IA" — pide a la IA de 4 a 6 pasos concretos según el nivel actual, en JSON, y los añade a la lista para que Josué los edite después). Las tres formas que pedía el Prompt Maestro (IA / manual / IA + edición) quedan cubiertas con el mismo mecanismo: todo pasa por la misma lista editable.
  - **PRs**: récords personales con fecha automática, valor libre (ej. "12 reps", "25s") y nota opcional.
  - **Sesiones**: botón "He entrenado esto hoy" (una vez al día por habilidad) y cálculo de la racha de días consecutivos. Aviso de "descanso recomendado" si la racha llega a 4 días seguidos sin descanso — la señal de sobreentrenamiento que pedía el Prompt Maestro.
  - **Vídeos**: subida de vídeos reales a un bucket privado de Supabase Storage (`entrenamiento-videos`, límite 100 MB, solo mp4/mov/webm). Botón "Analizar con IA" por vídeo: extrae 4 fotogramas clave del vídeo directamente en el navegador (`src/lib/videoFrames.js`, con `<video>` + `<canvas>`, sin subir nada a ningún sitio adicional) y los manda a la IA para un análisis de técnica — nunca el vídeo fluido completo, tal y como aceptaba el Prompt Maestro como limitación conocida. El análisis se guarda en el propio vídeo para no repetirlo cada vez. Comparación mes a mes: se pueden marcar hasta 2 vídeos de la misma habilidad para verlos lado a lado.
- `src/lib/videoFrames.js` (nuevo): `extractFramesFromSrc()`, funciona tanto con un archivo local recién subido como con la URL firmada de un vídeo ya guardado en Storage.
- `src/lib/ai.js`: nueva función `askAIWithImages()` (varias imágenes en una sola petición) — `askAIWithImage()` (una sola imagen, de la Fase 4) se mantiene intacta para Nutrición.
- `api/ask-ai.js`: ahora acepta un array `images` además del `image` suelto que ya existía; con `images`, manda todas las imágenes en el mismo mensaje a Anthropic.
- `src/lib/supabase.js`: `uploadTrainingVideo`, `getSignedVideoUrl`, `deleteTrainingVideo` — mismo patrón exacto que las fotos de progreso de Salud.
- `supabase/schema.sql`: bloque nuevo con el bucket `entrenamiento-videos` y sus políticas (cada usuario solo accede a su propia carpeta), con límite de tamaño y tipos de archivo permitidos.
- `SETUP.md`: nuevo paso 8 para activar el bucket de vídeos.
- Calistenia (con progresión, PRs y sesiones) sigue integrada en el sistema de deshacer y ahora la exportación CSV/Excel también incluye los PRs de cada habilidad, no solo el nivel.
- El panel de IA "Sugerencia de entrenamiento" ahora manda también la progresión, los PRs y las sesiones recientes, no solo el nivel — y se le pide explícitamente que avise si alguna habilidad lleva mucho tiempo sin PRs nuevos.

### Decisiones de esta fase
- **Los vídeos, igual que las fotos de Salud, quedan fuera del sistema de deshacer** — mismo motivo: evitar archivos huérfanos en Storage.
- **El análisis de IA de un vídeo nunca se dispara solo** — ni al subir el vídeo ni al abrir la pestaña. Solo cuando el usuario toca "Analizar con IA" explícitamente, respetando el principio de que la IA no actúa por su cuenta.
- **La extracción de fotogramas pasa siempre por el navegador, nunca por un servidor** — evita tener que subir el vídeo dos veces o montar un servicio de procesamiento de vídeo aparte; con 4 fotogramas por vídeo es suficiente para dar consejos de técnica útiles sin disparar el coste de tokens de imagen.
- **Progresión, PRs y sesiones viven dentro del mismo objeto `calistenia[skill]`** (junto al `nivel` que ya existía desde la Fase 1), no en claves nuevas separadas — mismo criterio que se usó con `salud` en la Fase 3, para no mezclar convenciones de almacenamiento distintas dentro del mismo proyecto.
- **Reutilización de datos antiguos:** los usuarios que ya tenían `calistenia` guardado desde antes de esta fase (solo con `{ nivel }`) siguen funcionando sin migración: la vista rellena `progresion`, `prs` y `sesiones` como listas vacías por defecto si no existen (`{ nivel: 0, progresion: [], prs: [], sesiones: [], ...data }`).

### Riesgo conocido, sin poder comprobarse en este entorno
- **La extracción de fotogramas de un vídeo ya subido a Supabase Storage depende de que el navegador pueda leer los píxeles de un `<video>` con una URL remota (CORS)** — Supabase Storage debería permitirlo por defecto en objetos servidos con URL firmada, pero esto **no se ha podido verificar de verdad sin acceso a red en este entorno de desarrollo**. Si al tocar "Analizar con IA" aparece el mensaje de que el navegador ha bloqueado los fotogramas, es este el motivo más probable — avisar a la siguiente IA si Josué lo reporta, para investigarlo con un mensaje de error real en la mano.

### Verificado en este entorno (sin red real, igual que en fases anteriores)
- Chequeo de sintaxis con `esbuild` en todos los archivos nuevos y modificados.
- Bundle completo de la app (`src/main.jsx`, dependencias npm como `external`) resuelve sin errores todos los imports/exports entre archivos, incluidos los 2 archivos nuevos (`videoFrames.js`) y las funciones ampliadas de `ai.js` y `api/ask-ai.js`.
- `package.json` y `manifest.json` siguen siendo JSON válido (no se han tocado en esta fase).
- **Sigue sin poder ejecutarse `npm run dev` de verdad en este entorno** — primera prueba real la hace Josué, como siempre.

### Pendiente para cerrar esta fase de verdad
- Que Josué ejecute el bloque nuevo de `supabase/schema.sql` (bucket `entrenamiento-videos`).
- Que pruebe: desplegar una habilidad, añadir pasos de progresión a mano, generar progresión con IA, añadir un PR, registrar una sesión (y comprobar el aviso de racha si entrena varios días seguidos), subir un vídeo real y tocar "Analizar con IA" — y reportar si ese último paso falla por el riesgo de CORS descrito arriba.


## Fase 6 — Estudios

### Añadido
- Nuevo módulo **Estudios** (`src/views/EstudiosView.jsx`), organizado por **programas** en pestañas (por defecto Bachillerato y Música, ampliable desde la propia vista con el botón "Programa").
- Dentro de cada programa, **asignaturas** en tarjetas desplegables, cada una con:
  - Registro rápido de **horas de estudio** (con total de la última semana visible en la cabecera).
  - **Exámenes**: fecha, tema, nota objetivo, días restantes calculados automáticamente, y campo para la nota obtenida una vez pasado.
  - **Plan de repaso** por examen: generado por IA como checklist (JSON de 3-7 pasos según los días restantes) y siempre editable, ampliable o borrable a mano — mismo patrón que la progresión de Calistenia de la Fase 5.
- **Explícame un concepto**: caja de pregunta libre a la IA (la primera de la app donde el texto lo escribe el usuario, no un prompt ya construido a partir de datos), pensada tanto para Bachillerato como para música.
- **Primera correlación real entre módulos**: sueño ↔ horas de estudio. Nuevo archivo `src/lib/correlaciones.js` con `cruzarPorFecha` (genérica, cruza dos series por fecha) y `correlacionSuenoEstudio` (primer uso), construido a propósito para que la Fase 16 (motor de correlaciones) lo reutilice con más pares de módulos en vez de reescribir la lógica de cruce.
- Panel de IA "Analizar mis estudios": lectura breve con asignaturas, exámenes y horas recientes como contexto — aconseja, nunca decide por Josué.
- Exportación CSV/Excel ampliada con exámenes (nota objetivo/obtenida, progreso del plan de repaso) y horas de estudio por asignatura.

### Decisiones de esta fase
- **Programas como lista editable, no como enum fijo en el código** — Josué puede añadir un tercer programa (por ejemplo, un idioma) sin que haga falta tocar código, cumpliendo el "todo editable, nada bloqueado" del documento original.
- **Asignaturas, exámenes y horas como listas planas relacionadas por `id`**, no anidadas dentro de cada programa — mismo criterio relacional que ya usan `salud`, `nutricion` y `calistenia`.
- **La correlación sueño↔estudio usa un umbral simple (7h) y exige al menos 2 días en cada grupo antes de mostrar nada** — una heurística que Josué puede verificar a ojo, no una caja negra, y coherente con la prudencia que ya se le pide al resto de la IA de la app.
- **`ANTHROPIC_API_KEY` sigue sin activarse en producción** — decisión consciente de Josué, confirmada en esta fase; los paneles de IA seguirán mostrando el aviso de "IA no configurada" hasta que decida activarla.

### Verificado en este entorno (sin red real, igual que en fases anteriores)
- Chequeo de sintaxis con `esbuild` en todos los archivos nuevos y modificados (`tokens.js`, `correlaciones.js`, `EstudiosView.jsx`, `App.jsx`, `exportData.js`, y los ya existentes por si acaso).
- Bundle completo de la app (`src/main.jsx`, dependencias npm como `external`) resuelve sin errores todos los imports/exports, incluido el módulo nuevo.
- **Sigue sin poder ejecutarse `npm run dev` de verdad en este entorno** — primera prueba real la hace Josué, como siempre.

### Confirmado por Josué antes de empezar esta fase
- La Fase 5 (Calistenia a fondo) funciona de verdad en su dispositivo — progresión, PRs, sesiones y vídeos con análisis por IA probados sin errores; el riesgo de CORS avisado en la fase anterior no se materializó.
- El "setup" ya está hecho, salvo `ANTHROPIC_API_KEY` en producción, que decide dejar sin activar por ahora.

### Pendiente para cerrar esta fase de verdad
- Que Josué pruebe: crear una asignatura, añadir un examen, generar un plan de repaso con IA, registrar horas de estudio, y comprobar que la correlación sueño↔estudio aparece cuando hay suficientes días cruzados.

## Fase 7 — Negocio

### Añadido
- Nuevo módulo **Negocio** (`src/views/BusinessView.jsx`), deliberadamente simple por petición explícita de Josué.
- Lista de **proyectos/ideas**: nombre, estado (Idea / En marcha / Pausado), notas libres (para clientes o tareas sueltas), ingresos y gastos totales editables a mano, con balance calculado al momento.
- Panel de IA "Mejorar mis ideas": sugerencias por proyecto, o ánimo a apuntar la primera idea si la lista está vacía.
- Exportación CSV/Excel ampliada con los proyectos de Negocio.

### Decisiones de esta fase
- **Un único array `proyectos`, sin clientes/tareas/movimientos como listas separadas** — cumple la petición explícita de Josué de no dedicarle mucho diseño a este módulo; si algún día pide más estructura, se amplía entonces.
- **Ingresos/gastos como totales editables, no como libro de transacciones** — ya existe uno completo en Economía; duplicarlo aquí habría sido justo la sobre-ingeniería que se pidió evitar.

### Verificado en este entorno (sin red real, igual que en fases anteriores)
- Chequeo de sintaxis con `esbuild` en todos los archivos nuevos y modificados.
- Bundle completo de la app (`src/main.jsx`, dependencias npm como `external`) resuelve sin errores todos los imports/exports, incluido el módulo nuevo.
- Sigue sin poder ejecutarse `npm run dev` de verdad en este entorno — primera prueba real la hace Josué.

### Confirmado por Josué antes de empezar esta fase
- La Fase 6 (Estudios) funciona de verdad en su dispositivo, sin incidencias.
- Esta vez no adjuntó un zip nuevo: confirmó en el chat que todo funcionaba y se continuó directamente desde el zip que la propia IA había generado en el turno anterior de esta misma conversación.

## Fase 8 — Productividad

### Añadido
- **Hábitos**: racha "en pausa" (un día fallado no la rompe a cero, dos días seguidos sí la reinician), mejor racha guardada aparte. Panel de IA "Consejo de hábitos".
- **Rutinas/checklists**: pasos reutilizables con progreso X/Y y botón "reiniciar para hoy".
- **Pomodoro**: 25 min trabajo / 5 min descanso, con contador de sesiones completadas hoy.
- **Tareas**: lista con fecha límite opcional, pendientes/hechas separadas.
- **Metas a corto plazo**: nombre, periodo (diaria/semanal/mensual/anual), objetivo numérico y progreso con barra visual.
- Hábitos, tareas y metas integrados en historial/deshacer y en exportación CSV/Excel (rutinas y pomodoros no, por no ser datos tabulares con sentido fuera de la app).
- Nueva utilidad `addDays` en `helpers.js`.

### Decisiones de esta fase
- Metas cortas (esta fase) deliberadamente separadas de los futuros "Objetivos" 30d-10a (Fase 9) — son dos sistemas distintos, no fusionar.
- Contador de pomodoros fuera del sistema de deshacer — una sesión de concentración ya hecha no tiene sentido "deshacerla".
- Ninguna dependencia npm nueva esta fase.

### Verificado en este entorno (sin red real)
- Chequeo de sintaxis con `esbuild` en todos los archivos nuevos y modificados.
- Bundle completo de la app resuelve sin errores todos los imports/exports, incluido el módulo nuevo.
- Sigue sin poder ejecutarse `npm run dev` de verdad aquí — primera prueba real la hace Josué.

### Confirmado por Josué antes de empezar esta fase
- La Fase 7 (Negocio) funciona de verdad en su dispositivo, sin incidencias.

## Fase 9 — Objetivos

### Añadido
- Lista de objetivos por plazo (30 días, 90 días, 1 año, 5 años, 10 años), con estado activo/cumplido.
- Aviso de revisión periódica (30+ días sin revisar) con botón de revisión asistida por IA: valora brevemente el conjunto y sugiere como máximo un objetivo nuevo si ve un hueco — nunca lo añade sola.
- Panel de IA "¿Voy por buen camino?" para consultas puntuales, aparte del banner de revisión.
- Objetivos integrados en historial/deshacer (`ultimaRevision` queda fuera, como el contador de pomodoros) y en exportación CSV/Excel.

### Decisiones de esta fase
- Objetivos (esta fase) y Metas cortas (Productividad, Fase 8) se mantienen como sistemas separados a propósito, sin compartir datos ni componentes.
- La revisión con IA nunca añade objetivos automáticamente — solo texto para que Josué decida.
- A partir de esta fase, Josué pidió encadenar la construcción de fases sin esperar confirmación de ejecución real de cada una — se sigue construyendo una fase por turno igualmente.

### Verificado en este entorno (sin red real)
- `esbuild`: sintaxis de todos los archivos nuevos/modificados y bundle completo de la app sin errores.
- Ni la Fase 8 ni la Fase 9 tienen confirmación de ejecución real todavía — pendiente por parte de Josué.

### Aparte del código: Josué sigue atascado exponiendo el puerto del servidor de desarrollo en Replit (Preview/Webview) — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 10 — Diario

### Añadido
- Entrada diaria breve (`src/views/DiaryView.jsx`): estado de ánimo (1-5, selector con emoji), cómo me he sentido, qué he aprendido, qué mejoraré mañana. Una sola entrada por día — si ya existe la de hoy, se precarga en el formulario para completarla o corregirla en vez de duplicarla.
- Entradas anteriores en tarjetas plegables (fecha + primera línea visible, contenido completo al abrir), con opción de eliminar cada una.
- Panel de IA "Detectar patrones emocionales": analiza hasta las 20 entradas más recientes (ánimo + texto) y señala patrones si los hay; si hay muy pocas entradas para un patrón real, lo dice abiertamente en vez de forzarlo. Nunca se dispara sola, solo a un toque.
- Nuevo componente `Textarea` en `src/components/ui.jsx` — primera vez que la app necesita texto libre de varias líneas; mismo estilo visual que `TextInput`.
- Diario integrado en historial/deshacer y en exportación CSV/Excel.
- Sin PIN adicional, por petición explícita de Josué (a diferencia de la futura Fase 12, Relación, que sí usará `PinGate`).

### Decisiones de esta fase
- Una entrada por día (no una lista libre como Sueño o Fútbol) porque el Prompt Maestro describe el Diario como reflexión diaria, no un registro de varios eventos por día.
- La detección de patrones emocionales es una petición puntual del usuario (como el resto de paneles de IA de la app), nunca un análisis automático en segundo plano.
- Se sigue encadenando la construcción de fases sin esperar confirmación de ejecución real de cada una, por petición de Josué en fases anteriores.

### Verificado en este entorno (sin red real)
- `esbuild`: sintaxis de todos los archivos nuevos/modificados y bundle completo de la app sin errores.
- Ni la Fase 8, ni la Fase 9, ni esta Fase 10 tienen confirmación de ejecución real todavía — pendiente por parte de Josué.

### Aparte del código: el atasco de Replit exponiendo el puerto del servidor de desarrollo sigue sin resolver — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 11 — Biblioteca

### Añadido
- Nueva vista `src/views/LibraryView.jsx`: listado único y buscable de PDFs, vídeos, fotos, apuntes de texto y enlaces.
- Subida de PDF/vídeo/foto con título opcional (por defecto el nombre del archivo), guardados en el nuevo bucket privado de Supabase Storage `biblioteca` (`supabase/schema.sql`).
- Extracción automática del texto del PDF en el propio navegador al subirlo (`src/lib/pdfText.js`, con `pdfjs-dist`), guardado como `textoExtraido` para poder buscar dentro del contenido — funcionalidad clave del Prompt Maestro para esta fase ("clave para el instituto"). Si el PDF es un escaneo sin texto real, no falla: se avisa en la tarjeta y queda buscable solo por título.
- Apuntes de texto libre (título + contenido) y enlaces (título + URL + descripción opcional), ambos de alta directa sin archivo.
- Buscador único sobre título, contenido de apuntes, descripción/URL de enlaces y texto extraído de los PDF, con un fragmento de contexto alrededor de la coincidencia encontrada.
- Filtro por tipo (Todos/PDFs/Vídeos/Fotos/Apuntes/Enlaces).
- Eliminar cualquier ítem, incluyendo el archivo correspondiente en Storage cuando aplica.
- Exportación CSV/Excel: apuntes y enlaces de Biblioteca incluidos (los archivos no, mismo criterio que las fotos de progreso de Salud).

### Decisiones de esta fase
- Biblioteca se divide en dos estados: `biblioteca` (apuntes/enlaces, texto puro, con deshacer) y `bibliotecaArchivos` (pdf/vídeo/foto, sin deshacer) — mismo criterio que Salud/`saludFotos` y Calistenia/`calisteniaVideos`, para no dejar un archivo huérfano en Storage al deshacer.
- Un único bucket de Storage (`biblioteca`) para los tres tipos de archivo, con el tipo guardado en la fila de datos, no en Storage.
- Sin IA en esta fase — el Prompt Maestro no la pide para Biblioteca, no se añade alcance no solicitado.
- El Prompt Maestro completo de las 21 fases se ha incorporado íntegro a `HANDOFF.md` (sección 0), para que ninguna IA futura tenga que pedirlo de nuevo.

### Dependencias
- Nueva dependencia npm: `pdfjs-dist` (`package.json` v0.11.0). **Josué necesita ejecutar `npm install` en Replit** tras esta fase.

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app (todos los módulos locales, incluidos los nuevos) sin errores, con las dependencias npm marcadas como externas — este entorno no tiene acceso a red para instalar `pdfjs-dist` de verdad.
- Ninguna de las Fases 8, 9, 10 ni esta Fase 11 tiene confirmación de ejecución real todavía — pendiente por parte de Josué.

### Aparte del código: el atasco de Replit exponiendo el puerto del servidor de desarrollo sigue sin resolver — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 12 — Relación (privado)

### Añadido
- Nueva vista `src/views/RelationView.jsx`: nombre de la pareja (editable) y lista de fechas importantes (etiqueta + fecha), con entrada manual.
- Módulo protegido por el PIN existente, reutilizando el mismo `PinGate` de `ui.jsx` que ya usa la pestaña Fotos de Salud — sin PIN creado, muestra el mismo aviso para ir a Ajustes.
- Nuevo estado `relacion` en `App.jsx` (`{ nombre, fechas: [] }`), con carga/guardado en Supabase (`app_data`, clave `relacion`).
- Recordatorio en pantalla principal (`Hoy`): tarjeta discreta con la próxima fecha importante y cuenta atrás ("Aniversario en 12 días"), sin volver a pedir el PIN — el detalle completo sigue protegido en la pestaña Relación.
- Nuevo helper `diasHasta()` / `proximaOcurrencia()` en `src/lib/helpers.js`: calcula la próxima vez que "toca" una fecha guardada, sirviendo tanto para fechas que se repiten cada año (aniversario, cumpleaños) como para una fecha puntual futura.
- Nueva entrada de navegación "Relación" en la hoja "Más" (icono `Heart`).

### Decisiones de esta fase
- `relacion` (nombre + fechas) es texto puro sin archivos, así que pasa por `snapshotAndSave`/deshacer, igual que Diario o los apuntes de Biblioteca — no se aparta a un estado sin deshacer como las fotos/vídeos.
- `relacion` se excluye deliberadamente de la exportación CSV/Excel: es el único módulo protegido de principio a fin por PIN, y el export no vuelve a pedirlo — mismo criterio de exclusión que las fotos de Salud o los vídeos de Calistenia, aunque el motivo aquí es de privacidad y no de tipo binario.
- El recordatorio del Dashboard se muestra sin pedir el PIN: es solo una etiqueta y una cuenta atrás (igual de discreto que un recordatorio de calendario del móvil), mientras que el nombre completo y la lista entera siguen detrás del `PinGate` en la pestaña Relación. Si Josué prefiere que el propio recordatorio del Dashboard quede también oculto sin PIN, es un ajuste sencillo para pedir en cualquier momento.
- Sin IA en esta fase — el Prompt Maestro no la pide para Relación, no se añade alcance no solicitado.
- Sin fotos ni archivos en esta fase — el Prompt Maestro solo pide nombre y fechas importantes; los "Recordatorios románticos" (lista de días activables) son la Fase 13, no esta.

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app (todos los módulos locales, incluida esta fase) sin errores, dependencias npm marcadas como externas.
- Ninguna de las Fases 8, 9, 10, 11 ni esta Fase 12 tiene confirmación de ejecución real todavía — pendiente por parte de Josué.

### Aparte del código: el atasco de Replit exponiendo el puerto del servidor de desarrollo sigue sin resolver — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 13 — Recordatorios románticos

### Añadido
- Subpestaña "Días especiales" dentro de Relación (junto a "Fechas"), con los 11 nombres del Prompt Maestro (Aniversario, Cumpleaños, Día de la Novia, Día del Peluche, Día de las Flores Amarillas, Día del Chocolate, Día del Cine, Día del Maquillaje, Día del Anillo de Promesa, Día de los Collares, Día de los Poemas) como chips seleccionables.
- Tocar un chip abre el mismo formulario de fecha que "Fechas" — comparten el array `relacion.fechas`, mismo `PinGate`, sin ninguna clave de datos nueva.
- Chips ya usados se marcan con un check visual.

### Decisiones de esta fase
- Reutilizar el modelo de datos y los handlers ya existentes de "Fechas" en vez de crear un sistema paralelo — son, en esencia, el mismo tipo de dato.
- Ninguna fecha se autogenera: tocar un chip solo abre el formulario, el usuario escribe la fecha él mismo.
- La recurrencia anual de una fecha ya guardada (cuenta atrás que salta al año siguiente) es un cálculo de visualización sobre un dato existente, no la creación automática de una entrada nueva.

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app sin errores, incluida la subpestaña nueva.
- Ni esta fase ni las Fases 8-12 tienen confirmación de ejecución real todavía.

### Sin dependencias npm nuevas, sin cambios en App.jsx ni en el esquema de Supabase.

## Fase 14 — Fe y vida espiritual

### Añadido
- Nueva vista `src/views/FaithView.jsx` con 4 subpestañas (`ToggleTab`): Servicio, Calendario, Diario, Objetivos.
- **Servicio:** registro de cuándo has servido en cada rol (Eucaristía, Anuncio, Preparación, Palabra, Otro) con fecha y notas opcionales, listado de más reciente a más antiguo.
- **Calendario:** eventos puntuales (Convivencia, Reunión, Catequesis, Retiro, Otro) con título, fecha y notas — separados en "Próximos" y "Pasados", sin recurrencia automática (a diferencia de las fechas de Relación, un retiro pasado no "vuelve" solo).
- **Diario espiritual:** una entrada de texto libre al día (reutiliza `Textarea`), independiente del Diario general (Fase 10) — su propio array, sin mezclar datos. Incluye `AIPanel` "Reflexionar sobre mis últimas entradas".
- **Objetivos:** mismo patrón que `ObjectivesView` (Fase 9) pero en su propia lista — objetivos espirituales agrupados por `PLAZOS_OBJETIVO` (30 días a 10 años), con `AIPanel` "¿Voy por buen camino?".
- Nuevo estado `fe` en `App.jsx` (`{ servicio: [], eventos: [], diario: [], objetivos: [] }`), con carga/guardado en Supabase (`app_data`, clave `fe`), pasa por `snapshotAndSave`/deshacer (texto puro, sin PIN ni archivos).
- Nueva entrada de navegación "Fe" en la hoja "Más" (icono `Church`), entre Diario y Biblioteca.
- `src/lib/exportData.js`: las 4 sub-áreas de Fe incluidas en la exportación CSV/Excel (sin PIN, mismo criterio que Diario/Biblioteca).
- Nuevos tokens en `src/tokens.js`: `TIPOS_SERVICIO_FE`, `TIPOS_EVENTO_FE`, `DEFAULT_FE`.

### Decisiones de esta fase
- **La IA de este módulo nunca da autoridad doctrinal.** Como `AIPanel` reutiliza el mismo `AI_SYSTEM` general de toda la app (no admite un system prompt distinto por módulo), la restricción se añade dentro del propio `buildPrompt()` de los dos `AIPanel` de esta vista (constante `AVISO_DOCTRINAL` en `FaithView.jsx`): nunca zanjar preguntas de fe profundas, y si el texto las roza, decirlo y recomendar hablarlo con la comunidad o el responsable de pastoral.
- Sin PIN en todo el módulo — el Prompt Maestro no lo pide para Fe (a diferencia de Relación, Fase 12), mismo criterio que el Diario general.
- "Servicio" y "Calendario" se mantienen como dos listas separadas en vez de fusionarse: Servicio es un registro de participación en roles concretos y recurrentes; Calendario es un calendario general de eventos puntuales (convivencias, retiros...) — mezclar ambos habría forzado un modelo de datos con campos condicionales según el tipo.
- El Diario espiritual es un array propio (`fe.diario`), no reutiliza `diario.entradas` del Diario general — son dos diarios con propósitos distintos (vida en general vs. vida de fe) y Josué puede querer llevarlos por separado.
- Los eventos del Calendario se ordenan por fecha literal, sin recalcular ninguna recurrencia anual (a diferencia de `proximaOcurrencia`/`diasHasta` de Relación) — un retiro o una reunión puntual no se repite sola cada año.

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app (todos los módulos locales, incluida esta fase) sin errores, dependencias npm marcadas como externas.
- Ninguna de las Fases 8 a 14 tiene confirmación de ejecución real todavía — pendiente por parte de Josué.

### Aparte del código: el atasco de Replit exponiendo el puerto del servidor de desarrollo sigue sin resolver — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 15 — Bienestar digital

### Añadido
- Nueva vista `src/views/WellbeingView.jsx` con 4 subpestañas: Resumen, Tiempo de uso, Concentración, Reflexión.
- **Resumen**: tres índices (Productividad/Distracción/Equilibrio) como barras de progreso, calculados como % de minutos por categoría en los últimos 7 días de registros. Aviso explícito de que no es una medición real del dispositivo, solo una lectura del propio registro de Josué.
- **Tiempo de uso**: alta manual (categoría, app/actividad opcional, minutos, fecha) y listado de los últimos 25 registros con borrado.
- **Concentración**: temporizador simulado con duración elegible (10/20/30/45/60 min), reutilizando el mismo mecanismo del Pomodoro de Productividad. Mensaje breve al completar una sesión y recuento (no puntuación) de sesiones de la semana. Aviso explícito de que no bloquea otras apps del móvil de verdad — no es viable en una PWA.
- **Reflexión**: pantalla que Josué abre él mismo, nunca automática, con 3 preguntas guía (¿por qué has abierto esto? ¿es lo que querías hacer ahora? ¿cómo te sientes?) y una entrada de texto libre por reflexión, con historial plegable.
- Nueva entrada "Bienestar" en la hoja "Más" (icono `Smartphone`), entre Relación y Economía.
- Exportación CSV/Excel: las tres sub-áreas de Bienestar incluidas (sin PIN, mismo criterio que Fe/Diario).

### Decisiones de esta fase
- Los índices se calculan sobre una ventana móvil de 7 días, no sobre todo el histórico — refleja mejor la semana actual.
- "Equilibrio" se define como el % de minutos marcados "neutro", manteniendo los tres índices simples de explicar (cada uno es literalmente el % de una categoría) en vez de una fórmula derivada.
- Sin intento de leer el Tiempo de Uso real del dispositivo — solo entrada manual; la importación automática queda pendiente, igual que la del banco en Economía.
- Concentración reutiliza el `useRef`/`setInterval` de 1s del Pomodoro de Productividad en vez de crear un segundo mecanismo de temporizador desde cero.
- Recompensa deliberadamente discreta (mensaje breve + recuento de sesiones, sin puntos/niveles) — petición explícita del Prompt Maestro de no sobregamificar.
- Tres barras de progreso (`BarraIndice`) en vez de tres `ScoreGauge` para el Resumen: `ScoreGauge` usa un id de gradiente SVG fijo que se rompe si se renderiza más de una vez en la misma pantalla — documentado en HANDOFF.md sección 6 para que ninguna fase futura repita el problema.
- `bienestar` (registros/reflexiones/sesiones) pasa entero por `snapshotAndSave`/deshacer, sin PIN — mismo criterio que Fe.

### Dependencias
- Sin dependencias npm nuevas esta fase (`package.json` v0.15.0).

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app (todos los módulos locales, incluidos los nuevos) sin errores, con las dependencias npm marcadas como externas.
- Ninguna de las Fases 8 a 15 tiene confirmación de ejecución real todavía — pendiente por parte de Josué.

### Aparte del código: el atasco de Replit exponiendo el puerto del servidor de desarrollo sigue sin resolver — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 16 — Estadísticas y correlaciones

### Añadido
- Nueva vista `StatsView.jsx` (solo lectura, sin datos propios) que reúne las correlaciones de la app en un solo sitio.
- Dos correlaciones nuevas en `src/lib/correlaciones.js`: **sueño↔ánimo del Diario** y **entreno de calistenia↔ánimo del Diario** (sesiones de las 7 habilidades unificadas en un conjunto de fechas, sin duplicar).
- Las tres correlaciones (más la de sueño↔estudio ya existente desde la Fase 6) exigen un mínimo de días en cada grupo antes de mostrar nada, y explican abiertamente qué les falta cuando no hay datos suficientes.
- Nueva entrada "Estadísticas" en la hoja "Más" (icono `BarChart3`).

### Decisiones de esta fase
- StatsView no guarda nada propio — son cálculos sobre datos que ya existen en otros módulos, así que no hay clave nueva en Supabase ni cambios en exportación.
- El umbral de la correlación entreno↔ánimo es más alto (3 días por grupo) que las de sueño (2), por comparar contra un grupo más heterogéneo ("el resto de mis días").

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app sin errores, incluida la vista nueva.
- Ninguna fase de la 8 a la 16 tiene confirmación de ejecución real todavía.

### Sin dependencias npm nuevas.

## Fase 17 — Predicciones

### Añadido
- Nuevo motor `src/lib/predicciones.js` (solo lectura, sin datos propios), con el mismo espíritu que `correlaciones.js` (Fase 16): honesto sobre cuándo no hay datos suficientes, nunca decide nada por Josué, y usa solo medias/tasas/regresión lineal simple, siempre explicables.
  - `prediccionObjetivo(objetivo)` — tiempo restante hasta el plazo que Josué eligió al crear el objetivo (30d/90d/1/5/10 años desde `fechaCreacion`), simple aritmética de fechas.
  - `prediccionAbandonoHabito(habito)` — riesgo bajo/medio/alto según el % de días marcados en la ventana de hasta 14 días desde el primer día marcado en `historial`.
  - `prediccionPeso(medidas)` — regresión lineal simple sobre las medidas de Salud con campo `peso`, proyecta la tendencia semanal y una estimación a 30 días.
  - `prediccionFuerza(calistenia)` — sin cifra numérica fiable que proyectar (los PRs son texto libre), en su lugar compara la frecuencia de sesiones de la habilidad más entrenada en las últimas 2 semanas frente a las 2 anteriores.
  - `prediccionAhorro(economia)` — neto medio mensual (ingresos − gastos) de los últimos meses con movimientos, proyecta la hucha a 3 meses vista.
  - `prediccionNotas(estudios)` — media de las 3 notas obtenidas más recientes y su tendencia frente a las anteriores, sin forzar una regresión sobre pocos puntos.
- Nueva vista `src/views/PredictionsView.jsx` (solo lectura), con una tarjeta por predicción, siguiendo el mismo patrón visual que `StatsView.jsx` (Fase 16): mensaje explícito de "datos insuficientes" cuando corresponde, nunca una lectura forzada.
- Nueva entrada "Predicciones" en la hoja "Más" (icono `TrendingUp`), justo después de Estadísticas.
- No se exporta a CSV/Excel — mismo criterio que Estadísticas: son cálculos derivados de datos ya existentes, no datos propios.

### Decisiones de esta fase
- **"Fuerza" no proyecta un número inventado.** Los PRs de Calistenia son texto libre (ej. "30s hold"), así que no hay forma honesta de hacer una regresión numérica sobre ellos. En su lugar, la predicción mide constancia (frecuencia de sesiones reciente vs. anterior) de la habilidad que más se entrena, y lo deja explícito en la propia tarjeta para no sugerir una precisión que no existe.
- **"Notas" usa una media de los últimos 3 exámenes, no una regresión lineal.** Con solo 2-3 puntos de datos, ajustar una recta da una falsa sensación de precisión; una media reciente + comparación con el bloque anterior es más honesto y sigue siendo útil.
- **`prediccionObjetivo` es aritmética de fechas, no una proyección estadística** — el "tiempo estimado" de un objetivo, tal y como lo pide el Prompt Maestro, es literalmente cuánto queda del plazo que Josué mismo fijó, no algo que haya que inferir de un historial.
- Sin exportación a CSV/Excel — mismo criterio que Estadísticas (Fase 16): no son datos propios, son cálculos sobre datos que ya se exportan desde sus módulos de origen.

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app (todos los módulos locales, incluida esta fase) sin errores, dependencias npm marcadas como externas.
- Ninguna de las Fases 8 a 17 tiene confirmación de ejecución real todavía — pendiente por parte de Josué.

### Aparte del código: el atasco de Replit exponiendo el puerto del servidor de desarrollo sigue sin resolver — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 18 — IA con memoria a fondo

### Añadido
- **`AIPanel` (`src/components/ui.jsx`) multimodal:** icono de clip junto al botón de pregunta en las 15+ secciones que ya usan `AIPanel`, sin tocar ninguna vista. Permite adjuntar:
  - una foto o captura (imagen) → se manda con `askAIWithImage` (mismo mecanismo que el escaneo de comida de Nutrición, Fase 4);
  - un PDF → se extrae su texto en el navegador con `extractPdfText` (mismo lector que Biblioteca, Fase 11) y se añade como contexto extra al prompt de texto normal; si el PDF no tiene texto extraíble, se avisa en el propio prompt en vez de fallar.
  - El adjunto se limpia después de cada pregunta.
- **Buscador universal en lenguaje natural:** nuevo `UniversalSearchModal` (`ui.jsx`), abierto desde un icono fijo arriba a la derecha en `App.jsx`. Pregunta libre sobre `currentState` (el mismo objeto ya usado para exportar a CSV/Excel, sin `relacion`); la IA responde solo con lo que encuentra en esos datos y lo dice abiertamente si no puede.
- **Panel de sugerencias fijo arriba a la izquierda:** nuevo `SuggestionsButton` (`ui.jsx`), icono con bombilla en `App.jsx`. Panel plegable que, solo al tocar "Generar sugerencias", pide a la IA hasta 2 sugerencias breves sobre un resumen reciente de sueño, calistenia, fútbol, economía, salud, nutrición, estudios, productividad, objetivos, Fe y Bienestar.
- `fileToBase64` añadido a `src/lib/helpers.js`, compartido entre `NutritionView.jsx` (uso ya existente) y el nuevo `AIPanel`.
- `App.jsx`: `pt-8` → `pt-16` en el contenedor principal para dejar sitio a los dos iconos fijos de arriba.

### Decisiones de esta fase
- La multimodalidad se metió dentro del propio `AIPanel`, no como una prop nueva que cada vista tuviera que declarar — mantiene la firma `buildPrompt()` intacta en las 15+ vistas que ya lo usan.
- Un PDF adjunto se manda como texto extraído, no como documento binario a la API de Anthropic — reutiliza el mismo mecanismo que Biblioteca en vez de añadir un tercer tipo de contenido a `api/ask-ai.js`.
- El buscador universal y el panel de sugerencias reutilizan `currentState` como contexto — es el mismo conjunto de datos ya auditado para el export (excluye `relacion`, el único módulo protegido por PIN de principio a fin) — una sola fuente de verdad de "qué puede ver la IA".
- El panel de sugerencias nunca llama a la IA solo por abrirse — exige el toque explícito en "Generar sugerencias" la primera vez, mismo criterio de "la IA nunca se dispara sola" que ya aplicaba en Diario, Objetivos, el análisis de vídeo de Calistenia y el escaneo de comida de Nutrición.
- Tono de `AI_SYSTEM` sin cambios: ya estaba "a medio camino entre prudente y directo" desde una fase anterior, así que no hacía falta tocarlo para esta fase.

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app (todos los módulos locales, incluida esta fase) sin errores, dependencias npm marcadas como externas. También verificados por separado `api/ask-ai.js` y `src/components/ui.jsx`.
- Ninguna de las Fases 8 a 18 tiene confirmación de ejecución real todavía — pendiente por parte de Josué.

### Sin dependencias npm nuevas.

### Aparte del código: el atasco de Replit exponiendo el puerto del servidor de desarrollo sigue sin resolver — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 19 — Personalización total

### Añadido
- Nuevo objeto `personalizacion` en `App.jsx` (`{ orden, ocultos, iconos, pinExtra, favoritas }`), guardado directo en Supabase (`app_data`, clave `personalizacion`) — igual que `ajustes` (accent/pin), no pasa por `snapshotAndSave`/deshacer, porque es configuración de cómo se ve la app, no datos.
- Nueva vista `src/views/PersonalizationView.jsx`, mostrada dentro de la pantalla Ajustes (bajo el título "Personalización avanzada"), con:
  - **Reordenar** cualquier sección de "Más" con flechas arriba/abajo.
  - **Ocultar/mostrar** cualquier sección — ocultar pide confirmación inline ("¿Ocultar 'X' de Más?"), mostrar de nuevo no la pide (solo "borrar" necesita confirmación extra, tal y como pide el Prompt Maestro).
  - **Cambiar el icono** de cualquier sección desde un catálogo de 8 iconos alternativos (`ICONOS_PERSONALIZABLES_IDS` en `tokens.js`) o volver al original.
  - **Proteger con el mismo PIN** cualquier sección además de Relación (que sigue siempre protegida, sin poder quitarle el PIN).
  - **Métricas favoritas del panel "Hoy"**: hasta 4, elegidas de una lista de 6 (peso actual, hucha, mejor racha de hábito, objetivo más próximo, ánimo medio de 7 días, sesiones de concentración de la semana), con su propio orden.
- `DashboardView.jsx`: nuevas tarjetas de métricas favoritas (si hay alguna elegida), justo debajo del recordatorio de Relación.
- Los 4 accesos rápidos de la barra inferior (`PRIMARY_NAV`) y "Ajustes" mismo quedan deliberadamente **fuera** de la personalización — ver decisiones.
- Nuevos tokens en `src/tokens.js`: `ICONOS_PERSONALIZABLES_IDS`, `METRICAS_FAVORITAS_DISPONIBLES`, `MAX_METRICAS_FAVORITAS`, `DEFAULT_PERSONALIZACION`.

### Decisiones de esta fase
- **PRIMARY_NAV y "Ajustes" no son personalizables.** Dejar reordenar/ocultar los 4 accesos fijos de abajo (o el propio Ajustes) abriría la puerta a que Josué se quede sin forma de volver a mostrar algo que ocultó por error — mantenerlos fijos es la salvaguarda más simple.
- **"Crear/eliminar apartados" se interpreta como mostrar/ocultar los módulos ya construidos**, no como un constructor de módulos arbitrarios desde cero. Esto último (secciones completamente nuevas con su propio esquema de datos) está fuera del alcance razonable de una PWA de código fijo — el Prompt Maestro no detalla ese nivel, y encaja mejor en el motor de automatizaciones/plantillas ya previsto para la Fase 20.
- **"Cambiar gráficos" no se toca en esta fase** — el color de los gráficos ya se personaliza desde la Fase 1 (accent), y no hay una petición concreta de tipos de gráfico alternativos; no se añade alcance no pedido.
- **Confirmación solo al ocultar, nunca al mostrar de nuevo** — literal a la petición del Prompt Maestro ("confirmación extra solo al borrar un módulo entero"); mostrar de nuevo una sección oculta es una acción segura y reversible sin más fricción.
- **Ocultar un módulo nunca borra sus datos** — solo lo quita de la lista "Más"; los datos siguen intactos en Supabase y vuelven a aparecer en cuanto se muestra de nuevo. Una "eliminación" real de datos no se pidió y sería demasiado arriesgada para una casilla de personalización.
- **`personalizacion` se guarda directo (como `ajustes`), no pasa por `snapshotAndSave`** — es preferencia de interfaz, no un dato que tenga sentido "deshacer" con el histórico de 10 pasos compartido con el resto de módulos.
- **Las métricas favoritas se calculan en `App.jsx`, no dentro de `DashboardView.jsx`** — cada métrica cruza datos de un módulo distinto (Salud, Economía, Productividad, Objetivos, Diario, Bienestar); mismo criterio que Estadísticas/Predicciones, ninguna vista de solo lectura debería conocer la forma interna de otro módulo.
- **`proximo_objetivo` reutiliza `prediccionObjetivo()`** (Fase 17) en vez de duplicar el cálculo de plazo — mismo dato, misma fuente de verdad.

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo de la app (todos los módulos locales, incluida esta fase) sin errores, dependencias npm marcadas como externas.
- Ninguna de las Fases 8 a 19 tiene confirmación de ejecución real todavía — pendiente por parte de Josué.

### Aparte del código: el atasco de Replit exponiendo el puerto del servidor de desarrollo sigue sin resolver — ver HANDOFF.md sección 12. No bloquea seguir construyendo fases.

## Fase 20 — Funciones transversales avanzadas (completa)

### Añadido (turno anterior)
- Primera automatización fija del Prompt Maestro: aviso en el Dashboard cuando el sueño de anoche es menor de 7h, sugiriendo entreno más suave hoy y adelantar la hora de dormir. Cálculo al vuelo, sin datos nuevos que guardar.

### Añadido (este turno — cierra la Fase 20)
- **Segunda y tercera automatización fija** (`src/views/DashboardView.jsx`): `AvisoRachaEnRiesgo` (un hábito con racha de 3+ días sin marcar hoy ni ayer — un tercer día sin marcar la rompería) y `AvisoExamenSinHoras` (examen dentro de 3 días sin horas de estudio registradas esa semana para su asignatura). Mismo patrón que `AvisoSuenoCorto`: cálculo al vuelo, sin datos nuevos, riesgo mínimo.
- **Centro de logros** (`src/lib/logros.js` + `src/views/AchievementsView.jsx`, pestaña "Logros"): 12 insignias binarias (sin puntos/niveles/monedas) calculadas sobre datos ya existentes de Productividad, Diario, Objetivos, Bienestar, Fe, Nutrición, Salud, Calistenia, Economía y Sueño. Mismo criterio "solo lectura, sin datos propios" que Estadísticas/Predicciones.
- **Mapa de vida** (`AchievementsView.jsx`, pestaña "Mapa de vida"): visualización cronológica de los Objetivos ya existentes (30 días a 10 años) como línea de tiempo — no crea ni duplica datos, reutiliza `objetivos.lista` tal cual.
- Nueva entrada en `MORE_NAV`: "Logros" (icono `Trophy`), justo después de Predicciones.
- **Modos "viaje/vacaciones/exámenes"** (`MODOS_APP` en `src/tokens.js`, nueva sección en `PersonalizationView.jsx`, `ModoBanner` en `DashboardView.jsx`): plantillas ligeras, no un motor configurable — 3 chips en Ajustes → Personalización avanzada; el activo (uno o ninguno) muestra un aviso con 2-3 recordatorios de texto fijo en el Dashboard. Nueva clave `personalizacion.modo` (mismo objeto guardado directo que el resto de Personalización, sin pasar por `snapshotAndSave`/deshacer).

### Verificado en este entorno (sin red real)
- `esbuild`: bundle completo (`src/main.jsx`, formato ESM, dependencias npm marcadas como externas) sin errores, 317.9kb.

## Fase 21 — Pulido final y QA (en curso, segunda pasada)

### Hecho en el turno anterior (primera pasada)
- Auditoría de coherencia visual: búsqueda de colores hexadecimales sueltos fuera de `src/tokens.js` en todo `src/`. Resultado: ningún color nuevo introducido en la Fase 20 está suelto (todo usa `COLORS`/`accent`/`hexToRgba`); los hallazgos existentes (`#080A0D` como color de texto sobre botón de acento, `#C9A24B` como color de aviso/riesgo medio) son un patrón ya establecido y repetido a propósito desde fases anteriores, no un defecto — no se tocan sin petición explícita de Josué (ver sección 17 del HANDOFF).

### Hecho este turno (segunda pasada)
- **Revisión de código de `src/lib/exportData.js`:** confirmado que `currentState` (`App.jsx`, línea ~443) excluye correctamente `relacion` y que sus claves coinciden exactamente con lo que `buildExportRows()` espera para cada módulo. Sin errores encontrados.
- **Revisión de código de `src/lib/supabase.js`:** patrón `loadData`/`saveData` genérico revisado sin errores. Caso de riesgo comprobado explícitamente: `loadData` no fusiona con el valor por defecto si ya existe una fila guardada en Supabase — se verificó que `personalizacion.modo` (añadido en la Fase 20) no rompe nada aunque llegue como `undefined` en un registro guardado antes de la Fase 20, porque todo el código que lo usa (`ModoBanner`, `ModoAppSection`, `setModoApp`) lo trata igual que `null`. No hace falta ninguna migración de datos.
- **Revisión del tono de la IA:** repasados los 13 `AIPanel` reales de la app (no 17+ como decía el HANDOFF — cifra corregida) en `BusinessView`, `DashboardView`, `DiaryView`, `EstudiosView`, `FaithView` (2), `FinanceView`, `HealthView`, `NutritionView`, `ObjectivesView`, `ProductivityView`, `SleepView`, `TrainingView`. Tono consistente en todos: factual, cita datos concretos del propio JSON en vez de opinar en abstracto, "aconseja/sugiere, no decide por él", y admite abiertamente cuando hay pocos datos para un patrón real. Confirmado que `HealthView`/`NutritionView` evitan dar objetivos calóricos o de peso estrictos, y que ambos `AIPanel` de `FaithView` incluyen `AVISO_DOCTRINAL`. No se ha necesitado tocar ningún `buildPrompt()`.

### Explícitamente pendiente (ver HANDOFF.md, sección 16)
- Repaso visual/contraste real, módulo por módulo, pantalla a pantalla — lo hecho hasta ahora (grep de colores) no sustituye mirar cada vista renderizada.
- Pruebas reales de exportación/offline/sincronización de extremo a extremo — Claude nunca ejecuta la app de verdad; el código ya se ha revisado (ver arriba), pero la prueba real la tiene que hacer Josué en Replit/Vercel.
